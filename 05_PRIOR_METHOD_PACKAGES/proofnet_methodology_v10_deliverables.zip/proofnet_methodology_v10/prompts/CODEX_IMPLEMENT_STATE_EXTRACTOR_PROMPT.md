# Codex Prompt: Implement Lean Tactic-State Extractor

You are working inside the current uploaded package `proofnet_frontier_v04_audit_deliverables.zip`. Build the next technical step: a Lean 4 tactic-state extractor that records `state_before`, `tactic`, `state_after`, `graph_delta`, and partial graph frontier mappings for a controlled subset of tactics.

## Hard requirements

1. Avoid proof leakage. Split every declaration into:
   - `formal_statement_header` without `:= by` or proof body;
   - `proof_body_source`;
   - `full_declaration_source`.
   Never use `proof_body_source` as model input for next-tactic prediction.

2. Keep node ids separate from model features. Node ids may be stable engineering identifiers, but model features must use normalized expressions, types, declarations, and structural roles.

3. Extract graph nodes from Lean objects, not manual labels:
   - metavariable goals;
   - goal target expressions;
   - local context declarations;
   - declarations/constants used by elaborated tactics;
   - tactic effects;
   - proof-term dependencies when available.

4. Generate both success and failure records. For failure records, store the pre-state, candidate tactic, Lean error excerpt, failure type, and optional candidate graph-delta estimate.

5. Implement only a controlled subset first:
   - `intro`, `intros`, `exact`, `assumption`, `apply`, `refine`, `constructor`, `left`, `right`, `cases`, `rcases`, `have`, `suffices`, `let`, `rw`, `rfl`, `exfalso`, `contradiction`.
   Automation tactics may be recorded as coarse `AutomationBundle` nodes.

## Engineering plan

Create:

```text
ProofNet/Extract/State.lean
ProofNet/Extract/InfoTree.lean
ProofNet/Extract/Expr.lean
ProofNet/Extract/Delta.lean
ProofNet/Extract/Serialize.lean
scripts/run_state_extractor.py
scripts/validate_extracted_traces.py
```

## Required output format

Emit JSONL records with schema version `proofnet-trace-step-1.0`:

```json
{
  "schema_version": "proofnet-trace-step-1.0",
  "record_type": "trace_step",
  "quality_tier": "silver",
  "theorem_id": "...",
  "variant_id": "...",
  "step_index": 0,
  "source_span": {"file": "...", "start_line": 1, "end_line": 1},
  "state_before": {"goals": []},
  "tactic": "constructor",
  "state_after": {"goals": []},
  "lean_result": "success",
  "graph_before_hash": "...",
  "graph_delta": {"nodes_added": [], "edges_added": [], "nodes_updated": []},
  "graph_after_hash": "...",
  "frontier_before": [],
  "frontier_after": [],
  "used_declarations": [],
  "provenance": {"trace_origin": "lean_state"}
}
```

## Validation tests

Test on controlled synthetic examples:

1. conjunction constructor/exact;
2. disjunction left/right;
3. equality substitution by `cases h` and `exact`;
4. `rw` theorem;
5. `have` intermediate claim.

Then test on selected PFR examples from the current package, but mark them as silver only if Lean states and graph deltas are actually extracted.

## Reports

Produce strict reports:

- number of declarations extracted;
- number of tactic steps with real states;
- number of failures;
- percentage of empty graph deltas;
- proof leakage violations;
- frontier invariant violations;
- examples that remain bronze/source-only.

Do not overclaim: if state extraction fails, keep the record as bronze and explain why.
