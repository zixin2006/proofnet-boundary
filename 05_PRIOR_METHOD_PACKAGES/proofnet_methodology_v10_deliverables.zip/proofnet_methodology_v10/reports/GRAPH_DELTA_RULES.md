# Graph Delta Rules for Common Lean Tactics

| Tactic | Expected Lean state change | Nodes added | Edges added | Reliability | Lean data needed | Failure cases |
|---|---|---|---|---|---|---|
| `intro` | Introduces one binder into local context; target changes from forall/implication to body | `Hypothesis`, successor `OpenGoal` | `introduces_hypothesis`, `creates_subgoal` | High | pre/post goals and local context diff | implicit binders, pattern intro |
| `intros` | Repeated `intro` | multiple `Hypothesis`/`LocalDefinition` nodes | repeated introduction edges | High | ordered context diff | inaccessible names, patterns |
| `exact` | Closes current goal using supplied term | `TacticStep`, optional `Term` | `uses`, `closes` | High | elaborated term, pre/post goals | term elaborates through automation/coercions |
| `assumption` | Closes by matching local hypothesis | `TacticStep` | `uses`, `closes` | High | selected local decl or proof term | multiple possible matches |
| `apply` | Replaces goal by premises of lemma/theorem | `Lemma`, child `OpenGoal`s | `applies_lemma`, `creates_subgoal`, `decomposes` | High | elaborated constant and resulting mvars | coercions/typeclass subgoals obscure premises |
| `refine` | Constructs partial proof term with holes | `ProofTermFragment`, holes as `OpenGoal`s | `constructs`, `creates_subgoal` | High | elaborated partial term | hole order may differ from source order |
| `constructor` | Splits constructor goal into fields/subgoals | `ConstructorSplit`, child `OpenGoal`s | `decomposes`, `creates_subgoal`, maybe `sibling_independent` | High | constructor selected and post goals | typeclass/instance constructors |
| `left` | Selects left constructor/disjunct | `ConstructorSplit` or `CaseChoice` | `constructs`, `creates_subgoal` | High | pre/post target | overloaded constructors |
| `right` | Selects right constructor/disjunct | `ConstructorSplit` or `CaseChoice` | `constructs`, `creates_subgoal` | High | pre/post target | overloaded constructors |
| `cases` | Case split on inductive hypothesis/term | `CaseSplit`, branch goals, projected hypotheses | `splits_case`, `projects`, `creates_subgoal` | Medium-high | local context per branch | dependent eliminator complexity |
| `rcases` | Patterned case split and destructuring | `CaseSplit`, `Projection`, branch goals | `splits_case`, `projects` | Medium | branch contexts, pattern parse | complex nested patterns |
| `induction` | Constructor cases plus induction hypotheses | `CaseSplit`, branch goals, IH hypotheses | `splits_case`, `depends_on` | Medium | recursor info, branch contexts | generalized hypotheses, dependent motives |
| `have` | Adds intermediate claim and possibly a proof subgoal | `IntermediateClaim`, `OpenGoal` | `constructs`, `depends_on`, `creates_subgoal` | High | context diff and generated goals | anonymous have, by-block nesting |
| `suffices` | Replaces goal by sufficient claim plus proof of original from claim | `IntermediateClaim`, child goals | `depends_on`, `creates_subgoal` | High | generated goals and context diff | nontrivial term elaboration |
| `let` | Adds local definition | `LocalDefinition` | `introduces_hypothesis`, `normalizes_to` | High | local context diff | reducibility affects normalization |
| `rw` | Rewrites target or hypothesis | `Rewrite`, optional `Lemma` | `rewrites`, `uses` | Medium-high | rewrite lemma, direction, location | simp-normalization around rw |
| `simp` | Simplifies using simp set; may close or transform | `AutomationBundle`, optional rewrite bundle | `rewrites`, `closes` or `creates_subgoal` | Low-medium | simp trace/proof term | large hidden search/noisy trace |
| `rfl` | Closes reflexive equality/reducible equality | `TacticStep` | `normalizes_to`, `closes` | High | target normalization | reducibility transparency differences |
| `ext` | Extensionality creates pointwise goals | `ConstructorSplit` or `Projection` | `decomposes`, `introduces_hypothesis` | Medium | ext theorem used, post goals | overloaded/extensional lemmas hidden |
| `omega` | Presburger arithmetic automation | `AutomationBundle` | `closes` or `fails_on` | Low | proof term/certificate if available | hidden arithmetic search |
| `linarith` | Linear arithmetic automation | `AutomationBundle` | `uses`, `closes` | Low | selected hypotheses/certificate | nonlinear terms or normalization |
| `ring` | Normalizes semiring/ring expressions | `AutomationBundle` | `normalizes_to`, `closes` | Low-medium | proof term/certificate | coercions/semiring instances |
| `aesop` | Search over rules/tactics | `AutomationBundle` | `closes`, `uses` where known | Low | aesop trace/proof term | huge hidden search tree |
| `tauto` | Propositional tautology automation | `AutomationBundle` | `decomposes`, `closes` coarse | Low-medium | proof term | hidden propositional proof |
| `contradiction` | Closes from contradictory context | `TacticStep` | `uses`, `closes` | Medium-high | selected contradiction if recoverable | implicit discrimination/no-confusion |
| `exfalso` | Changes target to `False` | successor `OpenGoal` | `normalizes_to`, `creates_subgoal` | High | pre/post target | none substantial |

Silver records should keep automation tactics coarse. Gold records may enrich them by proof-term or tactic-specific trace inspection.
