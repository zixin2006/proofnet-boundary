# Partial Proof Graph Schema v1.0

## Graph object

```text
G_i = (V_i, E_i, tau_i, ell_i, sigma_i, rho_i, eta_i)
```

## Node types

- `Goal`
- `OpenGoal`
- `ClosedGoal`
- `Hypothesis`
- `LocalDefinition`
- `Lemma`
- `TacticStep`
- `Projection`
- `Rewrite`
- `CaseSplit`
- `ConstructorSplit`
- `IntermediateClaim`
- `Term`
- `ProofTermFragment`
- `Conclusion`
- `Failure`
- `AutomationBundle`
- `Witness`

## Edge types

- `uses`
- `creates_subgoal`
- `decomposes`
- `closes`
- `rewrites`
- `applies_lemma`
- `introduces_hypothesis`
- `splits_case`
- `projects`
- `constructs`
- `depends_on`
- `sibling_independent`
- `normalizes_to`
- `fails_on`
- `validated_by_term`

## Status values

- `open`
- `closed`
- `decomposed`
- `verified`
- `failed`
- `source_only`

## Provenance values

- `source_heuristic`
- `lean_state`
- `proof_term`
- `kernel_dependency`
- `manual_audit`

## Invariant

Every open Lean goal in `state_i` corresponds to exactly one open frontier node in `G_i`, and every open frontier node corresponds to exactly one open Lean goal unless the record is explicitly marked `source_heuristic` or `bronze`.

## Hash policy

- `literal_graph_hash`: exact serialization hash, unstable across ids.
- `shape_graph_hash`: ignores labels and ids; used only for diagnostics.
- `canonical_graph_hash`: conservative graph canonicalization.
- `state_hash`: normalized Lean state hash.
- `state_graph_joint_hash`: recommended pruning key component.

Do not prune by graph hash alone.
