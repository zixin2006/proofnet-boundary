# Academic and Technical Work Review

This review separates existing work, adaptation, and original contribution.

## Proof nets and proof bureaucracy

### Girard: Linear Logic and Proof Nets
Existing work: Girard introduced linear logic and proof nets as graphical representations reducing sequential bureaucracy in proofs. The important conceptual point is that two sequent derivations can differ only by irrelevant rule ordering.

What it does not provide: a Lean tactic-state extractor, a dataset schema, or a method for incomplete proof-search states.

How this project builds on it: proof nets motivate quotienting away tactic-history bureaucracy, but the project replaces complete proof nets with Lean-certified partial proof graphs during search.

Primary reference: Jean-Yves Girard, *Linear Logic*, Theoretical Computer Science, 1987; and Girard's proof-net notes: https://girard.perso.math.cnrs.fr/Synsem.pdf

### Strassburger and Guglielmi: Proof identity and bureaucracy
Existing work: proof nets are presented as a response to proof identity and bureaucratic derivation structure.

What it does not provide: Lean-specific extraction or ML search records.

Project adaptation: the bureaucracy idea becomes a canonicalization rule for search states, but only conservatively and always paired with normalized Lean state.

References: https://www.lix.polytechnique.fr/~lutz/papers/ESSLLI06notes-270606.pdf and https://researchportal.bath.ac.uk/en/publications/the-problem-of-bureaucracy-and-identity-of-proofs-from-the-perspe/

## Lean infrastructure

### Lean 4 kernel, elaborator, and tactics
Existing work: Lean 4 is based on dependent type theory with a small trusted kernel, elaboration, tactics, metaprogramming, and generated proof terms. The language reference and Lean 4 paper document the underlying system.

What it does not provide: a proof-net-inspired graph object or certified graph-delta schema.

Project adaptation: use Lean's elaboration and tactic infrastructure to inspect goals and local context before/after tactics.

References: https://lean-lang.org/doc/reference/latest/ and https://lean-lang.org/papers/lean4.pdf

### Lean InfoTree
Existing work: InfoTree records elaboration/tactic information tied to source positions and powers the infoview ecosystem.

What it does not provide: stable ML-ready graph-delta traces out of the box.

Project adaptation: use InfoTree/source spans to align tactic text with state snapshots and proof-term enrichment.

References: https://leanprover-community.github.io/mathlib4_docs/Lean/Elab/InfoTree/Types.html and https://leanprover-community.github.io/mathlib4_docs/Lean/Elab/InfoTree/Main.html

### Mathlib
Existing work: mathlib is a large community-driven Lean mathematics library and the main substrate for modern Lean proving.

What it does not provide: proof-net graphs or graph-conditioned search datasets.

Project adaptation: use mathlib and mathlib-dependent frontier repositories as large-scale extraction targets.

Reference: https://arxiv.org/pdf/1910.09336

## Neural theorem proving

### LeanDojo and ReProver
Existing work: LeanDojo extracts Lean proof states, tactics, premises, and supports retrieval-augmented theorem proving with best-first search. It demonstrates that real Lean execution traces can become benchmark-quality ML data.

What it does not provide: partial proof-net-inspired graphs, graph deltas, or frontier-node mappings.

Project adaptation: treat LeanDojo as the closest engineering precedent, but add graph state and graph-delta supervision.

References: https://arxiv.org/pdf/2306.15626 and https://github.com/lean-dojo/reprover

### LeanProgress
Existing work: proof-progress prediction can improve Lean proof search, especially for long proofs.

What it does not provide: graph-conditioned proof progress over open frontier nodes.

Project adaptation: the partial proof graph can be used as a richer progress/value state.

Reference: https://arxiv.org/abs/2502.17925

### Expert iteration and search-generated theorem proving
Existing work: modern theorem provers increasingly combine neural proposal models with tree search, value models, and search-generated data.

What it does not provide: graph compatibility/pruning labels tied to Lean-certified partial graph states.

Project adaptation: positive and negative branch records allow graph compatibility and pruning models.

Example references: https://openreview.net/forum?id=kk3mSjVCUO and related expert-iteration theorem-proving literature.

## Graph-based theorem proving

### Premise selection by deep graph embedding
Existing work: formula graphs can encode logical structure with invariance to variable renaming and support premise selection.

What it does not provide: dynamic proof-state graphs or tactic-transition graph deltas.

Project adaptation: use graph normalization ideas for Lean expressions and local context.

Reference: https://papers.neurips.cc/paper/6871-premise-selection-for-theorem-proving-by-deep-graph-embedding.pdf

### Graph representations for higher-order logic
Existing work: GNNs can improve higher-order theorem proving by encoding formulas/proof obligations as graphs.

What it does not provide: Lean 4 tactic-state instrumentation or proof-net-inspired frontier tracking.

Project adaptation: motivates expression-graph encoders for goals, hypotheses, and proof fragments.

Reference: https://openreview.net/pdf?id=iUGUc3HJ_3f

### Graph2Tac
Existing work: graph-based representations can improve tactic prediction in interactive theorem proving, especially in online settings with new definitions.

What it does not provide: Lean-certified graph deltas for search redundancy.

Project adaptation: use graph-conditioned tactic prediction, but with graph states produced by accepted Lean transitions.

Reference: https://proceedings.mlr.press/v235/blaauwbroek24a.html

## Formalization-scale projects

### PFR formalization
Existing work: the Polynomial Freiman-Ruzsa formalization in Lean 4 shows blueprint-guided large-scale formalization on modern mathematics.

What it does not provide: tactic-state graph-delta traces for ML.

Project adaptation: use as a frontier repository for source-mined and eventually Lean-state extracted graph traces.

References: https://teorth.github.io/pfr/ and https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/

### Liquid Tensor Experiment
Existing work: completed Lean formalization of a frontier theorem, with blueprint/dependency organization.

Project adaptation: use blueprint structure as repository-level dependency context, not as substitute for tactic-level graph extraction.

References: https://leanprover-community.github.io/blog/posts/lte-final/ and https://github.com/leanprover-community/lean-liquid

### Equational Theories Project
Existing work: Lean formalization of implication relations among thousands of equational laws, with collaborative proof discovery.

Project adaptation: strong candidate for graph-guided search because implication structure is naturally graph-shaped.

Reference: https://teorth.github.io/equational_theories/

### FLT regular primes
Existing work: large formalization of Fermat's Last Theorem for regular primes in Lean.

Project adaptation: advanced stress test for graph extraction, proof-term dependency enrichment, and long-proof search.

References: https://lean-lang.org/use-cases/flt/ and https://afm.episciences.org/16046/pdf
