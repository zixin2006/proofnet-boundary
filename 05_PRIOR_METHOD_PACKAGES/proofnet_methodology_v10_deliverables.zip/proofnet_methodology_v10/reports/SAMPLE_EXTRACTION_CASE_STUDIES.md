# Sample Extraction Case Studies

## Case 1: controlled conjunction theorem

```lean
theorem C01_and_comm {A B : Prop} (h : A \and B) : B \and A := by
  constructor
  · exact h.right
  · exact h.left
```

Expected transitions:

1. Initial state has one open goal `B \and A` with local hypothesis `h : A \and B`.
2. `constructor` decomposes the goal into two child goals: `B` and `A`.
3. `exact h.right` closes the first child using a projection from `h`.
4. `exact h.left` closes the second child using a projection from `h`.

Intended partial graph after step 1:

```text
Goal(B and A) --decomposes--> ConstructorSplit(and.intro)
ConstructorSplit --creates_subgoal--> Goal(B)
ConstructorSplit --creates_subgoal--> Goal(A)
Goal(B) --sibling_independent--> Goal(A)
```

Current package status: controlled synthetic graphs represent this structure manually, but no `state_before`, `state_after`, or mechanically extracted graph deltas are available. Improved representation should use metavariable-aligned frontier nodes and Lean-local declarations.

## Case 2: equality/dependent rewrite theorem

```lean
theorem C22_eq_subst {alpha : Type} {P : alpha -> Prop} {a b : alpha}
    (h : a = b) (ha : P a) : P b := by
  cases h
  exact ha
```

Expected transitions:

1. `cases h` performs equality elimination; the goal normalizes from `P b` to `P a` in the reflexive case.
2. `exact ha` closes the normalized goal.

Graph delta:

```json
{
  "tactic": "cases h",
  "nodes_added": [{"type": "CaseSplit", "label": "Eq.rec/cases"}],
  "edges_added": [{"type": "normalizes_to", "from": "goal:P b", "to": "goal:P a"}]
}
```

Current package status: source/synthetic structure may say rewrite/case, but real target normalization requires Lean instrumentation.

## Case 3: promoted PFR frontier theorem

The promoted PFR records in the uploaded package are useful because they carry frontier provenance and build-verification metadata. The current graph is nevertheless too coarse: it uses lemma clusters and semantic labels rather than extracted local goals, side obligations, witnesses, and case branches.

Expected improved extraction:

- `obtain` and `rcases` create witness/projection nodes.
- positivity and inequality subgoals become separate frontier nodes.
- `have` nodes become intermediate claims with proof subgoals.
- final existential assembly becomes `Witness` + `constructs`/`closes` edges.

Current package status: verified subset is useful for selecting examples, but the graph is not a Lean-state trace. Do not train a search/pruning model on it as if it were extracted.

## Case 4: longer frontier/source-mined tactic script

The source-mined trace file includes longer tactic scripts with rows such as `obtain`, `have`, `rw`, `convert`, `le_antisymm`, and `rcases`. These rows are valuable as bronze alignment data. However all `state_before` and `state_after` fields are null, so the graph deltas cannot yet be validated.

Expected improved representation:

- `le_antisymm` decomposes a relation equality/order goal into two inequality subgoals.
- `set y := ...` creates a local definition node linked by `normalizes_to`.
- `rw` emits rewrite nodes preserving direction and location.
- `convert` emits a proof-term-fragment node and child unification obligations.
- `rcases` emits case/projection/witness nodes.

Current diagnosis: the current graph is too linear and too shallow. The source rows should be kept as bronze records and upgraded to silver only after Lean instrumentation supplies states and deltas.
