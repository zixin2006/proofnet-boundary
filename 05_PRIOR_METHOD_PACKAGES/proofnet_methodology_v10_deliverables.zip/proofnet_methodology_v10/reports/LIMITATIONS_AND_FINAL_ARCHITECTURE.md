# Limitations and Final Architecture

## Limitations

1. Automation tactics hide large searches. Tactics such as `simp`, `aesop`, `linarith`, `omega`, and `ring` can compress many internal proof steps into one tactic. Silver records should use coarse `AutomationBundle` nodes; gold records may attempt proof-term or tactic-trace enrichment.

2. Proof terms can be huge and noisy. Kernel-inspected dependencies are more trustworthy than source parsing, but full proof-term graphs may be too large for training. The methodology should extract dependency summaries and certificates, not always raw proof terms.

3. Dependent types make equivalence hard. A local hypothesis may appear syntactically renamed but semantically dependent on prior variables. Canonicalization must preserve local-context dependency structure.

4. Typeclass inference introduces hidden dependencies. Typeclass-resolved instances can affect search behavior and must be preserved when relevant.

5. Multiple tactic scripts may elaborate to similar or different proof terms. The project should not assume tactic-history equivalence from graph shape alone.

6. Manual graph labels cause leakage. Labels such as `entropy`, `ruzsa`, or `cover` may encode human semantic summaries unavailable to the prover. They should be excluded from model features unless derived from Lean expressions or declarations.

7. Source-mined graphs are too linear. Source parser output is useful for alignment but cannot certify proof structure.

8. Graph canonicalization can be unsound if over-aggressive. Always use the joint key `(NormalizeState(s_i), CanonicalizePartialGraph(G_i))`.

9. Frontier repositories are hard to build at scale. Pin exact commits, toolchains, mathlib versions, and build logs.

## Final recommended architecture

```text
Stage 0: source-mined bronze records
Stage 1: tactic-state silver records
Stage 2: proof-term-enriched gold records
Stage 3: graph-guided search records with positive and negative branches
Stage 4: large-scale frontier dataset
```

## Which stages are trainable?

- Bronze: weak pretraining, tactic-family classification, source alignment, repository selection.
- Silver: graph-delta learning, graph-conditioned next-tactic prediction, frontier-invariant modeling.
- Gold: graph-conditioned premise/tactic prediction with dependency supervision.
- Search records: pruning, compatibility, proof-progress/value models.
- Frontier benchmark: evaluation only until extraction is build-verified and state-backed.

## Final methodology in one sentence

Build a Lean instrumentation system that turns accepted tactic transitions into certified graph deltas while preserving an exact frontier correspondence between Lean open goals and graph open nodes.
