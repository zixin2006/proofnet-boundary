#!/usr/bin/env python3
"""Controlled graph-delta rule table for the MVP extractor."""
RULES = {
  'intro': {'reliability':'high','nodes':['Hypothesis','OpenGoal'],'edges':['introduces_hypothesis','creates_subgoal']},
  'intros': {'reliability':'high','nodes':['Hypothesis','OpenGoal'],'edges':['introduces_hypothesis','creates_subgoal']},
  'exact': {'reliability':'high','nodes':['TacticStep','Term'],'edges':['uses','closes']},
  'assumption': {'reliability':'high','nodes':['TacticStep'],'edges':['uses','closes']},
  'apply': {'reliability':'high','nodes':['Lemma','OpenGoal'],'edges':['applies_lemma','creates_subgoal','decomposes']},
  'refine': {'reliability':'high','nodes':['ProofTermFragment','OpenGoal'],'edges':['constructs','creates_subgoal']},
  'constructor': {'reliability':'high','nodes':['ConstructorSplit','OpenGoal'],'edges':['decomposes','creates_subgoal','sibling_independent']},
  'cases': {'reliability':'medium-high','nodes':['CaseSplit','OpenGoal','Projection'],'edges':['splits_case','projects','creates_subgoal']},
  'rcases': {'reliability':'medium','nodes':['CaseSplit','Projection','OpenGoal'],'edges':['splits_case','projects']},
  'induction': {'reliability':'medium','nodes':['CaseSplit','Hypothesis','OpenGoal'],'edges':['splits_case','depends_on','creates_subgoal']},
  'have': {'reliability':'high','nodes':['IntermediateClaim','OpenGoal'],'edges':['constructs','depends_on','creates_subgoal']},
  'suffices': {'reliability':'high','nodes':['IntermediateClaim','OpenGoal'],'edges':['depends_on','creates_subgoal']},
  'let': {'reliability':'high','nodes':['LocalDefinition'],'edges':['introduces_hypothesis','normalizes_to']},
  'rw': {'reliability':'medium-high','nodes':['Rewrite','Lemma'],'edges':['rewrites','uses']},
  'simp': {'reliability':'low-medium','nodes':['AutomationBundle'],'edges':['rewrites','closes']},
  'rfl': {'reliability':'high','nodes':['TacticStep'],'edges':['normalizes_to','closes']},
  'ext': {'reliability':'medium','nodes':['Projection','OpenGoal'],'edges':['decomposes','introduces_hypothesis']},
  'omega': {'reliability':'low','nodes':['AutomationBundle'],'edges':['closes']},
  'linarith': {'reliability':'low','nodes':['AutomationBundle'],'edges':['uses','closes']},
  'ring': {'reliability':'low-medium','nodes':['AutomationBundle'],'edges':['normalizes_to','closes']},
  'aesop': {'reliability':'low','nodes':['AutomationBundle'],'edges':['closes']},
  'tauto': {'reliability':'low-medium','nodes':['AutomationBundle'],'edges':['decomposes','closes']},
  'contradiction': {'reliability':'medium-high','nodes':['TacticStep'],'edges':['uses','closes']},
  'exfalso': {'reliability':'high','nodes':['OpenGoal'],'edges':['normalizes_to','creates_subgoal']},
}

def classify(tactic_text: str):
    head = tactic_text.strip().split(maxsplit=1)[0].lstrip('·').strip()
    return RULES.get(head, {'reliability':'unknown','nodes':['TacticStep'],'edges':[]})

if __name__ == '__main__':
    import json, sys
    for arg in sys.argv[1:]: print(json.dumps({'tactic':arg, 'rule':classify(arg)}, indent=2))
