#!/usr/bin/env python3
"""Source-level Lean declaration extractor.
This bronze extractor separates statement headers from proof bodies to avoid proof leakage.
It is not a Lean elaborator and does not certify tactics.
"""
import argparse, json, pathlib, re

def split_decl(text):
    # Conservative theorem/lemma finder for simple declarations.
    pattern = re.compile(r'(?ms)^\s*(theorem|lemma|def)\s+([A-Za-z0-9_\.\']+).*?(?=^\s*(?:theorem|lemma|def)\s+|\Z)')
    for m in pattern.finditer(text):
        src = m.group(0).strip()
        marker = ':= by'
        if marker in src:
            head, body = src.split(marker, 1)
            header = head.rstrip()
            proof = 'by' + body
            safe = marker not in header
        else:
            header, proof, safe = src, '', True
        yield {"declaration_kind": m.group(1), "declaration_name": m.group(2), "formal_statement_header": header, "proof_body_source": proof, "full_declaration_source": src, "proof_leakage_check": {"input_safe": safe, "header_contains_proof_body_marker": ':= by' in header}}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('paths', nargs='+')
    ap.add_argument('--out', required=True)
    args=ap.parse_args()
    with open(args.out,'w',encoding='utf-8') as out:
        for p in args.paths:
            path=pathlib.Path(p)
            for file in ([path] if path.is_file() else path.rglob('*.lean')):
                for rec in split_decl(file.read_text(encoding='utf-8', errors='ignore')):
                    rec['file_path']=str(file)
                    out.write(json.dumps(rec, ensure_ascii=False)+'\n')
if __name__=='__main__': main()
