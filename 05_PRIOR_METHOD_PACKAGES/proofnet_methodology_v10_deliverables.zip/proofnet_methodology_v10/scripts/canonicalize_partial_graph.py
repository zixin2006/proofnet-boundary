#!/usr/bin/env python3
"""Conservative partial-graph canonicalizer. It intentionally preserves labels/exprs."""
import json, hashlib, argparse

def canonicalize_graph(g):
    nodes = g.get('nodes', [])
    edges = g.get('edges', [])
    # Replace engineering ids by deterministic ids ordered by type and normalized label.
    def node_key(n): return (n.get('type',''), json.dumps(n.get('label',{}), sort_keys=True, ensure_ascii=False), n.get('status',''))
    sorted_nodes = sorted(nodes, key=node_key)
    idmap = {n.get('id'): f'n{i}' for i,n in enumerate(sorted_nodes)}
    cnodes = [{k:v for k,v in n.items() if k!='id'} | {'cid': idmap.get(n.get('id'), n.get('id'))} for n in sorted_nodes]
    cedges=[]
    for e in edges:
        c=dict(e); c.pop('id', None); c['source']=idmap.get(e.get('source'), e.get('source')); c['target']=idmap.get(e.get('target'), e.get('target')); cedges.append(c)
    cedges=sorted(cedges, key=lambda e:(e.get('type',''), e.get('source',''), e.get('target',''), json.dumps(e.get('features',{}), sort_keys=True)))
    return {'nodes':cnodes,'edges':cedges,'open_frontier':sorted(idmap.get(x,x) for x in g.get('open_frontier',[]))}

def sha(obj): return 'sha256:'+hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('jsonl'); args=ap.parse_args()
    for line in open(args.jsonl, encoding='utf-8'):
        if not line.strip(): continue
        rec=json.loads(line); cg=canonicalize_graph(rec.get('graph',{})); rec['computed_canonical_graph_hash']=sha(cg); print(json.dumps(rec, ensure_ascii=False))
if __name__=='__main__': main()
