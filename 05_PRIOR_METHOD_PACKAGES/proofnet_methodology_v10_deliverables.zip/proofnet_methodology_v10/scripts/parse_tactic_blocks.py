#!/usr/bin/env python3
"""Heuristic bronze tactic-block parser. Not Lean-certified."""
import argparse, json, re, pathlib
TACTIC_RE = re.compile(r'^\s*(·\s*)?([A-Za-z_][A-Za-z0-9_!?]*)(.*)$')
def parse_lines(text, file):
    for i,line in enumerate(text.splitlines(),1):
        m=TACTIC_RE.match(line)
        if not m: continue
        tac=m.group(2)
        if tac in {'theorem','lemma','def','import','open','namespace','section','end'}: continue
        yield {"source_file":file,"source_line":i,"tactic":line.strip(),"tactic_family":tac,"extraction_status":"source_heuristic_no_state","state_before":None,"state_after":None,"graph_delta":{},"used_premises":[]}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('paths', nargs='+'); ap.add_argument('--out', required=True); args=ap.parse_args()
    with open(args.out,'w',encoding='utf-8') as out:
        for p in args.paths:
            path=pathlib.Path(p)
            for file in ([path] if path.is_file() else path.rglob('*.lean')):
                for rec in parse_lines(file.read_text(encoding='utf-8', errors='ignore'), str(file)):
                    out.write(json.dumps(rec, ensure_ascii=False)+'\n')
if __name__=='__main__': main()
