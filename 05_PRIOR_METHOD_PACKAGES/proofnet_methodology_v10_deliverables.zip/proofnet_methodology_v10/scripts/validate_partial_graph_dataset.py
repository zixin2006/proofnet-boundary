#!/usr/bin/env python3
"""Validator for ProofNet partial graph and trace JSONL files."""
import argparse, json, sys

def validate_record(r):
    errs=[]
    if r.get('schema_version') == 'proofnet-trace-step-1.0':
        for k in ['state_before','tactic','lean_result','graph_delta']:
            if k not in r: errs.append(f'missing {k}')
        if r.get('lean_result') == 'success' and r.get('state_after') is None:
            errs.append('success record has null state_after')
        if r.get('quality_tier') in {'silver','gold','search'} and r.get('state_before') is None:
            errs.append('silver/gold/search record has null state_before')
    elif r.get('schema_version') == 'proofnet-partial-graph-1.0':
        g=r.get('graph',{})
        node_ids={n.get('id') for n in g.get('nodes',[])}
        for e in g.get('edges',[]):
            if e.get('source') not in node_ids: errs.append('edge source missing')
            if e.get('target') not in node_ids: errs.append('edge target missing')
        for fid in g.get('open_frontier',[]):
            if fid not in node_ids: errs.append('frontier node missing')
    else:
        errs.append('unknown schema_version')
    return errs

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('files', nargs='+'); args=ap.parse_args(); bad=0; total=0
    for fn in args.files:
        for i,line in enumerate(open(fn, encoding='utf-8'),1):
            if not line.strip(): continue
            total+=1; r=json.loads(line); errs=validate_record(r)
            if errs:
                bad+=1; print(f'{fn}:{i}: '+ '; '.join(errs), file=sys.stderr)
    print(json.dumps({'records':total,'bad_records':bad}))
    sys.exit(1 if bad else 0)
if __name__=='__main__': main()
