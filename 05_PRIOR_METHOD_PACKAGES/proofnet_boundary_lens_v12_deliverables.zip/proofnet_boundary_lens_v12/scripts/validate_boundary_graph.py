#!/usr/bin/env python3
"""Validate ProofNet boundary graph JSONL invariants.

Checks beyond JSON schema:
  * every frontier node exists and is open-ish;
  * every open goal capsule points to exactly one frontier node;
  * verified edges have accepted certificates;
  * engineering IDs do not appear as model-visible labels by convention.
"""
from __future__ import annotations
import argparse, json, sys

VERIFIED_CERTS = {"accepted_lean_transition", "kernel_dependency", "same_session_mvar"}

def validate_graph(g):
    errors=[]
    nodes={n["id"]:n for n in g.get("nodes",[])}
    frontier=set(g.get("frontier",[]))
    for f in frontier:
        if f not in nodes:
            errors.append(f"frontier node missing: {f}")
        elif nodes[f].get("status") not in {"open","transported"}:
            errors.append(f"frontier node is not open: {f}")
    capsule_nodes=[c.get("node_id") for c in g.get("lean_boundary",{}).get("goal_capsules",[]) if c.get("certificate_status") in {"lean_mvar","matched_capsule","speculative"}]
    if set(capsule_nodes) != frontier:
        errors.append(f"frontier/capsule mismatch: frontier={sorted(frontier)} capsules={sorted(capsule_nodes)}")
    for ed in g.get("edges",[]):
        if ed.get("certificate") == "accepted_lean_transition":
            if ed.get("source") not in nodes and ed.get("source") not in frontier:
                errors.append(f"edge source missing: {ed}")
            if ed.get("target") not in nodes and ed.get("target") not in frontier:
                errors.append(f"edge target missing: {ed}")
    return errors

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("jsonl")
    args=ap.parse_args()
    total=bad=0
    for line_no,line in enumerate(open(args.jsonl,encoding="utf-8"),1):
        if not line.strip(): continue
        total+=1
        g=json.loads(line)
        errs=validate_graph(g)
        if errs:
            bad+=1
            print(f"line {line_no} errors:")
            for e in errs: print("  -",e)
    print(json.dumps({"total":total,"bad":bad,"status":"PASS" if bad==0 else "FAIL"}))
    return 1 if bad else 0

if __name__=="__main__":
    raise SystemExit(main())
