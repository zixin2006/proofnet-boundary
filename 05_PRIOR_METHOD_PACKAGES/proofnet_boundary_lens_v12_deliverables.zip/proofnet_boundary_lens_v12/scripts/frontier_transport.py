#!/usr/bin/env python3
"""Boundary-lens frontier transport.

Order of trust:
  1. Same-session metavariable identity.
  2. Exact capsule equality up to alpha-normalized target/context.
  3. Minimum-cost target/context matching, marked as capsule_match.

The production extractor should prefer Lean MVarId transport whenever possible.
"""
from __future__ import annotations
import argparse, json
from typing import Dict, List, Tuple, Any

def capsule_key(c: Dict[str, Any]) -> Tuple[str, Tuple[str, ...], Tuple[str, ...]]:
    return (c.get("target_nf", ""), tuple(c.get("context_nf", [])), tuple(c.get("typeclass_snapshot", [])))

def cost(a: Dict[str, Any], b: Dict[str, Any]) -> float:
    if a.get("mvar_id") and a.get("mvar_id") == b.get("mvar_id"):
        return 0.0
    ca, cb = capsule_key(a), capsule_key(b)
    if ca == cb:
        return 0.05
    score = 0.0
    score += 0.5 if ca[0] != cb[0] else 0.0
    score += 0.25 * abs(len(ca[1]) - len(cb[1]))
    score += 0.25 if set(ca[1]) != set(cb[1]) else 0.0
    return score

def transport(before: List[Dict[str, Any]], after: List[Dict[str, Any]], consumed_node_ids: List[str], threshold: float = 0.3):
    after_unused = set(range(len(after)))
    result = []
    consumed = set(consumed_node_ids)
    # Exact MVarId first.
    for i, a in enumerate(before):
        if a.get("node_id") in consumed:
            continue
        for j in list(after_unused):
            b = after[j]
            if a.get("mvar_id") and a.get("mvar_id") == b.get("mvar_id"):
                result.append({"from": a["node_id"], "to": b["node_id"], "certificate": "same_session_mvar", "cost": 0.0})
                after_unused.remove(j)
                break
    # Greedy minimum cost for remaining capsules. Replace by Hungarian for scale.
    for a in before:
        if a.get("node_id") in consumed or any(r["from"] == a.get("node_id") for r in result):
            continue
        best = None
        for j in after_unused:
            c = cost(a, after[j])
            if best is None or c < best[0]:
                best = (c, j)
        if best and best[0] <= threshold:
            j = best[1]
            result.append({"from": a["node_id"], "to": after[j]["node_id"], "certificate": "capsule_match", "cost": best[0]})
            after_unused.remove(j)
    return result

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("before_json")
    ap.add_argument("after_json")
    ap.add_argument("--consumed", nargs="*", default=[])
    args = ap.parse_args()
    before = json.loads(open(args.before_json).read())
    after = json.loads(open(args.after_json).read())
    print(json.dumps(transport(before, after, args.consumed), indent=2))

if __name__ == "__main__":
    main()
