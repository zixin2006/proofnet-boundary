#!/usr/bin/env python3
"""Reference tactic-to-delta rules for the v1.2 methodology.

This is not a Lean extractor. It is the executable specification of graph delta
families used by the paper and by validators.
"""
from __future__ import annotations
import json, sys

def n(id, type, label, status="verified"):
    return {"id": id, "type": type, "label": label, "status": status, "features": {}, "model_visible": True}

def e(source, target, type, cert="accepted_lean_transition"):
    return {"source": source, "target": target, "type": type, "certificate": cert, "features": {}}

def rule_for(tactic: str, focused: str, new_goals=None):
    t = tactic.strip()
    fam = t.split()[0] if t else "unknown"
    tid = "tac." + fam
    new_goals = new_goals or []
    if fam in {"constructor", "left", "right"}:
        return {"nodes_added": [n(tid, "ConstructorSplit", fam)] + [n(g, "OpenGoal", g, "open") for g in new_goals],
                "edges_added": [e(focused, tid, "decomposes")] + [e(tid, g, "creates_subgoal") for g in new_goals],
                "nodes_updated": [{"id": focused, "status": "decomposed"}],
                "certificate_status": "accepted_lean_transition"}
    if fam in {"exact", "assumption", "rfl", "omega", "linarith", "ring", "aesop", "tauto", "contradiction"}:
        node_type = "AutomationBundle" if fam in {"omega", "linarith", "ring", "aesop", "tauto"} else "TacticStep"
        return {"nodes_added": [n(tid, node_type, t)], "edges_added": [e(tid, focused, "closes")],
                "nodes_updated": [{"id": focused, "status": "closed"}], "certificate_status": "accepted_lean_transition"}
    if fam in {"rw", "erw", "simp"}:
        return {"nodes_added": [n(tid, "Rewrite", t)], "edges_added": [e(focused, tid, "rewrites")],
                "nodes_updated": [{"id": focused, "status": "decomposed"}], "certificate_status": "accepted_lean_transition"}
    if fam in {"intro", "intros", "introsI"}:
        return {"nodes_added": [n(tid, "TacticStep", t)], "edges_added": [e(focused, tid, "introduces_hypothesis")],
                "nodes_updated": [], "certificate_status": "accepted_lean_transition"}
    if fam in {"have", "suffices"}:
        claim = new_goals[0] if new_goals else "goal.claim"
        return {"nodes_added": [n(tid, "IntermediateClaim", t), n(claim, "OpenGoal", claim, "open")],
                "edges_added": [e(focused, tid, "depends_on"), e(tid, claim, "creates_subgoal")],
                "nodes_updated": [], "certificate_status": "accepted_lean_transition"}
    return {"nodes_added": [n(tid, "TacticStep", t)], "edges_added": [e(focused, tid, "depends_on")],
            "nodes_updated": [], "certificate_status": "source_heuristic"}

if __name__ == "__main__":
    tactic = sys.argv[1] if len(sys.argv) > 1 else "constructor"
    print(json.dumps(rule_for(tactic, "goal.focus", sys.argv[2:]), indent=2))
