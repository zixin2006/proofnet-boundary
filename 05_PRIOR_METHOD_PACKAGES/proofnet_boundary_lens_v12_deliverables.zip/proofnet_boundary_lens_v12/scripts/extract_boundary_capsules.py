#!/usr/bin/env python3
"""Create boundary capsules from Lean-state JSON.

This is a Python-side reference implementation for v1.2 records. The production
extractor should compute the same fields inside Lean, but this script documents
exactly what the downstream data layer expects.
"""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from typing import Any, Dict, List

def alpha_name(name: str, index: int) -> str:
    return f"x{index}"

def normalize_expr_string(s: str) -> str:
    s = re.sub(r"\s+", " ", s.strip())
    # Engineering placeholder: production Lean code should traverse Expr.
    return s

def context_nf(local_context: List[Dict[str, Any]]) -> List[str]:
    out = []
    for i, decl in enumerate(local_context):
        typ = decl.get("type", {}).get("normalized") or decl.get("type", {}).get("pretty") or decl.get("type_normalized") or "?"
        out.append(f"{alpha_name(decl.get('user_name','_'), i)} : {normalize_expr_string(typ)}")
    return out

def capsule_for_goal(goal: Dict[str, Any], ordinal: int) -> Dict[str, Any]:
    target = goal.get("target", {}).get("normalized") or goal.get("target_nf") or goal.get("target", "?")
    ctx = goal.get("local_context") or []
    obj = {
        "capsule_id": f"cap.{ordinal}",
        "node_id": goal.get("node_id") or goal.get("node_id_hint") or f"goal.{ordinal}",
        "mvar_id": goal.get("mvar_id") or goal.get("engineering_id"),
        "target_nf": normalize_expr_string(target),
        "context_nf": context_nf(ctx) if isinstance(ctx, list) else ctx,
        "typeclass_snapshot": goal.get("typeclass_snapshot", []),
        "support_nodes": goal.get("support_nodes", []),
        "case_path": goal.get("case_path", []),
        "certificate_status": "lean_mvar"
    }
    return obj

def boundary_hash(capsules: List[Dict[str, Any]]) -> str:
    payload = json.dumps(capsules, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(payload.encode()).hexdigest()[:16]

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("jsonl", help="Trace JSONL containing state_before/state_after objects")
    ap.add_argument("--after", action="store_true", help="Use state_after instead of state_before")
    args = ap.parse_args()
    key = "state_after" if args.after else "state_before"
    for line in open(args.jsonl, encoding="utf-8"):
        rec = json.loads(line)
        state = rec.get(key) or {}
        goals = state.get("goals") or []
        caps = [capsule_for_goal(g, i) for i, g in enumerate(goals)]
        print(json.dumps({"theorem_id": rec.get("theorem_id"), "step_index": rec.get("step_index"), "boundary_hash": boundary_hash(caps), "goal_capsules": caps}, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
