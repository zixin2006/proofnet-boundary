# Visual index

This folder contains Graphviz-rendered PNG and PDF figures used in the methodology paper.

- `boundary_lens_architecture`: the global boundary-lens extraction architecture.
- `frontier_transport_and_exact`: controlled conjunction example showing stable frontier transport.
- `speculative_ai_stage`: intermediate AI stage with accepted, failed, and ghost/speculative tactics.
- `liquid_first_target_graph`: source-derived graph plan for Lean Liquid `first_target`.
- `liquid_challenge_graph`: source-derived graph plan for Lean Liquid `liquid_tensor_experiment`.
- `boundary_bisimulation`: guarded redundancy relation comparing only boundary-compatible graph states.

The Lean Liquid figures are bronze/source-derived plans, not real Lean-state traces. They become silver only after running a same-session extractor inside the pinned Lean project.
