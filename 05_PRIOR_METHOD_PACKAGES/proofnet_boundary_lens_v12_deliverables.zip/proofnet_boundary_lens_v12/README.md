# ProofNet Boundary-Lens Methodology v1.2

This package contains a research paper and engineering artifacts for automatically converting Lean tactic executions into Lean-certified partial proof-net-inspired boundary graphs.

Key files:

- `paper/ProofNet_Boundary_Lens_Methodology.pdf`
- `paper/ProofNet_Boundary_Lens_Methodology.tex`
- `reports/EUREKA_BOUNDARY_LENS_METHOD.md`
- `reports/MATHEMATICAL_FORMALISM.md`
- `reports/ENGINEERING_ALGORITHM.md`
- `reports/SAMPLE_GRAPHS_CONTROLLED_AND_FRONTIER.md`
- `reports/CONDENSED_MATH_CASE_STUDIES.md`
- `schemas/proofnet_boundary_graph_schema_v1_2.json`
- `schemas/proofnet_lens_trace_step_schema_v1_2.json`
- `data/example_controlled_and_partial_ai.jsonl`
- `data/example_liquid_tensor_boundary_traces.jsonl`
- `data/example_boundary_graphs.jsonl`
- `prompts/CODEX_V07_BOUNDARY_LENS_EXTRACTOR_PROMPT.md`

Caveat: the Lean Liquid examples are source-derived graph plans, not real silver traces, until the extractor is run inside the pinned Lean project.
