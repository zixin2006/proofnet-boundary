# Codex task: implement v0.7 Boundary-Lens ProofNet extractor

You are working in the current ProofNet Lean extraction package. Implement the next technical milestone:

```text
A same-session Lean extractor that records boundary capsules, frontier transport,
accepted/failure graph deltas, and cumulative partial proof graphs.
```

## Non-negotiable requirements

1. Do not use proof bodies as model input. Store:
   - formal_statement_header
   - proof_body_source
   - full_source_excerpt
   separately.

2. Maintain a persistent map:

```lean
rho : MVarId -> GraphNodeId
```

for open goals inside one Lean session.

3. Before every tactic, record:
   - all goals and focused goal;
   - target Expr;
   - local context declarations;
   - typeclass instances where visible;
   - metavariable IDs;
   - source span.

4. After every tactic, record the same data and compute frontier transport:
   - exact same-session MVarId transport first;
   - structural capsule matching only as fallback, marked weaker;
   - never consume all frontier goals for an ordinary focused tactic.

5. Implement graph delta rules for:

```text
intro/intros/introsI, exact, assumption, constructor, left, right,
apply, refine, have, suffices, let, rw/erw, simp, cases, rcases,
linarith, omega, ring, aesop, contradiction, exfalso
```

Automation tactics may emit coarse `AutomationBundle` nodes for now.

6. Produce JSONL conforming to:

```text
schemas/proofnet_boundary_graph_schema_v1_2.json
schemas/proofnet_lens_trace_step_schema_v1_2.json
```

7. Generate both success and failure records.

8. Add tests:
   - `constructor; exact h.right; exact h.left` must preserve the second goal node across step 1;
   - failed `exact h.left` on goal `q` must emit failure without changing frontier;
   - `rw [h]` and `rw [<- h]` must have different rewrite-direction features;
   - `have` must create an intermediate claim node.

9. Add a report explaining:
   - which edges are accepted-Lean certified;
   - which edges are proof-term/kernel certified;
   - which edges are source-derived or speculative;
   - which examples remain bronze.

## Stretch goal

Run the extractor on a pinned local copy of `lean-liquid` if available. If not available, emit source-only plans for `first_target` and `liquid_tensor_experiment` but do not label them silver.
