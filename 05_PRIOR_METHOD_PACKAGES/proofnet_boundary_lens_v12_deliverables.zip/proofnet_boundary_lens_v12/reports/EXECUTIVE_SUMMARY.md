# Executive summary: the boundary-lens eureka solution

The caveat was that a graph hash is unsafe and that partial graph identity breaks under Lean's dependent metavariable machinery. The proposed solution is not to make the graph hash smarter. The solution is to change the mathematical object.

**Eureka idea.** A partial proof-net graph should be a **boundary-typed open net**, i.e. a graph equipped with a Lean-certified interface of open goal capsules. The graph is not compared globally. It is compared only as a section over a normalized Lean boundary.

The state is therefore:

```text
B_i = (s_i, G_i, rho_i, partial_i)
```

where `partial_i` is the boundary/interface map from open Lean metavariable goals to open graph ports. A tactic transition is a **proof-net lens**:

```text
(s_i, G_i, rho_i) --t_i--> (s_{i+1}, G_{i+1}, rho_{i+1})
```

that performs three actions:

1. consumes or transforms the focused goal;
2. transports unchanged frontier ports by Lean metavariable identity or certified capsule matching;
3. glues in a local graph rewrite `DeltaG_i`.

This makes pruning safe only under the guarded key:

```text
PruningKey_i = (NormalizeLeanState(s_i), NormalizeBoundaryNet(G_i -> Boundary(s_i))).
```

The graph alone is never a sufficient state identifier.

Original contributions in this package:

- boundary-lens frontier transport for Lean tactic traces;
- goal capsules as proof-net ports indexed over Lean judgments;
- speculative ghost deltas for partially predicted AI tactics;
- delayed witness packets for existential/theorem-application steps, inspired by unification nets but adapted to Lean;
- a v1.2 schema separating certified, matched, speculative, source-only, and failure edges.

The condensed-mathematics examples are source-derived plans from `lean-liquid`. They are not claimed to be silver/gold traces until the extractor is run in the pinned Lean project.


## References used in this package

- Jean-Yves Girard, "Linear Logic," Theoretical Computer Science, 1987. Basis for proof nets and bureaucracy reduction.
- Dominic Hughes, "Unification nets: canonical proof net quantifiers," arXiv:1802.03224, 2018. Inspiration for delaying existential witnesses rather than prematurely branching on concrete witnesses.
- Chuck Liang and Dale Miller, "Focusing and Polarization in Intuitionistic Logic," arXiv:0708.2252, 2007. Inspiration for grouping deterministic phases and separating invertible/non-invertible proof search.
- Robert Simmons, "Structural focalization," arXiv:1109.6273, 2011. Focusing as a normal-form discipline for proof search.
- Hartmut Ehrig et al. and Habel--Muller--Plump, algebraic/DPO graph transformation. Inspiration for tactic deltas as local graph rewrites.
- Leonardo de Moura and Sebastian Ullrich, "The Lean 4 Theorem Prover and Programming Language," CADE 2021, and the Lean language reference. Basis for kernel-checked proof terms and tactic-state instrumentation.
- Kaiyu Yang et al., "LeanDojo: Theorem Proving with Retrieval-Augmented Language Models," arXiv:2306.15626, 2023. Existing state/premise extraction and programmatic Lean interaction; this project extends toward cumulative partial graph deltas.
- Mingzhe Wang et al., "Premise Selection for Theorem Proving by Deep Graph Embedding," arXiv:1709.09994, 2017. Formula graph representation precedent.
- Kshitij Bansal et al., "HOList," arXiv:1904.03241, 2019. Reinforcement-learning environment for higher-order theorem proving.
- Guillaume Lample et al., "HyperTree Proof Search," arXiv:2205.11491, 2022, and later best-first Lean proving work. Motivation for value/pruning/search records.
- leanprover-community/lean-liquid and the Liquid Tensor Experiment completion announcement. Source for condensed-mathematics examples.
