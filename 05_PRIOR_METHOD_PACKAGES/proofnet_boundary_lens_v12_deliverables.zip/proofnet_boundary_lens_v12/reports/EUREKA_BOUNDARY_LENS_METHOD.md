# Boundary-lens ProofNets: the core methodology

## 1. The problem with the old caveat

The old safe-pruning warning was correct but incomplete:

```text
graph hash alone is unsafe
```

That warning prevents a bad experiment, but it does not solve the scientific problem. The deeper issue is that a partial proof graph does not live by itself. In dependent type theory, every open goal is a judgment

```text
Gamma |- ?m : T
```

and its meaning depends on the local context, typeclass instances, metavariable assignments, universe constraints, and hidden elaborator choices. Hence two identical-looking graph shapes may denote different proof obligations.

## 2. The eureka solution

The graph must be treated as an open proof object **over a boundary**. The boundary is a finite family of goal capsules:

```text
cap(?m) = alpha(Gamma, T, typeclass_snapshot, support_nodes, case_path).
```

The partial graph is then a cospan-like object:

```text
ClosedCore(G_i)  <--  G_i  -->  Boundary(s_i)
```

or more simply:

```text
G_i with open ports labelled by Lean goal capsules.
```

Tactics act as **lenses** from one boundary to the next:

```text
Lens(t_i) : (G_i -> B_i)  ==>  (G_{i+1} -> B_{i+1}).
```

The lens has four parts:

1. `observe_before`: collect Lean goals, locals, typeclasses, and proof support;
2. `execute`: run the tactic or tactic skeleton;
3. `transport`: preserve unchanged open ports across the transition;
4. `rewrite`: add the tactic-specific graph delta.

## 3. Existing work vs. adaptation vs. original contribution

Proof nets motivate quotienting away bureaucratic ordering of independent inference rules. This project adapts that idea, but does not claim that Lean tactic traces are linear-logic proof nets.

Focusing motivates grouping deterministic phases and recording genuine choices. This project adapts focusing by marking graph regions as deterministic, choice, automation, or speculative.

Algebraic graph rewriting motivates local graph updates. This project adapts graph rewriting to Lean tactic transitions by requiring every verified rewrite edge to come from a Lean-accepted transition or kernel dependency.

LeanDojo already extracts Lean proof-state and premise information. This project's original addition is a persistent cumulative graph with frontier transport and boundary-guarded canonicalization.

## 4. Delayed witnesses

A key mathematical trick comes from the proof-net literature on quantifier witnesses: do not force the graph to commit to a witness too early. In Lean terms, a tactic such as

```text
refine < ?a, ?b >
```

or a theorem application producing existential data should create **witness ports** first. Concrete terms are attached later when Lean elaboration or a subsequent tactic fills them. This is critical for search because many branches differ only by premature witness choices.

## 5. Speculative ghost deltas for AI search

When an AI proposes an incomplete tactic skeleton, the system creates a ghost delta:

```text
status = speculative
certificate = speculative
```

Then Lean execution either promotes it:

```text
speculative -> accepted_lean_transition
```

or converts it into a failure branch:

```text
speculative -> failure
```

This allows the dataset to represent the intermediate stage of proof search, where the model knows the proof geometry before it knows every term.


## References used in this package

- Jean-Yves Girard, "Linear Logic," Theoretical Computer Science, 1987. Basis for proof nets and bureaucracy reduction.
- Dominic Hughes, "Unification nets: canonical proof net quantifiers," arXiv:1802.03224, 2018. Inspiration for delaying existential witnesses rather than prematurely branching on concrete witnesses.
- Chuck Liang and Dale Miller, "Focusing and Polarization in Intuitionistic Logic," arXiv:0708.2252, 2007. Inspiration for grouping deterministic phases and separating invertible/non-invertible proof search.
- Robert Simmons, "Structural focalization," arXiv:1109.6273, 2011. Focusing as a normal-form discipline for proof search.
- Hartmut Ehrig et al. and Habel--Muller--Plump, algebraic/DPO graph transformation. Inspiration for tactic deltas as local graph rewrites.
- Leonardo de Moura and Sebastian Ullrich, "The Lean 4 Theorem Prover and Programming Language," CADE 2021, and the Lean language reference. Basis for kernel-checked proof terms and tactic-state instrumentation.
- Kaiyu Yang et al., "LeanDojo: Theorem Proving with Retrieval-Augmented Language Models," arXiv:2306.15626, 2023. Existing state/premise extraction and programmatic Lean interaction; this project extends toward cumulative partial graph deltas.
- Mingzhe Wang et al., "Premise Selection for Theorem Proving by Deep Graph Embedding," arXiv:1709.09994, 2017. Formula graph representation precedent.
- Kshitij Bansal et al., "HOList," arXiv:1904.03241, 2019. Reinforcement-learning environment for higher-order theorem proving.
- Guillaume Lample et al., "HyperTree Proof Search," arXiv:2205.11491, 2022, and later best-first Lean proving work. Motivation for value/pruning/search records.
- leanprover-community/lean-liquid and the Liquid Tensor Experiment completion announcement. Source for condensed-mathematics examples.
