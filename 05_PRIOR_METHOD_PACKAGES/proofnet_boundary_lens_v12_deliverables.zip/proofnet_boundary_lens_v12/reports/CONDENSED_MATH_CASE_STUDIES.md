# Condensed mathematics case studies: lean-liquid

## Source status

The examples here are taken from the public Lean Liquid Tensor Experiment repository and its completion announcement. They are **source-derived graph plans**, not silver/gold traces, because this environment did not run the Lean 3 project or collect real before/after states.

## Case study A: `first_target`

The `first_target` proof in `src/liquid.lean` is ideal for proof-net extraction because it consists of witness introduction, theorem specialization, isomorphism transport, rewriting, and final norm-map closure.

Graph motifs:

1. `intro m`: transforms a universal goal into a witness/exactness goal.
2. `obtain` from `thm95''`: creates a witness packet `k,K,hk,H`.
3. `obtain` from `H Z`: creates a second witness packet `c0,H`.
4. `use [k,K,hk,c0]`: fills existential ports and exposes the exactness goal.
5. `introsI`: introduces ordinary locals and typeclass instance nodes.
6. `specialize H S V`: specializes a theorem packet to current objects.
7. `let i := ...`: constructs an isomorphism node.
8. `refine H.of_iso i.symm _`: transports exactness across the isomorphism and creates a subgoal.
9. `rw` and final `apply` steps close the norm condition.

See `figures/png/liquid_first_target_graph.png`.

## Case study B: `liquid_tensor_experiment`

The main theorem proof in `src/challenge.lean` has a different graph geometry. The core abstraction is:

```text
Ext-vanishing goal
  -> is_zero criterion
  -> exact sequence / epi-isomorphism criterion
  -> laurent_measures.epi_and_is_iso
  -> definitional equality cleanup
```

This is a good frontier-math example because most of the proof is not low-level term construction. It is a chain of mathematical reductions through categorical and analytic infrastructure. The graph representation should capture that reduction spine.

See `figures/png/liquid_challenge_graph.png` and `data/example_liquid_tensor_boundary_traces.jsonl`.

## What a real silver extraction must add

For each step, the extractor must collect actual Lean states:

```text
state_before, state_after, focused goal, introduced locals,
proof-term constants, typeclass instances, metavariable transport
```

Until that happens, these examples should remain labelled `bronze_source` or `source_only`.


## References used in this package

- Jean-Yves Girard, "Linear Logic," Theoretical Computer Science, 1987. Basis for proof nets and bureaucracy reduction.
- Dominic Hughes, "Unification nets: canonical proof net quantifiers," arXiv:1802.03224, 2018. Inspiration for delaying existential witnesses rather than prematurely branching on concrete witnesses.
- Chuck Liang and Dale Miller, "Focusing and Polarization in Intuitionistic Logic," arXiv:0708.2252, 2007. Inspiration for grouping deterministic phases and separating invertible/non-invertible proof search.
- Robert Simmons, "Structural focalization," arXiv:1109.6273, 2011. Focusing as a normal-form discipline for proof search.
- Hartmut Ehrig et al. and Habel--Muller--Plump, algebraic/DPO graph transformation. Inspiration for tactic deltas as local graph rewrites.
- Leonardo de Moura and Sebastian Ullrich, "The Lean 4 Theorem Prover and Programming Language," CADE 2021, and the Lean language reference. Basis for kernel-checked proof terms and tactic-state instrumentation.
- Kaiyu Yang et al., "LeanDojo: Theorem Proving with Retrieval-Augmented Language Models," arXiv:2306.15626, 2023. Existing state/premise extraction and programmatic Lean interaction; this project extends toward cumulative partial graph deltas.
- Mingzhe Wang et al., "Premise Selection for Theorem Proving by Deep Graph Embedding," arXiv:1709.09994, 2017. Formula graph representation precedent.
- Kshitij Bansal et al., "HOList," arXiv:1904.03241, 2019. Reinforcement-learning environment for higher-order theorem proving.
- Guillaume Lample et al., "HyperTree Proof Search," arXiv:2205.11491, 2022, and later best-first Lean proving work. Motivation for value/pruning/search records.
- leanprover-community/lean-liquid and the Liquid Tensor Experiment completion announcement. Source for condensed-mathematics examples.
