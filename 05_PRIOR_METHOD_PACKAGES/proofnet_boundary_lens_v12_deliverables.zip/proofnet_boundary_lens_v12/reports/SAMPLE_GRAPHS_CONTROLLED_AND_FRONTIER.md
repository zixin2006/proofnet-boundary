# Sample graphs: controlled theorem and partial AI stage

## Controlled conjunction theorem

Statement shape:

```text
p q : Prop, h : p AND q |- q AND p
```

Tactic schedule:

```text
constructor
exact h.right
exact h.left
```

The critical graph event is after `constructor`. The frontier contains two sibling ports: one for `q`, one for `p`. The next tactic `exact h.right` consumes only the focused `q` port. The `p` port is transported, not recreated.

See `figures/png/frontier_transport_and_exact.png` and `data/example_controlled_and_partial_ai.jsonl`.

## Partial AI stage

Suppose the model has not yet predicted the full proof and proposes three candidates:

```text
constructor
exact h.left
refine < ?_, ?_ >
```

The extractor records:

- `constructor` as a successful decomposition;
- `exact h.left` as a failure branch against the focused `q` goal;
- `refine < ?_, ?_ >` as a ghost tactic skeleton if allowed by Lean syntax, or as a speculative graph delta otherwise.

This is important because neural search often knows the proof geometry before it knows the exact witness terms.

## Equality/rewrite shape

For a schematic target

```text
h : a = b |- f a = f b
```

`tactic = rw [h]` should add a `Rewrite` node with direction, lemma source, before-expression, after-expression, and a boundary update. The rewrite edge is not interchangeable with `rw [<- h]`; direction must be preserved.


## References used in this package

- Jean-Yves Girard, "Linear Logic," Theoretical Computer Science, 1987. Basis for proof nets and bureaucracy reduction.
- Dominic Hughes, "Unification nets: canonical proof net quantifiers," arXiv:1802.03224, 2018. Inspiration for delaying existential witnesses rather than prematurely branching on concrete witnesses.
- Chuck Liang and Dale Miller, "Focusing and Polarization in Intuitionistic Logic," arXiv:0708.2252, 2007. Inspiration for grouping deterministic phases and separating invertible/non-invertible proof search.
- Robert Simmons, "Structural focalization," arXiv:1109.6273, 2011. Focusing as a normal-form discipline for proof search.
- Hartmut Ehrig et al. and Habel--Muller--Plump, algebraic/DPO graph transformation. Inspiration for tactic deltas as local graph rewrites.
- Leonardo de Moura and Sebastian Ullrich, "The Lean 4 Theorem Prover and Programming Language," CADE 2021, and the Lean language reference. Basis for kernel-checked proof terms and tactic-state instrumentation.
- Kaiyu Yang et al., "LeanDojo: Theorem Proving with Retrieval-Augmented Language Models," arXiv:2306.15626, 2023. Existing state/premise extraction and programmatic Lean interaction; this project extends toward cumulative partial graph deltas.
- Mingzhe Wang et al., "Premise Selection for Theorem Proving by Deep Graph Embedding," arXiv:1709.09994, 2017. Formula graph representation precedent.
- Kshitij Bansal et al., "HOList," arXiv:1904.03241, 2019. Reinforcement-learning environment for higher-order theorem proving.
- Guillaume Lample et al., "HyperTree Proof Search," arXiv:2205.11491, 2022, and later best-first Lean proving work. Motivation for value/pruning/search records.
- leanprover-community/lean-liquid and the Liquid Tensor Experiment completion announcement. Source for condensed-mathematics examples.
