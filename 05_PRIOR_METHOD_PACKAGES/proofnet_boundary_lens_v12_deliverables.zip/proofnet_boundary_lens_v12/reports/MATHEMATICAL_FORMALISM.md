# Mathematical formalism

## Definition 1: Lean boundary

A Lean boundary is a finite family

```text
B = { c_j }_{j in J}
```

where each capsule is an alpha-normalized judgment

```text
c_j = (Gamma_j |- ?m_j : T_j, I_j, S_j, P_j).
```

Here `I_j` is a typeclass and instance snapshot, `S_j` is the set of graph support nodes on which the goal depends, and `P_j` is a case path.

Metavariable IDs are engineering identifiers and must not be model-visible features.

## Definition 2: Boundary-typed partial proof graph

A boundary-typed partial proof graph is

```text
G = (V, E, tau, ell, sigma, rho, partial)
```

where:

- `V` is a finite set of nodes;
- `E` is a finite set of typed directed hyperedges or directed edges;
- `tau` maps nodes to node types;
- `ell` stores normalized labels and expression fingerprints;
- `sigma` maps nodes to statuses: open, closed, decomposed, verified, failed, speculative, transported;
- `rho` maps stable Lean metavariable IDs to graph nodes when available;
- `partial` maps every open boundary capsule to exactly one open graph port.

The frontier invariant is:

```text
for every open Lean goal in s_i, there exists exactly one open frontier node in G_i, and conversely.
```

## Definition 3: ProofNet lens

For an accepted tactic transition

```text
s_i --t_i--> s_{i+1},
```

a ProofNet lens is a partial graph rewrite

```text
L_i = (match_i, transport_i, delta_i, certify_i)
```

such that

```text
G_{i+1} = G_i union_{boundary} DeltaG_i.
```

`match_i` identifies the focused goal and relevant local objects. `transport_i` maps unchanged frontier ports forward. `delta_i` adds tactic-specific nodes and edges. `certify_i` assigns the strongest valid certificate level.

## Proposition 1: Frontier preservation

If `ExtractDelta` creates one new open graph port for every new open Lean goal, transports every unchanged Lean goal to exactly one old graph port, and marks every consumed focused goal as closed or decomposed, then the frontier invariant holds at `i+1`.

Proof sketch. Partition open goals after the tactic into transported goals and newly created goals. Transport is injective by same-session metavariable identity or by a one-to-one capsule matching. New goal creation is by construction one-to-one. Consumed goals are removed from the frontier. Therefore every open Lean goal has exactly one graph node, and every frontier node is associated with an open Lean goal.

## Proposition 2: Guarded redundancy is sound as a pruning heuristic

Let

```text
Key(s,G) = (NF_Lean(s), NF_boundary(G -> Boundary(s))).
```

If two search branches have the same key, then they have the same normalized open Lean obligations and the same boundary-relative proof geometry. Pruning one branch is still a heuristic, because future proof terms may differ, but the key avoids the unsound merge caused by graph-only hashing.

## The original mathematical move

The original move is to regard proof-net canonicalization as a **fiberwise quotient**. One never quotients all graphs at once. Instead, for each Lean boundary `B`, one considers only graphs lying over `B` and quotients them by boundary-preserving isomorphisms and independent-sibling permutations.

This converts the caveat into a design principle:

```text
proof geometry is quotientable only relative to a dependent boundary.
```


## References used in this package

- Jean-Yves Girard, "Linear Logic," Theoretical Computer Science, 1987. Basis for proof nets and bureaucracy reduction.
- Dominic Hughes, "Unification nets: canonical proof net quantifiers," arXiv:1802.03224, 2018. Inspiration for delaying existential witnesses rather than prematurely branching on concrete witnesses.
- Chuck Liang and Dale Miller, "Focusing and Polarization in Intuitionistic Logic," arXiv:0708.2252, 2007. Inspiration for grouping deterministic phases and separating invertible/non-invertible proof search.
- Robert Simmons, "Structural focalization," arXiv:1109.6273, 2011. Focusing as a normal-form discipline for proof search.
- Hartmut Ehrig et al. and Habel--Muller--Plump, algebraic/DPO graph transformation. Inspiration for tactic deltas as local graph rewrites.
- Leonardo de Moura and Sebastian Ullrich, "The Lean 4 Theorem Prover and Programming Language," CADE 2021, and the Lean language reference. Basis for kernel-checked proof terms and tactic-state instrumentation.
- Kaiyu Yang et al., "LeanDojo: Theorem Proving with Retrieval-Augmented Language Models," arXiv:2306.15626, 2023. Existing state/premise extraction and programmatic Lean interaction; this project extends toward cumulative partial graph deltas.
- Mingzhe Wang et al., "Premise Selection for Theorem Proving by Deep Graph Embedding," arXiv:1709.09994, 2017. Formula graph representation precedent.
- Kshitij Bansal et al., "HOList," arXiv:1904.03241, 2019. Reinforcement-learning environment for higher-order theorem proving.
- Guillaume Lample et al., "HyperTree Proof Search," arXiv:2205.11491, 2022, and later best-first Lean proving work. Motivation for value/pruning/search records.
- leanprover-community/lean-liquid and the Liquid Tensor Experiment completion announcement. Source for condensed-mathematics examples.
