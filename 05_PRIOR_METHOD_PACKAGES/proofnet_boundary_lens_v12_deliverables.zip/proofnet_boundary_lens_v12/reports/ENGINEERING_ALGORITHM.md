# Engineering algorithm

## Algorithm: LeanToBoundaryProofNet

Input:

```text
Lean declaration D
formal statement header
proof body or interactive candidate tactics
```

Output:

```text
JSONL trace records with boundary capsules, graph deltas, transport maps, and certificates
```

Procedure:

```text
1. Extract declaration header and imports.
   Store proof_body separately. Never use proof_body as model input.

2. Start one Lean session for the declaration.
   Same-session execution is preferred because MVarId transport is exact.

3. Before each tactic:
   collect open goals, focused goal, local context, typeclass instances,
   metavariable IDs, target Exprs, local declaration Exprs, and source span.

4. Construct Boundary(s_i):
   alpha-normalize local names, structurally normalize expressions,
   record typeclass snapshot, support nodes, and case path.

5. Execute the tactic or tactic skeleton.

6. If Lean rejects it:
   emit a failure branch with unchanged frontier and failure edge.

7. If Lean accepts it:
   collect Boundary(s_{i+1}); compute frontier transport:
     a. exact same-session MVarId matching;
     b. if unavailable, capsule matching with explicit certificate downgrade;
     c. if ambiguous, split or mark non-prunable.

8. Run tactic-family ExtractDelta:
   intro/introsI     -> introduces_hypothesis, typeclass_instance
   exact/assumption  -> closes focused goal
   constructor       -> decomposes and creates sibling ports
   apply/refine      -> applies lemma, creates required subgoals
   have/suffices     -> creates intermediate claim and dependency edge
   cases/rcases      -> splits_case, introduces hypotheses/witnesses
   rw/erw/simp       -> rewrite or automation bundle
   linarith/ring     -> coarse automation bundle unless proof certificate exposed

9. Update cumulative graph:
   G_{i+1} = G_i union DeltaG_i with frontier replacement by transport/new ports.

10. Validate:
   every open Lean goal has exactly one open frontier node;
   no proof leakage in formal_statement_header;
   verified edges have accepted Lean or kernel certificates;
   model-visible features do not contain engineering IDs.
```

## Certificate levels

- `accepted_lean_transition`: the edge is implied by a successful tactic before/after transition.
- `kernel_dependency`: proof-term inspection shows an actual dependency.
- `same_session_mvar`: a frontier transport is certified by identical Lean metavariable ID.
- `capsule_match`: transport was reconstructed by normalized goal matching; useful but weaker.
- `source_heuristic`: source parser or tactic schedule only.
- `speculative`: AI-proposed but not Lean-promoted.
- `failure`: Lean rejected the branch.

## Production architecture

```text
Lean side:
  ProofNet.Capsule
  ProofNet.Trace
  ProofNet.Transport
  ProofNet.DeltaRules
  ProofNet.JsonlWriter

Python side:
  schema validation
  dataset splitting
  search-record aggregation
  graph visualization
  model feature extraction
```

The strongest recommendation is to write JSONL directly from Lean rather than parsing JSON from log output.


## References used in this package

- Jean-Yves Girard, "Linear Logic," Theoretical Computer Science, 1987. Basis for proof nets and bureaucracy reduction.
- Dominic Hughes, "Unification nets: canonical proof net quantifiers," arXiv:1802.03224, 2018. Inspiration for delaying existential witnesses rather than prematurely branching on concrete witnesses.
- Chuck Liang and Dale Miller, "Focusing and Polarization in Intuitionistic Logic," arXiv:0708.2252, 2007. Inspiration for grouping deterministic phases and separating invertible/non-invertible proof search.
- Robert Simmons, "Structural focalization," arXiv:1109.6273, 2011. Focusing as a normal-form discipline for proof search.
- Hartmut Ehrig et al. and Habel--Muller--Plump, algebraic/DPO graph transformation. Inspiration for tactic deltas as local graph rewrites.
- Leonardo de Moura and Sebastian Ullrich, "The Lean 4 Theorem Prover and Programming Language," CADE 2021, and the Lean language reference. Basis for kernel-checked proof terms and tactic-state instrumentation.
- Kaiyu Yang et al., "LeanDojo: Theorem Proving with Retrieval-Augmented Language Models," arXiv:2306.15626, 2023. Existing state/premise extraction and programmatic Lean interaction; this project extends toward cumulative partial graph deltas.
- Mingzhe Wang et al., "Premise Selection for Theorem Proving by Deep Graph Embedding," arXiv:1709.09994, 2017. Formula graph representation precedent.
- Kshitij Bansal et al., "HOList," arXiv:1904.03241, 2019. Reinforcement-learning environment for higher-order theorem proving.
- Guillaume Lample et al., "HyperTree Proof Search," arXiv:2205.11491, 2022, and later best-first Lean proving work. Motivation for value/pruning/search records.
- leanprover-community/lean-liquid and the Liquid Tensor Experiment completion announcement. Source for condensed-mathematics examples.
