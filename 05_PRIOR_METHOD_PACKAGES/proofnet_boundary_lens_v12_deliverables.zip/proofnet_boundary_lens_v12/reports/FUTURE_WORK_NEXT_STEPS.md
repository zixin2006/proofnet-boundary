# Next steps

## Immediate next step: v0.7 boundary-lens extractor

Build a same-session Lean extractor that maintains the boundary map throughout a declaration.

Minimum success criteria:

1. exact MVarId frontier transport in same Lean session;
2. graph delta rules for `intro`, `constructor`, `exact`, `apply`, `refine`, `have`, `rw`, `cases`, `rcases`, `let`, `simp`, `linarith`;
3. JSONL output with v1.2 schema;
4. controlled tests for multi-goal identity preservation;
5. failure branch records;
6. no proof leakage from `:= by` in model inputs.

## Next controlled experiments

- conjunction/disjunction/exists examples with multiple independent siblings;
- rewrite direction and simplifier examples;
- `have`/`suffices` intermediate claim examples;
- theorem application with existential witness packets;
- automation examples where dependency is coarse but verified.

## Frontier pilot

Run on a pinned copy of `lean-liquid` or a modern Lean 4 frontier project. Start with tiny subproofs, not the whole repository.

Recommended first frontier scripts:

- `first_target` from `lean-liquid`, because it is short and contains many useful graph motifs;
- `liquid_tensor_experiment`, because it shows high-level reduction spine;
- a PFR theorem from the existing package only after the repository builds and state traces are real.

## Modeling experiments

Train three ablations:

1. state-only tactic model;
2. graph-only auxiliary embedding, never used for pruning alone;
3. boundary-graph model using the guarded key.

The first scientific claim should be modest:

```text
Does boundary-graph conditioning reduce repeated exploration on controlled theorem families beyond normalized state alone?
```

Only after this should the project claim frontier-scale benefit.


## References used in this package

- Jean-Yves Girard, "Linear Logic," Theoretical Computer Science, 1987. Basis for proof nets and bureaucracy reduction.
- Dominic Hughes, "Unification nets: canonical proof net quantifiers," arXiv:1802.03224, 2018. Inspiration for delaying existential witnesses rather than prematurely branching on concrete witnesses.
- Chuck Liang and Dale Miller, "Focusing and Polarization in Intuitionistic Logic," arXiv:0708.2252, 2007. Inspiration for grouping deterministic phases and separating invertible/non-invertible proof search.
- Robert Simmons, "Structural focalization," arXiv:1109.6273, 2011. Focusing as a normal-form discipline for proof search.
- Hartmut Ehrig et al. and Habel--Muller--Plump, algebraic/DPO graph transformation. Inspiration for tactic deltas as local graph rewrites.
- Leonardo de Moura and Sebastian Ullrich, "The Lean 4 Theorem Prover and Programming Language," CADE 2021, and the Lean language reference. Basis for kernel-checked proof terms and tactic-state instrumentation.
- Kaiyu Yang et al., "LeanDojo: Theorem Proving with Retrieval-Augmented Language Models," arXiv:2306.15626, 2023. Existing state/premise extraction and programmatic Lean interaction; this project extends toward cumulative partial graph deltas.
- Mingzhe Wang et al., "Premise Selection for Theorem Proving by Deep Graph Embedding," arXiv:1709.09994, 2017. Formula graph representation precedent.
- Kshitij Bansal et al., "HOList," arXiv:1904.03241, 2019. Reinforcement-learning environment for higher-order theorem proving.
- Guillaume Lample et al., "HyperTree Proof Search," arXiv:2205.11491, 2022, and later best-first Lean proving work. Motivation for value/pruning/search records.
- leanprover-community/lean-liquid and the Liquid Tensor Experiment completion announcement. Source for condensed-mathematics examples.
