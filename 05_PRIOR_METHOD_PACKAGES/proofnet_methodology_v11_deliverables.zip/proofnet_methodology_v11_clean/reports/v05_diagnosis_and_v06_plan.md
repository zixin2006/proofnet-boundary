
# v0.5 Diagnosis and v0.6/V1.1 Methodology Plan

The v0.5 extractor is a genuine silver MVP for controlled Lean examples: it records real `state_before`, `tactic`, `state_after`, success/failure status, and graph-delta-like records. It also separates `formal_statement_header` from the proof body, avoiding direct `:= by` leakage.

The key remaining defect is frontier identity. In multi-goal states, v0.5 treats all open frontier nodes as consumed by a normal focused tactic. The corrected semantics is a boundary-local graph rewrite: the focused goal is consumed/transformed, newly generated goals are added, and unchanged sibling goals are transported with stable node identity. The state carrier is not just `(s_i, G_i)` but `(s_i, G_i, rho_i)`, where `rho_i : LeanGoalHandle -> GraphNodeId` is the persistent frontier map.

The next extractor should run each declaration in a single Lean session rather than reconstructing each step from replayed prefixes. Same-session extraction can preserve Lean metavariable identities, local declaration identities, source spans, and InfoTree/proof-term context. Replay fallback should be explicitly lower-confidence and use conservative structural matching only when MVarIds are unavailable.

Bronze data remains useful for source-level pretraining and target selection. Silver data supports graph-delta learning. Gold data enriches silver traces with proof-term/kernel dependencies. Search-branch data adds positive and negative candidate tactics for pruning/value/compatibility models. PFR and the Equational Theories Project should remain bronze until the extractor runs inside the actual pinned repositories.
