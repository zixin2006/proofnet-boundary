
# Codex prompt: implement same-session frontier transport extractor

Use the current `proofnet_state_extractor_v05` project as the starting point. Implement a v0.6 extractor whose central invariant is:

`every open Lean goal in the state corresponds to exactly one open frontier graph node, and every open frontier graph node corresponds to exactly one open Lean goal.`

Do not rely on theorem IDs, expected theorem families, manually named graph nodes, or graph node IDs as model features. Keep them only as audit metadata.

Core engineering tasks:

1. Replace prefix-replay graph identity with same-session frontier transport. Maintain `rho : MVarId -> GraphNodeId` across the full declaration run. For normal tactics, consume only the focused goal. Preserve unchanged sibling goals with their existing graph node ID.
2. Record `state_before`, `tactic`, `state_after`, `goal_transport`, `frontier_before`, `frontier_after`, `graph_delta`, `graph_before_hash`, and `graph_after_hash` for each tactic.
3. Separate source-level declaration fields: `formal_statement_header`, `proof_body_source`, and `full_declaration_source`. For any model-input record, reject a `formal_statement_header` containing `:= by`.
4. Replace pretty-string normalization with structural Lean expression serialization: constants, applications, binders, projections, lets, local variables by binder order, metavariables by role, universes, and display strings only for debugging.
5. Implement tactic-specific delta rules for `intro/intros`, `exact`, `assumption`, `apply`, `refine`, `constructor`, `left/right`, `cases/rcases`, `induction`, `have`, `suffices`, `let`, `rw`, `simp`, `rfl`, `ext`, `omega`, `linarith`, `ring`, `aesop`, `tauto`, `contradiction`, and `exfalso`. Mark automation internals as `AutomationBundle` unless Lean traces or proof terms expose verified internal dependencies.
6. Generate failure records for candidate tactics. On failure, preserve the pre-state, set `state_after` and `graph_after_hash` to null, and include `error_excerpt`, `failure_type`, and a candidate-only unverified delta.
7. Validate against `proofnet_trace_step_schema_v1_1.json` and `proofnet_partial_graph_schema_v1_1.json`. Add tests that specifically catch the v0.5 bug: after `constructor; exact h.right`, the remaining `p` goal must preserve node identity.
8. Start with controlled synthetic examples. Then run a small pinned PFR pilot only inside the real `teorth/pfr` Lake project; do not promote PFR records to silver without real `state_before`/`state_after`.

Report exactly which edges are Lean-state-derived, which are proof-term-derived, and which are source-parser bronze annotations. Do not silently coerce source-derived graph guesses into verified graph edges.
