# Codex Prompt: v0.8 Real State-only vs State+Boundary-Graph Search Comparison

Use the v0.7 Boundary-Lens extractor output. Build a small proof-search harness with two modes:

1. normalized Lean state only;
2. normalized Lean state plus Boundary-Lens graph features.

Run on the controlled suite first. Measure duplicate frontier expansions, failed candidate rate, total accepted transitions, time to proof, and number of candidate evaluations. Do not use graph hash alone; use `(NormalizeLeanState, CanonicalizeBoundaryGraph over boundary)`.

The experiment is valid only if all v0.7 invariants pass first, especially sibling-goal preservation.
