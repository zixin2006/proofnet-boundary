import ProofNet.Boundary.TacticWrapper
example (p q : Prop) (h : p ∧ q) : q ∧ p := by
  proofnet_step "constructor"
  proofnet_step "exact h.right"
  proofnet_step "exact h.left"
example (p q : Prop) (hp : p) : p ∨ q := by
  proofnet_step "left"
  proofnet_step "exact hp"
