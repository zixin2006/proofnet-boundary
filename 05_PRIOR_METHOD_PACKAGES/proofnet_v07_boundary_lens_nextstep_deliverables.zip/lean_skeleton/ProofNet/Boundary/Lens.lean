/- Frontier transport skeleton for v0.7. Production code should use real Lean MVarIds. -/
namespace ProofNet.Boundary
abbrev MVarKey := String
abbrev GraphNodeId := String
structure FrontierTransport where
  rhoAfter : List (MVarKey × GraphNodeId)
  consumed : List MVarKey
  preserved : List MVarKey
  newlyCreated : List MVarKey
  unexpectedlyRemovedSiblings : List MVarKey
  deriving Repr, Inhabited
end ProofNet.Boundary
