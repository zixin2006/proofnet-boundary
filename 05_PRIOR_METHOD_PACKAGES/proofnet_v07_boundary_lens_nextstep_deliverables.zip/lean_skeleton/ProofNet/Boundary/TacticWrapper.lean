/- Tactic wrapper skeleton. Codex should implement this in Lean 4 TacticM. -/
namespace ProofNet.Boundary
syntax (name := proofnetStep) "proofnet_step " str : tactic
-- Desired behavior:
--   capture state_before; parse/evaluate the tactic string in the same session;
--   capture state_after; update rho; emit JSONL.
end ProofNet.Boundary
