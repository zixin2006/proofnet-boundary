/- Boundary capsule skeleton for v0.7. This file is a design target; it is not compiled in this container. -/
namespace ProofNet.Boundary
structure LocalDeclCapsule where
  fvarId : String
  userName : String
  typePretty : String
  typeStructuralHash : String
  binderInfo : String := "default"
  isImplementationDetail : Bool := false
  deriving Inhabited, Repr
structure BoundaryCapsule where
  mvarId : String
  graphNodeId : String
  targetPretty : String
  targetStructuralHash : String
  localContext : List LocalDeclCapsule
  typeclassInstances : List String := []
  universeContext : List String := []
  boundaryHash : String
  deriving Inhabited, Repr
end ProofNet.Boundary
