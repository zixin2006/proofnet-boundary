# Redundancy Experiments

## Purpose

The redundancy experiment is a symbolic sanity check for the core ProofNet hypothesis. It is not a neural model evaluation and not a Lean prover benchmark.

## Experiment

For `k` independent frontier obligations:

```text
state-only sequence search may see k! successful linearizations
Boundary-Lens graph stores one partial-order class
```

The side condition is strict: the sibling goals must have disjoint dependency support.

## Results

```text
k=1: 1 -> 1
k=2: 2 -> 1
k=3: 6 -> 1
k=4: 24 -> 1
k=5: 120 -> 1
k=6: 720 -> 1
k=7: 5040 -> 1
```

The corresponding toy candidate-evaluation factors are factorial because the toy baseline repeats candidate evaluation under every duplicate linearization. This demonstrates the kind of redundancy a proof-net graph can target.

## Caveat

A strong state-only neural model may learn parts of this pattern. The real scientific test must compare:

```text
normalized Lean state only
vs.
normalized Lean state + Boundary-Lens graph
```

on the same search loop and theorem set.
