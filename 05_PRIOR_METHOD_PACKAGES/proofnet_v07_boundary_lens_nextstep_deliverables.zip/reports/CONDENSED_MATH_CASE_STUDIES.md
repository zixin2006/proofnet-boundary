# Condensed-Mathematics Case Studies

These records are bronze/source-derived graph plans from the Lean Liquid Tensor Experiment, not same-session Lean state traces.

## `first_target`

The source proof uses the following high-level schedule:

```text
intro m
obtain k,K,hk,H from thm95''
obtain c0,H from H Z
use [k,K,hk,c0]
introsI S hS V hV
specialize H S V
let i be a map isomorphism
refine H.of_iso i.symm _
rw a system_of_complexes hom identity
apply norm-nonincreasing lemmas
```

Boundary-Lens motif:

```text
delayed witness packet -> existential construction -> specialization -> isomorphism transport -> final norm closure
```

## `liquid_tensor_experiment`

The source proof uses:

```text
intros i hi
apply is_zero.iso_zero
revert i
haveI positivity facts
erw is_zero_iff_epi_and_is_iso using short exactness
choose structures on V
convert laurent_measures.epi_and_is_iso
intro v
rw normalization lemmas
```

Boundary-Lens motif:

```text
Ext-isomorphism goal -> is_zero criterion -> epi/isomorphism reduction -> structure choice -> Laurent-measures theorem -> residual rewrite
```

## Promotion criterion

These examples become silver only when a Lean-side extractor records true `state_before`, `state_after`, `rho_before`, `rho_after`, and graph deltas inside the pinned Lean Liquid project.
