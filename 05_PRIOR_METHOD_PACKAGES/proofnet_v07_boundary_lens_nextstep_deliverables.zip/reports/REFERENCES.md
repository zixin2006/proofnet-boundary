# References

- Girard, Jean-Yves. *Linear Logic*. Theoretical Computer Science, 1987.
- Andreoli, Jean-Marc. *Logic Programming with Focusing Proofs in Linear Logic*. Journal of Logic and Computation, 1992.
- Hughes, Dominic J. D. *Unification nets: canonical proof net quantifiers*. arXiv:1802.03224.
- The Lean Language Reference. https://lean-lang.org/doc/reference/latest/
- Yang et al. *LeanDojo: Theorem Proving with Retrieval-Augmented Language Models*. arXiv:2306.15626.
- Lample et al. *HyperTree Proof Search for Neural Theorem Proving*. arXiv:2205.11491.
- Yang and Deng. *Learning to Prove Theorems via Interacting with Proof Assistants*. arXiv:1905.09381.
- Wang et al. *Premise Selection for Theorem Proving by Deep Graph Embedding*. arXiv:1709.09994.
- Kripner, Sustr, Straka. *LeanTree: Accelerating White-Box Proof Search with Factorized States in Lean 4*. arXiv:2507.14722.
- Lean Liquid Tensor Experiment repository. https://github.com/leanprover-community/lean-liquid
