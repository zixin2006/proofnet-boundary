# Executive Summary: v0.7 Boundary-Lens Immediate Next Step

This package performs the immediate next step toward a real same-session Boundary-Lens extractor. Since Lean/Lake is not installed in this container, it does **not** claim to run a fresh Lean 4 same-session extractor here. Instead, it implements the v0.7 reference algorithm, repairs available v0.5 tactic-state traces into Boundary-Lens records, validates the core invariants, and produces redundancy diagnostics and frontier bronze plans.

## Main technical result

The key repair is persistent frontier transport:

```text
rho_i : MVarId -> GraphNodeId
```

For ordinary focused tactics, only the focused goal is consumed. Unchanged sibling goals preserve their graph node identity. This fixes the main caveat identified in v0.5.

## Validation

```text
trace_records: 15
failure_records: 6
schema_errors: 0
frontier_invariant: PASS
sibling_goal_preservation: PASS
```

The conjunction regression passes: after `constructor`, the `exact h.right` step closes only the `q` goal and preserves the same graph node for the `p` sibling goal.

## ProofNet search-redundancy insight

For `k` independent sibling goals, sequence search may see `k!` successful linearizations, whereas a proof-net-style boundary graph stores one partial-order class when dependency supports are disjoint. The toy harness reports:

```text
k=4: 24 linearizations -> 1 net class
k=6: 720 linearizations -> 1 net class
k=7: 5040 linearizations -> 1 net class
```

This is a symbolic combinatorics sanity check, not a trained neural prover result.

## Frontier samples

The package includes bronze/source-derived graph plans for Lean Liquid:

- `first_target` from `src/liquid.lean`;
- `liquid_tensor_experiment` from `src/challenge.lean`.

They are not silver because no same-session Lean state was extracted inside the Lean Liquid repository.
