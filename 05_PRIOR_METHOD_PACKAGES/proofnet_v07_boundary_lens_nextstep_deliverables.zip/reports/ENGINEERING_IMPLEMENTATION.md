# Engineering Implementation Report

## Implemented components

```text
scripts/boundary_lens_core.py
scripts/repair_v05_frontier_transport.py
scripts/validate_v07_records.py
scripts/run_redundancy_experiment.py
scripts/render_v07_graphs.py
```

## Data outputs

```text
data/v07_repaired_boundary_lens_trace_steps.jsonl
data/v07_boundary_graph_snapshots.jsonl
data/v07_failure_branches.jsonl
data/redundancy_experiment_results.json
data/condensed_math_source_plans.jsonl
```

## Schemas

```text
schemas/proofnet_lens_trace_step_schema_v0_7.json
schemas/proofnet_boundary_graph_schema_v0_7.json
```

## Key algorithmic fix

The v0.7 transport algorithm distinguishes:

```text
preserved goals    = goals_before intersection goals_after
new goals          = goals_after minus goals_before
removed goals      = goals_before minus goals_after
focused goal       = first active goal before the tactic
```

For focused tactics, only the focused goal may be consumed. If a sibling remains open, it keeps its graph node ID. This is the core correction over a naive state-diff graph.

## Failure branches

Failure records produce ghost deltas. Ghost deltas are stored for learning and pruning, but they are not merged into the verified graph.

## Current implementation status

This package is a Python reference implementation and v0.5 repair pass. It is not yet the full Lean-side same-session wrapper. The next step is to implement `proofnet_step` in Lean 4 and emit JSONL records directly from a single Lean session.
