# Mathematical Formalism

## Boundary-Lens state

A partial proof-search state is

```text
B_i = (s_i, G_i, rho_i, partial_i)
```

where `s_i` is a Lean tactic state, `G_i` is a cumulative typed graph, `rho_i` maps Lean metavariable goals to open graph nodes, and `partial_i` maps boundary capsules to open graph ports.

## Boundary capsule

For an open goal `m`, a capsule contains:

```text
mvar_id
local context Gamma_m
target expression T_m
structural hashes of Gamma_m and T_m
typeclass instances
universe context
graph frontier node id
```

The current implementation uses normalized pretty strings. The production implementation must use structural Lean expression hashes.

## Invariant

Every open Lean goal in `s_i` corresponds to exactly one open frontier node in `G_i`, and every open frontier node corresponds to one open Lean goal.

## Certified lens transition

A tactic transition is represented as:

```text
(s_i, G_i, rho_i, partial_i) --t_i--> (s_{i+1}, G_{i+1}, rho_{i+1}, partial_{i+1})
```

where:

```text
G_{i+1} = G_i union DeltaG_i
```

Edges are marked verified only if they come from accepted Lean transitions or proof-term/kernel/environment inspection.

## Boundary-indexed equivalence

Graph-only hashing is unsafe. The safe pruning key is:

```text
PruningKey(B_i) = (NormalizeLeanState(s_i), CanonicalizeBoundaryGraph(G_i -> Boundary(s_i)))
```

## Independent sibling quotient theorem

If a tactic creates sibling goals whose dependency supports are disjoint, and no later step in one sibling introduces data used by another, then all orders of completing the siblings commute. Thus `k!` sequence-level schedules collapse to one canonical boundary graph.

The theorem is deliberately conditional. It must not be applied when dependent witnesses, typeclass instances, or local declarations create cross-branch dependencies.
