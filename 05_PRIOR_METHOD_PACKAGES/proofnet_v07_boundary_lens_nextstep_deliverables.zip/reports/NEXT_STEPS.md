# Next Steps

1. Implement a real Lean 4 `proofnet_step` tactic wrapper.
2. Capture real `MVarId`, target expressions, local declarations, typeclass instances, and universe context.
3. Emit JSONL from the same Lean session rather than repairing traces after the fact.
4. Replace pretty-string hashes with structural `Lean.Expr` hashes.
5. Run the controlled regression suite and require sibling-goal preservation to pass.
6. Add proof-term enrichment for constants, recursors, constructors, projections, rewrite lemmas, and typeclass instances.
7. Run the first real search comparison: state-only model versus state-plus-boundary-graph model.
8. Run one pinned frontier pilot, preferably a small Mathlib theorem or a small Lean Liquid theorem that builds quickly.
9. Only promote frontier records to silver after real state extraction.
