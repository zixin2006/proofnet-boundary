#!/usr/bin/env python3
"""Toy redundancy experiment for Boundary-Lens proof nets.

This is not a neural experiment. It is a controlled search-combinatorics test:
for k independent frontier obligations, sequential search sees all k! possible
linearizations, while the proof-net boundary graph identifies a single partial
order class. The result is a sanity check for the proposed pruning target.
"""
from pathlib import Path
import argparse, json, math, itertools, csv

def experiment(max_goals: int):
    rows=[]
    for k in range(1, max_goals+1):
        state_only_success_traces = math.factorial(k)
        proofnet_equiv_classes = 1
        duplicate_traces = state_only_success_traces - proofnet_equiv_classes
        reduction = duplicate_traces / state_only_success_traces if state_only_success_traces else 0.0
        # Add a candidate-expansion model: each open leaf has one correct closing tactic
        # and two plausible wrong tactics. A naive scheduler tries candidates per leaf
        # for every linearization prefix; a graph-compatible scheduler caches the leaf
        # type/term compatibility and closes each leaf once.
        wrong_per_goal = 2
        state_only_candidate_evals = state_only_success_traces * k * (wrong_per_goal + 1)
        proofnet_candidate_evals = k * (wrong_per_goal + 1)  # one class
        rows.append({
            'independent_goals': k,
            'state_only_success_linearizations': state_only_success_traces,
            'proofnet_partial_order_classes': proofnet_equiv_classes,
            'duplicate_linearizations_pruned': duplicate_traces,
            'linearization_reduction_fraction': reduction,
            'state_only_candidate_evaluations_toy': state_only_candidate_evals,
            'proofnet_candidate_evaluations_toy': proofnet_candidate_evals,
            'candidate_eval_reduction_factor_toy': state_only_candidate_evals / proofnet_candidate_evals,
        })
    return rows

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--max-goals', type=int, default=7)
    ap.add_argument('--json', required=True)
    ap.add_argument('--csv', required=True)
    args=ap.parse_args()
    rows=experiment(args.max_goals)
    Path(args.json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.json).write_text(json.dumps({'description': __doc__, 'rows': rows}, indent=2), encoding='utf-8')
    with open(args.csv, 'w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(json.dumps(rows[-1], indent=2))
if __name__ == '__main__': main()
