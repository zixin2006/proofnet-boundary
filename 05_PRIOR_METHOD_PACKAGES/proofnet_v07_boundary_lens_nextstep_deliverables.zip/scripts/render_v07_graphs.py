#!/usr/bin/env python3
from pathlib import Path
import subprocess, argparse

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--dot-dir', required=True)
    ap.add_argument('--png-dir', required=True)
    ap.add_argument('--svg-dir', required=True)
    args=ap.parse_args()
    Path(args.png_dir).mkdir(parents=True, exist_ok=True)
    Path(args.svg_dir).mkdir(parents=True, exist_ok=True)
    for dot in Path(args.dot_dir).glob('*.dot'):
        png=Path(args.png_dir)/(dot.stem+'.png')
        svg=Path(args.svg_dir)/(dot.stem+'.svg')
        subprocess.run(['dot','-Tpng',str(dot),'-o',str(png)], check=True)
        subprocess.run(['dot','-Tsvg',str(dot),'-o',str(svg)], check=True)
        print(png)
if __name__ == '__main__': main()
