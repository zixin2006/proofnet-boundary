#!/usr/bin/env python3
from pathlib import Path
import argparse, json, sys
from jsonschema import Draft202012Validator

def load_schema(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def iter_jsonl(path):
    with open(path, encoding='utf-8') as f:
        for i,line in enumerate(f,1):
            if line.strip():
                yield i, json.loads(line)

def validate_trace(path, schema_path):
    schema=load_schema(schema_path)
    validator=Draft202012Validator(schema)
    errors=[]; records=[]
    for line_no, rec in iter_jsonl(path):
        es=list(validator.iter_errors(rec))
        for e in es:
            errors.append(f"{path}:{line_no}: {list(e.path)} {e.message}")
        records.append(rec)
        if rec.get('lean_result') == 'success':
            goals = rec.get('state_after',{}).get('goals', []) if rec.get('state_after') else []
            frontier = rec.get('frontier_after') or []
            caps = rec.get('state_after',{}).get('boundary_capsules', []) if rec.get('state_after') else []
            if len(goals) != len(frontier):
                errors.append(f"{path}:{line_no}: frontier invariant failure: {len(goals)} goals but {len(frontier)} frontier nodes")
            if len(caps) != len(frontier):
                errors.append(f"{path}:{line_no}: boundary invariant failure: {len(caps)} capsules but {len(frontier)} frontier nodes")
            # Verified edges only on success.
            for e in rec.get('graph_delta',{}).get('edges_added',[]):
                if e.get('verified') is not True:
                    errors.append(f"{path}:{line_no}: success record contains unverified edge {e}")
        else:
            if rec.get('state_after') is not None:
                errors.append(f"{path}:{line_no}: failure record should have state_after null")
            for e in rec.get('graph_delta',{}).get('edges_added',[]):
                if e.get('verified') is True:
                    errors.append(f"{path}:{line_no}: failure record contains verified edge")
    return records, errors

def check_sibling_preservation(records):
    # Specific crucial regression test for CEX_AND.
    by_step={r['step_index']:r for r in records if r.get('theorem_id')=='CEX_AND' and r.get('lean_result')=='success'}
    if not all(i in by_step for i in [0,1,2]):
        return False, 'CEX_AND steps 0,1,2 not all found'
    s0=by_step[0]; s1=by_step[1]; s2=by_step[2]
    if len(s0['frontier_after']) != 2:
        return False, 'constructor should create two frontier nodes'
    preserved = s1.get('transport',{}).get('preserved_nodes', [])
    expected = s0['frontier_after'][1]
    if preserved != [expected]:
        return False, f'exact h.right should preserve second node {expected}, got {preserved}'
    if s1['frontier_after'] != [expected]:
        return False, 'frontier_after of exact h.right should contain only preserved second node'
    if s2['frontier_after'] != []:
        return False, 'final exact should close all goals'
    return True, 'PASS'

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--trace', required=True)
    ap.add_argument('--failures', required=True)
    ap.add_argument('--schema', required=True)
    ap.add_argument('--report', required=True)
    args=ap.parse_args()
    records, errors = validate_trace(args.trace, args.schema)
    frecords, ferrors = validate_trace(args.failures, args.schema)
    errors += ferrors
    ok, msg = check_sibling_preservation(records)
    if not ok: errors.append('sibling preservation: '+msg)
    report={
        'trace_records': len(records),
        'failure_records': len(frecords),
        'schema_errors': errors,
        'frontier_invariant': 'PASS' if not errors else 'FAIL',
        'sibling_goal_preservation': msg,
    }
    Path(args.report).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps(report, indent=2, ensure_ascii=False))
    if errors:
        sys.exit(1)
if __name__ == '__main__': main()
