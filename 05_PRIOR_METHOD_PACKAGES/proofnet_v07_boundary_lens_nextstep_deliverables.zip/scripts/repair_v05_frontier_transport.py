#!/usr/bin/env python3
"""Repair v0.5 traces into v0.7 Boundary-Lens records.

The v0.5 extractor captured useful Lean states but generated frontier IDs from
ordinals/targets, so unchanged sibling goals could receive new graph node IDs.
This script replays the v0.5 trace records theorem-by-theorem and reconstructs
rho : MVarId -> GraphNodeId using state engineering IDs.
"""
from pathlib import Path
import argparse, json, sys
from boundary_lens_core import make_lens_record

def load_jsonl(path):
    with open(path, encoding='utf-8') as f:
        for line in f:
            line=line.strip()
            if line:
                yield json.loads(line)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--output', required=True)
    ap.add_argument('--failures-output', required=True)
    args = ap.parse_args()
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    by_key = {}
    failures = []
    for rec in load_jsonl(args.input):
        key=(rec.get('theorem_id','unknown'), rec.get('variant_id','canonical'))
        if rec.get('lean_result') == 'success':
            by_key.setdefault(key, []).append(rec)
        else:
            failures.append(rec)
    out_records=[]
    for key, recs in sorted(by_key.items()):
        rho={}
        for rec in sorted(recs, key=lambda r:r.get('step_index',0)):
            new, rho = make_lens_record(
                theorem_id=rec.get('theorem_id','unknown'),
                variant_id=rec.get('variant_id','canonical'),
                step_index=rec.get('step_index',0),
                raw_tactic=rec.get('tactic',''),
                state_before=rec.get('state_before') or {'goals': []},
                state_after=rec.get('state_after'),
                rho_before=rho,
                success=True,
                provenance='v05',
            )
            out_records.append(new)
    with open(args.output, 'w', encoding='utf-8') as f:
        for r in out_records:
            f.write(json.dumps(r, ensure_ascii=False, sort_keys=True)+'\n')
    # Convert failure records to ghost branches from their state_before.
    with open(args.failures_output, 'w', encoding='utf-8') as f:
        for rec in failures:
            rho={}
            new, _ = make_lens_record(
                theorem_id=rec.get('theorem_id','unknown'),
                variant_id=rec.get('variant_id','failure_candidate'),
                step_index=rec.get('step_index',0),
                raw_tactic=rec.get('tactic',''),
                state_before=rec.get('state_before') or {'goals': []},
                state_after=None,
                rho_before=rho,
                success=False,
                provenance='v05',
            )
            new['error_excerpt'] = rec.get('error_excerpt')
            new['failure_type'] = rec.get('failure_type') or 'lean_failure'
            f.write(json.dumps(new, ensure_ascii=False, sort_keys=True)+'\n')
    print(json.dumps({'success_records': len(out_records), 'failure_records': len(failures), 'output': args.output}, indent=2))

if __name__ == '__main__':
    main()
