#!/usr/bin/env python3
"""Core v0.7 Boundary-Lens ProofNet prototype.

This is a Python implementation of the extraction logic that should be mirrored in
Lean v0.7. It operates on Lean-like state snapshots. When fed v0.5 records, it
uses real captured Lean state snapshots but repairs the frontier transport bug by
tracking metavariable/engineering IDs across steps.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional, Tuple
import hashlib, json, re

FOCUSED_TACTICS = {
    "intro", "intros", "exact", "assumption", "apply", "refine", "constructor",
    "left", "right", "rw", "rfl", "simp", "linarith", "omega", "ring", "aesop",
    "have", "rcases", "cases"
}
MULTIGOAL_TACTICS = {"all_goals", "any_goals", "repeat", "simp_all"}
AUTOMATION_TACTICS = {"simp", "linarith", "omega", "ring", "aesop"}

def stable_hash(obj: Any, n: int = 16) -> str:
    if not isinstance(obj, str):
        obj = json.dumps(obj, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(obj.encode("utf-8")).hexdigest()[:n]

def alpha_norm_pretty(s: str) -> str:
    """Very small MVP normalizer.

    Real Lean v0.7 should hash Expr structure, not pretty strings. This MVP keeps
    the function isolated so it can be replaced by kernel-level expression hashing.
    """
    s = s.strip()
    s = re.sub(r"\s+", " ", s)
    # Normalize common unique names while preserving user-level structure.
    s = re.sub(r"_uniq\.\d+\.\d+", "_m", s)
    return s

@dataclass
class LocalDeclCapsule:
    fvar_id: str
    user_name: str
    type_pretty: str
    type_structural_hash: str
    kind: str = "cdecl"
    value_pretty: Optional[str] = None
    binder_info: str = "default"
    is_implementation_detail: bool = False

@dataclass
class BoundaryCapsule:
    mvar_id: str
    graph_node_id: str
    target_pretty: str
    target_structural_hash: str
    local_context: List[LocalDeclCapsule]
    typeclass_instances: List[Any] = field(default_factory=list)
    universe_context: List[Any] = field(default_factory=list)
    boundary_hash: str = ""

    def finalize(self) -> "BoundaryCapsule":
        payload = {
            "target": self.target_structural_hash,
            "locals": [(l.user_name, l.type_structural_hash, l.kind) for l in self.local_context],
            "typeclasses": self.typeclass_instances,
        }
        self.boundary_hash = "boundary:" + stable_hash(payload)
        return self

@dataclass
class GraphNode:
    id: str
    type: str
    label: str
    status: str = "open"
    features: Dict[str, Any] = field(default_factory=dict)

@dataclass
class GraphEdge:
    source: str
    target: str
    type: str
    verified: bool = True
    provenance: str = "lean_transition"
    features: Dict[str, Any] = field(default_factory=dict)

@dataclass
class GraphDelta:
    nodes_added: List[GraphNode] = field(default_factory=list)
    edges_added: List[GraphEdge] = field(default_factory=list)
    nodes_updated: List[Dict[str, Any]] = field(default_factory=list)
    frontier_updates: List[Dict[str, Any]] = field(default_factory=list)
    delta_status: str = "accepted_verified"

@dataclass
class TransportResult:
    rho_after: Dict[str, str]
    consumed_mvars: List[str]
    consumed_nodes: List[str]
    preserved_mvars: List[str]
    preserved_nodes: List[str]
    new_mvars: List[str]
    new_nodes: List[str]


def tactic_kind(raw: str) -> str:
    raw = raw.strip()
    if not raw:
        return "unknown"
    head = raw.split()[0]
    head = head.split("[")[0]
    if head == "haveI":
        return "have"
    if head in {"obtain"}:
        return "rcases"
    if head in {"use"}:
        return "refine"
    return head


def mk_goal_node_id(theorem_id: str, mvar_id: str, target: str) -> str:
    # Engineering ID is allowed as a stable internal key, but not as a model feature.
    return "goal:" + stable_hash({"theorem": theorem_id, "mvar": mvar_id, "target": alpha_norm_pretty(target)})


def goal_target(goal: Dict[str, Any]) -> str:
    t = goal.get("target")
    if isinstance(t, dict):
        return t.get("normalized") or t.get("pretty") or ""
    return goal.get("target_normalized") or str(t or "")


def goal_mvar(goal: Dict[str, Any]) -> str:
    return goal.get("mvar_id") or goal.get("engineering_id") or goal.get("node_id_hint") or stable_hash(goal)


def local_capsules(goal: Dict[str, Any]) -> List[LocalDeclCapsule]:
    out: List[LocalDeclCapsule] = []
    for d in goal.get("local_context", []) or []:
        tp = d.get("type")
        if isinstance(tp, dict):
            tpretty = tp.get("normalized") or tp.get("pretty") or ""
        else:
            tpretty = d.get("type_pretty") or str(tp or "")
        if d.get("is_implementation_detail"):
            continue
        tp_str = alpha_norm_pretty(tpretty)
        out.append(LocalDeclCapsule(
            fvar_id=d.get("fvar_id") or d.get("engineering_id") or stable_hash(d),
            user_name=d.get("user_name", "_"),
            type_pretty=tp_str,
            type_structural_hash="expr:" + stable_hash(tp_str),
            kind=d.get("kind", "cdecl"),
            value_pretty=None,
            is_implementation_detail=bool(d.get("is_implementation_detail", False)),
        ))
    return out


def boundary_capsules(theorem_id: str, state: Optional[Dict[str, Any]], rho: Dict[str, str]) -> List[BoundaryCapsule]:
    if state is None:
        return []
    caps: List[BoundaryCapsule] = []
    for g in state.get("goals", []) or []:
        m = goal_mvar(g)
        tgt = alpha_norm_pretty(goal_target(g))
        gid = rho.get(m, mk_goal_node_id(theorem_id, m, tgt))
        cap = BoundaryCapsule(
            mvar_id=m,
            graph_node_id=gid,
            target_pretty=tgt,
            target_structural_hash="expr:" + stable_hash(tgt),
            local_context=local_capsules(g),
        ).finalize()
        caps.append(cap)
    return caps


def transport_frontier(theorem_id: str, rho_before: Dict[str, str], state_before: Dict[str, Any], state_after: Optional[Dict[str, Any]], kind: str) -> TransportResult:
    goals_before = [goal_mvar(g) for g in (state_before.get("goals", []) or [])]
    targets_before = {goal_mvar(g): alpha_norm_pretty(goal_target(g)) for g in (state_before.get("goals", []) or [])}
    goals_after = [] if state_after is None else [goal_mvar(g) for g in (state_after.get("goals", []) or [])]
    targets_after = {} if state_after is None else {goal_mvar(g): alpha_norm_pretty(goal_target(g)) for g in (state_after.get("goals", []) or [])}
    focused_before = goals_before[0] if goals_before else None
    before_set, after_set = set(goals_before), set(goals_after)
    preserved = [m for m in goals_after if m in before_set]
    newly_created = [m for m in goals_after if m not in before_set]
    closed_or_replaced = [m for m in goals_before if m not in after_set]

    rho_after: Dict[str, str] = {}
    for m in preserved:
        rho_after[m] = rho_before[m]
    for m in newly_created:
        rho_after[m] = mk_goal_node_id(theorem_id, m, targets_after[m])

    if kind in FOCUSED_TACTICS and kind not in MULTIGOAL_TACTICS:
        consumed = [focused_before] if focused_before in closed_or_replaced else []
        # If non-focused siblings disappeared, record them but do not silently claim correctness.
        for m in closed_or_replaced:
            if m != focused_before:
                consumed.append(m)
    else:
        consumed = closed_or_replaced

    return TransportResult(
        rho_after=rho_after,
        consumed_mvars=consumed,
        consumed_nodes=[rho_before[m] for m in consumed if m in rho_before],
        preserved_mvars=preserved,
        preserved_nodes=[rho_before[m] for m in preserved if m in rho_before],
        new_mvars=newly_created,
        new_nodes=[rho_after[m] for m in newly_created],
    )


def build_delta(theorem_id: str, step_index: int, raw_tactic: str, state_before: Dict[str, Any], state_after: Optional[Dict[str, Any]], rho_before: Dict[str, str], transport: TransportResult, success: bool) -> GraphDelta:
    kind = tactic_kind(raw_tactic)
    verified = bool(success)
    status = "accepted_verified" if success else "ghost_rejected"
    delta = GraphDelta(delta_status=status)
    step_node = GraphNode(
        id="tactic:" + stable_hash({"theorem": theorem_id, "step": step_index, "tactic": raw_tactic}),
        type="TacticStep" if kind not in AUTOMATION_TACTICS else "AutomationBundle",
        label=raw_tactic,
        status="verified" if success else "rejected",
        features={"kind": kind},
    )
    delta.nodes_added.append(step_node)

    # Add new goal nodes.
    after_goal_by_m = {} if state_after is None else {goal_mvar(g): g for g in state_after.get("goals", []) or []}
    for m in transport.new_mvars:
        target = alpha_norm_pretty(goal_target(after_goal_by_m[m])) if m in after_goal_by_m else ""
        delta.nodes_added.append(GraphNode(
            id=transport.rho_after[m], type="OpenGoal", label=target, status="open",
            features={"target_structural_hash": "expr:" + stable_hash(target)}
        ))

    # Local-context diff nodes for introduced hypotheses/witnesses.
    before_locals = {}
    after_locals = {}
    for g in state_before.get("goals", []) or []:
        for l in local_capsules(g):
            before_locals[l.fvar_id] = l
    if state_after:
        for g in state_after.get("goals", []) or []:
            for l in local_capsules(g):
                after_locals[l.fvar_id] = l
    for fid, loc in after_locals.items():
        if fid not in before_locals:
            nid = "local:" + stable_hash({"theorem": theorem_id, "fid": fid, "type": loc.type_pretty})
            ntype = "Hypothesis" if loc.type_pretty == "Prop" or "→" in loc.type_pretty or "=" in loc.type_pretty or "∧" in loc.type_pretty else "LocalDefinition"
            delta.nodes_added.append(GraphNode(id=nid, type=ntype, label=f"{loc.user_name} : {loc.type_pretty}", status="available"))
            delta.edges_added.append(GraphEdge(step_node.id, nid, "introduces_hypothesis", verified=verified))

    # Consumes/decomposes/closes edges.
    for gid in transport.consumed_nodes:
        edge_type = {
            "constructor": "decomposes",
            "left": "chooses_constructor",
            "right": "chooses_constructor",
            "exact": "closes",
            "assumption": "closes",
            "rfl": "closes_defeq",
            "rw": "rewrites",
            "simp": "simplifies",
            "linarith": "closes_by_arithmetic",
            "omega": "closes_by_arithmetic",
            "ring": "closes_by_normalization",
            "aesop": "closes_by_search",
            "apply": "reduces_by_apply",
            "refine": "constructs_partial",
            "have": "creates_intermediate_claim",
            "rcases": "destructs",
            "cases": "case_splits",
        }.get(kind, "acts_on")
        delta.edges_added.append(GraphEdge(gid, step_node.id, edge_type, verified=verified))
        new_status = "closed" if kind in {"exact", "assumption", "rfl", "linarith", "omega", "ring", "aesop", "simp"} and state_after is not None and not transport.new_nodes else "decomposed"
        delta.nodes_updated.append({"id": gid, "status": new_status, "by": step_node.id})

    for new in transport.new_nodes:
        et = "creates_subgoal"
        if kind in {"left", "right"}:
            et = "selects_branch_goal"
        elif kind == "rw":
            et = "rewrite_to"
        elif kind == "intro":
            et = "frontier_transformed"
        delta.edges_added.append(GraphEdge(step_node.id, new, et, verified=verified))

    # Preserve sibling identity explicitly.
    for node in transport.preserved_nodes:
        delta.frontier_updates.append({"node_id": node, "action": "preserve_identity"})
        delta.edges_added.append(GraphEdge(node, node, "frontier_transported", verified=verified, features={"identity": True}))

    # Independence edges among newly created sibling subgoals for decomposing tactics.
    if kind in {"constructor", "apply", "refine"} and len(transport.new_nodes) > 1:
        for a, b in zip(transport.new_nodes, transport.new_nodes[1:]):
            delta.edges_added.append(GraphEdge(a, b, "sibling_independent", verified=verified, provenance="state_transition_plus_no_shared_new_mvars"))

    if not success:
        for e in delta.edges_added:
            e.verified = False
            e.provenance = "ghost_candidate_rejected"
        delta.frontier_updates.append({"action": "no_verified_graph_update_on_failure"})
    return delta


def graph_hash(nodes: List[Dict[str, Any]], edges: List[Dict[str, Any]]) -> str:
    return "graph:" + stable_hash({"nodes": sorted(nodes, key=lambda x: x.get("id", "")), "edges": sorted(edges, key=lambda x: (x.get("source", ""), x.get("type", ""), x.get("target", "")))})


def serialize_dataclass(x: Any) -> Any:
    if hasattr(x, "__dataclass_fields__"):
        return {k: serialize_dataclass(v) for k, v in asdict(x).items()}
    if isinstance(x, list):
        return [serialize_dataclass(v) for v in x]
    if isinstance(x, dict):
        return {k: serialize_dataclass(v) for k, v in x.items()}
    return x


def make_lens_record(theorem_id: str, variant_id: str, step_index: int, raw_tactic: str, state_before: Dict[str, Any], state_after: Optional[Dict[str, Any]], rho_before: Dict[str, str], success: bool, provenance: str) -> Tuple[Dict[str, Any], Dict[str, str]]:
    kind = tactic_kind(raw_tactic)
    # Initialize rho_before for any initial goals.
    for g in state_before.get("goals", []) or []:
        m = goal_mvar(g)
        if m not in rho_before:
            rho_before[m] = mk_goal_node_id(theorem_id, m, goal_target(g))
    transport = transport_frontier(theorem_id, rho_before, state_before, state_after, kind)
    delta = build_delta(theorem_id, step_index, raw_tactic, state_before, state_after, rho_before, transport, success)
    caps_before = boundary_capsules(theorem_id, state_before, rho_before)
    caps_after = boundary_capsules(theorem_id, state_after, transport.rho_after) if state_after is not None else None
    frontier_before = [rho_before[goal_mvar(g)] for g in state_before.get("goals", []) or []]
    frontier_after = None if state_after is None else [transport.rho_after[goal_mvar(g)] for g in state_after.get("goals", []) or []]
    boundary_before_hash = "boundaryset:" + stable_hash([c.boundary_hash for c in caps_before])
    boundary_after_hash = None if caps_after is None else "boundaryset:" + stable_hash([c.boundary_hash for c in caps_after])
    delta_json = serialize_dataclass(delta)
    rec = {
        "schema_version": "0.7",
        "record_type": "lens_trace_step",
        "theorem_id": theorem_id,
        "variant_id": variant_id,
        "step_index": step_index,
        "extraction_tier": "silver_tactic_state_repaired_from_v05" if provenance == "v05" else "controlled_simulation",
        "state_before": {"goals": state_before.get("goals", []), "focused_goal_mvar": goal_mvar(state_before.get("goals", [{}])[0]) if state_before.get("goals") else None, "boundary_capsules": serialize_dataclass(caps_before)},
        "tactic": {"raw": raw_tactic, "kind": kind, "source_span": None, "arguments": raw_tactic.split()[1:]},
        "state_after": None if state_after is None else {"goals": state_after.get("goals", []), "focused_goal_mvar": goal_mvar(state_after.get("goals", [{}])[0]) if state_after.get("goals") else None, "boundary_capsules": serialize_dataclass(caps_after)},
        "frontier_before": frontier_before,
        "frontier_after": frontier_after,
        "rho_before": dict(rho_before),
        "rho_after": None if state_after is None else dict(transport.rho_after),
        "transport": serialize_dataclass(transport),
        "boundary_before_hash": boundary_before_hash,
        "boundary_after_hash": boundary_after_hash,
        "graph_before_hash": "not_materialized_in_python_mvp_before_" + stable_hash({"theorem": theorem_id, "step": step_index, "rho": rho_before}),
        "graph_delta": delta_json,
        "graph_after_hash": None if state_after is None else "not_materialized_in_python_mvp_after_" + stable_hash({"theorem": theorem_id, "step": step_index, "rho": transport.rho_after, "delta": delta_json}),
        "lean_result": "success" if success else "failure",
        "error_excerpt": None if success else "candidate tactic rejected by Lean or simulated checker",
        "failure_type": None if success else "candidate_rejected",
        "verification_status": "lean_transition_verified_from_v05_record_not_rebuilt_here" if success and provenance == "v05" else ("methodological_simulation" if success else "lean_rejected_or_simulated_rejection"),
    }
    return rec, transport.rho_after if state_after is not None and success else rho_before
