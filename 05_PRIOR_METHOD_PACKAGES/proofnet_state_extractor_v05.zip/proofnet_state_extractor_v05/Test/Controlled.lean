import ProofNet.Extract

namespace ProofNet.Test.Controlled

theorem cex_and_constructor_exact (p q : Prop) (h : And p q) : And q p := by
  constructor
  exact h.right
  exact h.left

theorem cex_or_left (p q : Prop) (hp : p) : Or p q := by
  left
  exact hp

theorem cex_or_right (p q : Prop) (hq : q) : Or p q := by
  right
  exact hq

theorem cex_eq_cases (alpha : Type) (a b : alpha) (h : a = b) (p : alpha -> Prop)
    (ha : p a) : p b := by
  cases h
  exact ha

theorem cex_rw (a b c : Nat) (h : a = b) (hc : b = c) : a = c := by
  rw [h]
  exact hc

theorem cex_have (p q : Prop) (hp : p) (hq : q) : And p q := by
  have hp' : p := by
    exact hp
  constructor
  exact hp'
  exact hq

end ProofNet.Test.Controlled
