# State Extractor Usage v0.5

## Build

```bash
lake build ProofNet
lake build Test
```

## Run Controlled Extraction

```bash
python3 scripts/run_state_extractor.py --package-root .
python3 scripts/validate_extracted_traces.py --package-root .
```

## Outputs

- `data/proofnet_declarations_split.jsonl`: proof-safe declaration splits. `formal_statement_header` is the only declaration source field allowed for model input.
- `data/extracted_trace_steps.jsonl`: silver trace/failure records with Lean-state snapshots.
- `data/pfr_bronze_extraction_attempts.jsonl`: PFR remains bronze in this package because the PFR Lake project is not bundled here.
- `reports/STATE_EXTRACTOR_REPORT.md`: extraction metrics and strict interpretation.
- `reports/STATE_EXTRACTOR_VALIDATION_REPORT.md`: leakage/frontier/schema validation.

## Scope

This MVP supports a controlled subset of tactics through replay probes and the Lean-side
`proofnet_state` tactic. It does not yet traverse arbitrary InfoTrees or recover complete proof-term
dependencies. Automation tactics should be represented only as coarse `AutomationBundle` nodes until
an elaborated proof-term/dependency pass is added.
