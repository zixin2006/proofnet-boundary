# State Extractor Report v0.5

## Summary

- Declarations split: 6
- Tactic records emitted: 21
- Tactic steps with real Lean states: 21
- Failure records: 6
- Empty graph deltas: 0 (0.0%)
- Proof leakage violations detected by runner: 0
- PFR examples remaining bronze/source-only: 1

## Strict Interpretation

The controlled synthetic examples are silver: every success row contains a Lean-object-derived
`state_before` and `state_after`, and every failure row contains a Lean-object-derived pre-state plus
the Lean error excerpt. The graph deltas are partial and rule-guided, but their goal, target, and local
context nodes are derived from Lean state snapshots rather than manual labels.

PFR is not promoted to silver in this deliverable. The v04 package includes verified PFR metadata but
does not include the cloned `teorth/pfr` Lake project, so the extractor records a bronze attempt only.

## Files

- Trace JSONL: `data/extracted_trace_steps.jsonl`
- Declaration splits: `data/proofnet_declarations_split.jsonl`
- PFR bronze attempts: `data/pfr_bronze_extraction_attempts.jsonl`
- Validator: `scripts/validate_extracted_traces.py`
