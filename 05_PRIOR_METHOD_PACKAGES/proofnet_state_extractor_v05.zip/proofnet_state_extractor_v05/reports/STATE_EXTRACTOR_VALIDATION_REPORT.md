# State Extractor Validation Report v0.5

Status: **PASS**

## Metrics

- declarations: 6
- trace_records: 21
- real_state_records: 21
- failure_records: 6
- empty_graph_delta_records: 0
- empty_graph_delta_percentage: 0.0
- proof_leakage_violations: 0
- frontier_invariant_violations: 0
- bronze_source_only_records: 1

## Errors

- None.
