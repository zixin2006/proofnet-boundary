# Lean-to-ProofNet Methodology

## 1. Scientific diagnosis of the current uploaded package

The accessible uploaded archive is `proofnet_frontier_v04_audit_deliverables.zip`.  It contains an audited v0.4 package with synthetic records, frontier candidates, a verified subset, source-mined tactic rows, scripts, and audit reports.

The package is valuable as a scaffold, but it is not yet a Lean-certified graph-delta dataset.  The main inspected facts are:

- `proofnet_checked_synthetic_29.jsonl`: 29 records. All inspected records contain proof-body material in `lean_statement` through `:= by`, so this field is not safe as model input for tactic prediction.
- `proofnet_frontier_research_10.jsonl`: 10 frontier candidates. Some have useful project-level provenance, but graph nodes remain conceptual/manual abstractions rather than Lean-state objects.
- `proofnet_frontier_verified_subset.jsonl`: 4 promoted frontier records. The promotion is useful, but the graphs are still candidate graphs, not extracted tactic-state traces.
- `proofnet_frontier_trace_steps_parsed_no_state.jsonl`: 131 parsed tactic rows. Every `state_before` and `state_after` is null; `graph_delta` is empty. This is a source parser scaffold, not a training trace.

The good part is the staged philosophy: synthetic -> frontier candidates -> verified subset -> trace scaffold. The weak part is that graph nodes such as `h`, `goal`, `entropy`, `ruzsa`, `cover`, and `card` are manually named summaries, not systematically derived from Lean metavariable goals, local declarations, elaborated expressions, or proof terms.  This makes the dataset weakly trainable for shape pretraining and repository selection, but not yet evidence-bearing for the central claim that proof-net-inspired graphs reduce redundant Lean tactic search.

## 2. Target object

During search the proof is incomplete, so the object should not be called a complete proof net.  The object is a **Lean-certified partial proof-net-inspired dependency graph**:

```text
G_i = (V_i, E_i, tau_i, ell_i, sigma_i, rho_i, eta_i)
```

where:

- `V_i` is a finite node set.
- `E_i` is a finite typed directed edge set.
- `tau_i : V_i -> NodeType` assigns node types.
- `ell_i : V_i -> NormalizedLabel` stores normalized expressions or safe labels.
- `sigma_i : V_i -> NodeStatus` stores `open`, `closed`, `decomposed`, `verified`, or `failed`.
- `rho_i : MVarId -> V_i` maps open Lean metavariable goals to open graph frontier nodes.
- `eta_i` stores provenance: `source_heuristic`, `lean_state`, `proof_term`, or `kernel_dependency`.

The key invariant is:

```text
Every open Lean goal in state s_i corresponds to exactly one open frontier node in G_i.
```

Every verified graph edge must come from an accepted Lean transition or a kernel/proof-term inspection. Source-derived edges may exist only with weaker provenance.

## 3. Extraction layers

### Layer A. Source-level declaration extraction

Input: Lean repository, `.lean` files, declarations, proof bodies, imports, and source spans.

Output: proof-safe declaration records.  The crucial repair is to split:

```json
{
  "formal_statement_header": "theorem foo ... : ...",
  "proof_body_kind": "by",
  "proof_body_source": "by ...",
  "full_declaration_source": "theorem foo ... := by ..."
}
```

`formal_statement_header` is safe for model input. `proof_body_source` is not safe as input for next-tactic prediction, but is useful as a target/trace source.

### Layer B. Tactic-script parsing

Parse tactic blocks into tactic text, source span, nesting/bullets, tactic family, arguments, and visible names. This layer is explicitly heuristic. It may produce bronze records, but it must not be represented as Lean-state-derived proof evidence.

### Layer C. Lean tactic-state transition extraction

For each tactic step, run Lean instrumentation to obtain:

```text
state_before, tactic, state_after, success/failure,
new goals, closed goals, local-context changes,
metavariable ids, and available used declarations.
```

Then compute:

```text
DeltaG_i = ExtractDelta(s_i, t_i, s_{i+1})
G_{i+1} = UpdateGraph(G_i, DeltaG_i)
```

Pseudocode:

```text
NormalizeState(s):
  enumerate open goals deterministically
  normalize target and local-context expressions
  alpha-normalize local names
  canonicalize metavariable ids
  return normalized goal list and state hash

ExtractDelta(s_i, t_i, s_{i+1}, G_i):
  consumed := frontier nodes mapped from goals closed or transformed by t_i
  family := classify tactic t_i
  diff := compare normalized goals and local contexts
  emit nodes and edges according to graph-delta rules
  attach provenance = lean_state
  return DeltaG_i

UpdateGraph(G_i, DeltaG_i):
  add nodes and edges
  update node status of consumed goals
  refresh frontier map rho_{i+1}
  recompute graph hashes
  assert frontier invariant
  return G_{i+1}

CanonicalizePartialGraph(G_i):
  remove non-semantic ids and names
  sort independent sibling goals canonically
  preserve expressions, lemma dependencies, rewrite direction, and case tree
  return canonical payload for hashing
```

### Layer D. Proof-term dependency extraction

After full proof elaboration, inspect the elaborated proof term and kernel dependencies to extract constants, projections, recursors, rewrite lemmas, typeclass instances, and proof-term applications. This layer is more accurate than source parsing but harder because proof terms can be huge and noisy. It should enrich and validate silver traces rather than replace the MVP.

### Layer E. Failure-branch extraction

Generate candidate tactics and failed branches. Store state, candidate tactic, Lean error, failure type, and any candidate graph-delta attempt. Negative branches train compatibility, pruning, and value models.

## 4. v1.0 trace-step record

```json
{
  "schema_version": "proofnet-trace-step-1.0",
  "record_type": "trace_step",
  "quality_tier": "silver",
  "theorem_id": "...",
  "variant_id": "...",
  "step_index": 0,
  "source_span": {"file": "...", "start_line": 1, "end_line": 1},
  "state_before": {"goals": []},
  "tactic": "constructor",
  "state_after": {"goals": []},
  "lean_result": "success",
  "graph_before_hash": "...",
  "graph_delta": {"nodes_added": [], "edges_added": [], "nodes_updated": []},
  "graph_after_hash": "...",
  "frontier_before": [],
  "frontier_after": [],
  "used_declarations": [],
  "provenance": {"trace_origin": "lean_state"}
}
```

## 5. Original contribution

Existing proof-net theory teaches that many sequential differences in derivations are bureaucratic. LeanDojo-style extraction teaches that tactic-state data can be obtained from actual Lean execution. Graph-based theorem proving teaches that formula/proof graphs can be useful for learned search. The original move here is to combine these into a **frontier-preserving partial graph during search**, where each accepted Lean tactic contributes a certified graph delta.  Redundancy reduction is then defined over a joint key:

```text
PruningKey(B_i) = (NormalizeState(s_i), CanonicalizePartialGraph(G_i))
```

The graph hash alone is explicitly unsafe.
