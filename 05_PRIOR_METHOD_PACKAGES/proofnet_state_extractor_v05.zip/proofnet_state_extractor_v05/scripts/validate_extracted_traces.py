#!/usr/bin/env python3
"""Validate ProofNet extracted trace records and declaration leakage guards."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


REPORT_PATH = "reports/STATE_EXTRACTOR_VALIDATION_REPORT.md"


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    for i, line in enumerate(path.read_text().splitlines(), 1):
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise ValueError(f"{path}:{i}: invalid JSON: {exc}") from exc
    return rows


def validate(package_root: Path) -> tuple[list[str], dict[str, Any]]:
    trace_path = package_root / "data/extracted_trace_steps.jsonl"
    decl_path = package_root / "data/proofnet_declarations_split.jsonl"
    pfr_path = package_root / "data/pfr_bronze_extraction_attempts.jsonl"
    traces = read_jsonl(trace_path)
    decls = read_jsonl(decl_path)
    pfr = read_jsonl(pfr_path) if pfr_path.exists() else []

    errors: list[str] = []
    failures = 0
    real_states = 0
    empty_deltas = 0
    frontier_violations = 0
    leakage_violations = 0

    for decl in decls:
        header = decl.get("formal_statement_header", "")
        proof = decl.get("proof_body_source", "")
        if ":= by" in header or " by " in header[-8:]:
            errors.append(f"{decl.get('theorem_id')}: formal_statement_header appears to include proof syntax")
            leakage_violations += 1
        allowed = decl.get("model_input_policy", {}).get("allowed_fields", [])
        if "proof_body_source" in allowed or "full_declaration_source" in allowed:
            errors.append(f"{decl.get('theorem_id')}: proof-bearing field allowed as model input")
            leakage_violations += 1
        if proof and proof in header:
            errors.append(f"{decl.get('theorem_id')}: proof body leaked into formal header")
            leakage_violations += 1

    required = {
        "schema_version",
        "record_type",
        "quality_tier",
        "theorem_id",
        "variant_id",
        "step_index",
        "state_before",
        "tactic",
        "state_after",
        "lean_result",
        "graph_delta",
        "frontier_before",
        "frontier_after",
        "provenance",
    }

    for idx, row in enumerate(traces):
        missing = required - set(row)
        if missing:
            errors.append(f"trace[{idx}] missing fields: {sorted(missing)}")
        if row.get("schema_version") != "proofnet-trace-step-1.0":
            errors.append(f"trace[{idx}] bad schema_version")
        if row.get("lean_result") == "failure":
            failures += 1
            if not row.get("error_excerpt"):
                errors.append(f"trace[{idx}] failure record missing error_excerpt")
        before_goals = row.get("state_before", {}).get("goals")
        after_goals = None if row.get("state_after") is None else row.get("state_after", {}).get("goals")
        if isinstance(before_goals, list) and (row.get("lean_result") == "failure" or isinstance(after_goals, list)):
            real_states += 1
        if len(row.get("frontier_before", [])) != len(before_goals or []):
            errors.append(f"trace[{idx}] frontier_before length does not match state_before goals")
            frontier_violations += 1
        if row.get("lean_result") == "success":
            if len(row.get("frontier_after", [])) != len(after_goals or []):
                errors.append(f"trace[{idx}] frontier_after length does not match state_after goals")
                frontier_violations += 1
        delta = row.get("graph_delta", {})
        if not delta.get("nodes_added") and not delta.get("edges_added") and not delta.get("nodes_updated"):
            empty_deltas += 1
        prov = row.get("provenance", {})
        if prov.get("proof_body_source_used_as_model_input") is not False:
            errors.append(f"trace[{idx}] missing proof leakage guard in provenance")
            leakage_violations += 1

    summary = {
        "declarations": len(decls),
        "trace_records": len(traces),
        "real_state_records": real_states,
        "failure_records": failures,
        "empty_graph_delta_records": empty_deltas,
        "empty_graph_delta_percentage": 0.0 if not traces else round(100.0 * empty_deltas / len(traces), 2),
        "proof_leakage_violations": leakage_violations,
        "frontier_invariant_violations": frontier_violations,
        "bronze_source_only_records": len(pfr),
    }
    return errors, summary


def render_report(errors: list[str], summary: dict[str, Any]) -> str:
    status = "PASS" if not errors else "FAIL"
    lines = [
        "# State Extractor Validation Report v0.5",
        "",
        f"Status: **{status}**",
        "",
        "## Metrics",
        "",
    ]
    for key, value in summary.items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Errors", ""])
    if errors:
        lines.extend(f"- {err}" for err in errors)
    else:
        lines.append("- None.")
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", default=".")
    args = parser.parse_args()
    package_root = Path(args.package_root).resolve()
    errors, summary = validate(package_root)
    report = render_report(errors, summary)
    out = package_root / REPORT_PATH
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(report)
    print(report)
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
