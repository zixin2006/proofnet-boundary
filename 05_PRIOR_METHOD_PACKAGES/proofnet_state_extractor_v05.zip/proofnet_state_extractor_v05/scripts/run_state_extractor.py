#!/usr/bin/env python3
"""Run the ProofNet Lean-state extractor on controlled Lean examples.

This is an MVP silver extractor. It does not parse arbitrary Lean files yet.
Instead, it probes known declarations by replaying tactic prefixes with the
Lean-side `proofnet_state` tactic inserted before and after a controlled tactic.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any


SCHEMA_VERSION = "proofnet-trace-step-1.0"
TRACE_RECORDS = "data/extracted_trace_steps.jsonl"
DECL_RECORDS = "data/proofnet_declarations_split.jsonl"
PFR_ATTEMPTS = "data/pfr_bronze_extraction_attempts.jsonl"
REPORT_PATH = "reports/STATE_EXTRACTOR_REPORT.md"


CONTROLLED_TACTICS = {
    "intro",
    "intros",
    "exact",
    "assumption",
    "apply",
    "refine",
    "constructor",
    "left",
    "right",
    "cases",
    "rcases",
    "have",
    "suffices",
    "let",
    "rw",
    "rfl",
    "exfalso",
    "contradiction",
}

AUTOMATION_TACTICS = {"simp", "aesop", "linarith", "omega", "ring"}


@dataclass(frozen=True)
class Declaration:
    theorem_id: str
    variant_id: str
    formal_statement_header: str
    proof_steps: list[str]
    failure_candidates: dict[int, str]
    source_file: str = "Test/Controlled.lean"
    start_line: int = 1

    @property
    def proof_body_source(self) -> str:
        body = ["by"]
        for step in self.proof_steps:
            body.extend("  " + line for line in step.splitlines())
        return "\n".join(body)

    @property
    def full_declaration_source(self) -> str:
        return self.formal_statement_header + " := " + self.proof_body_source


DECLARATIONS: list[Declaration] = [
    Declaration(
        theorem_id="CEX_AND",
        variant_id="cex_and_constructor_exact",
        formal_statement_header=(
            "theorem cex_and_constructor_exact (p q : Prop) (h : And p q) : And q p"
        ),
        proof_steps=["constructor", "exact h.right", "exact h.left"],
        failure_candidates={0: "exact h.left"},
        start_line=5,
    ),
    Declaration(
        theorem_id="CEX_OR_LEFT",
        variant_id="cex_or_left",
        formal_statement_header="theorem cex_or_left (p q : Prop) (hp : p) : Or p q",
        proof_steps=["left", "exact hp"],
        failure_candidates={0: "exact hp"},
        start_line=10,
    ),
    Declaration(
        theorem_id="CEX_OR_RIGHT",
        variant_id="cex_or_right",
        formal_statement_header="theorem cex_or_right (p q : Prop) (hq : q) : Or p q",
        proof_steps=["right", "exact hq"],
        failure_candidates={0: "exact hq"},
        start_line=14,
    ),
    Declaration(
        theorem_id="CEX_EQ_CASES",
        variant_id="cex_eq_cases",
        formal_statement_header=(
            "theorem cex_eq_cases (alpha : Type) (a b : alpha) (h : a = b) "
            "(p : alpha -> Prop) (ha : p a) : p b"
        ),
        proof_steps=["cases h", "exact ha"],
        failure_candidates={0: "exact ha"},
        start_line=18,
    ),
    Declaration(
        theorem_id="CEX_RW",
        variant_id="cex_rw",
        formal_statement_header=(
            "theorem cex_rw (a b c : Nat) (h : a = b) (hc : b = c) : a = c"
        ),
        proof_steps=["rw [h]", "exact hc"],
        failure_candidates={0: "rfl"},
        start_line=23,
    ),
    Declaration(
        theorem_id="CEX_HAVE",
        variant_id="cex_have",
        formal_statement_header=(
            "theorem cex_have (p q : Prop) (hp : p) (hq : q) : And p q"
        ),
        proof_steps=["have hp' : p := by\n  exact hp", "constructor", "exact hp'", "exact hq"],
        failure_candidates={0: "assumption"},
        start_line=27,
    ),
]


def stable_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_obj(obj: Any) -> str:
    return hashlib.sha256(stable_json(obj).encode("utf-8")).hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def indent_tactic(tactic: str, spaces: int = 2) -> str:
    prefix = " " * spaces
    return "\n".join(prefix + line if line.strip() else line for line in tactic.splitlines())


def tactic_head(tactic: str) -> str:
    stripped = tactic.strip()
    if not stripped:
        return ""
    return stripped.split(maxsplit=1)[0].strip("·")


def tactic_family(tactic: str) -> str:
    head = tactic_head(tactic)
    if head in CONTROLLED_TACTICS:
        return head
    if head in AUTOMATION_TACTICS:
        return "AutomationBundle"
    return "unsupported"


def source_for_probe(decl: Declaration, prefix_steps: list[str], tactic: str, include_after: bool) -> str:
    lines = [
        "import ProofNet.Extract",
        "",
        "set_option pp.unicode.fun true",
        "set_option autoImplicit false",
        "set_option relaxedAutoImplicit false",
        "",
        "namespace ProofNet.Extract.Generated",
        "",
        decl.formal_statement_header + " := by",
    ]
    for step in prefix_steps:
        lines.append(indent_tactic(step))
    lines.append('  proofnet_state "before"')
    lines.append(indent_tactic(tactic))
    if include_after:
        lines.append('  proofnet_state "after"')
        lines.append("  all_goals sorry")
    lines.append("")
    lines.append("end ProofNet.Extract.Generated")
    lines.append("")
    return "\n".join(lines)


def run_lean_probe(package_root: Path, source: str, timeout: int = 60) -> subprocess.CompletedProcess[str]:
    with tempfile.NamedTemporaryFile("w", suffix=".lean", dir=package_root, delete=False) as fh:
        fh.write(source)
        temp_path = Path(fh.name)
    try:
        return subprocess.run(
            ["lake", "env", "lean", temp_path.name],
            cwd=package_root,
            text=True,
            capture_output=True,
            timeout=timeout,
        )
    finally:
        try:
            temp_path.unlink()
        except FileNotFoundError:
            pass


def parse_state_markers(output: str) -> list[dict[str, Any]]:
    states: list[dict[str, Any]] = []
    for line in output.splitlines():
        if "PROOFNET_STATE " not in line:
            continue
        payload = line.split("PROOFNET_STATE ", 1)[1].strip()
        try:
            states.append(json.loads(payload))
        except json.JSONDecodeError:
            # Lean may wrap long messages. Keep this strict and let validation report missing states.
            continue
    return states


def compact_error(output: str, limit: int = 700) -> str:
    lines = [line for line in output.splitlines() if "error:" in line or "unsolved goals" in line]
    if not lines:
        lines = output.splitlines()
    text = "\n".join(lines).strip()
    return text[:limit]


def normalize_state(raw_state: dict[str, Any], theorem_id: str, step_index: int) -> dict[str, Any]:
    goals = []
    for idx, goal in enumerate(raw_state.get("goals", [])):
        target = goal.get("target", {})
        locals_norm = []
        for local in goal.get("local_context", []):
            locals_norm.append(
                {
                    "engineering_id": local.get("fvar_id", ""),
                    "user_name": local.get("user_name", ""),
                    "kind": local.get("kind", ""),
                    "type": local.get("type", {}),
                    "value": local.get("value"),
                    "features": {
                        "role": "local_context_decl",
                        "type_normalized": local.get("type", {}).get("normalized", ""),
                    },
                }
            )
        goals.append(
            {
                "engineering_id": goal.get("mvar_id", f"goal_{idx}"),
                "user_name": goal.get("user_name", ""),
                "ordinal": idx,
                "target": target,
                "local_context": locals_norm,
                "features": {
                    "role": "metavariable_goal",
                    "target_normalized": target.get("normalized", ""),
                    "local_context_size": len(locals_norm),
                },
                "node_id_hint": hashlib.sha256(
                    f"{theorem_id}:{step_index}:{idx}:{target.get('normalized', '')}".encode("utf-8")
                ).hexdigest()[:16],
            }
        )
    return {"goals": goals}


def node_id(kind: str, payload: Any) -> str:
    return f"{kind}:{sha256_obj(payload)[:16]}"


def state_to_graph(state: dict[str, Any], theorem_id: str, variant_id: str, step_index: int) -> dict[str, Any]:
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    frontier_map: dict[str, str] = {}
    open_frontier: list[str] = []
    for goal in state.get("goals", []):
        goal_payload = {
            "theorem_id": theorem_id,
            "variant_id": variant_id,
            "role": "goal",
            "ordinal": goal["ordinal"],
            "target": goal["target"].get("normalized", ""),
        }
        gid = node_id("goal", goal_payload)
        target_payload = {"role": "target", "expr": goal["target"].get("normalized", "")}
        tid = node_id("target", target_payload)
        nodes.append(
            {
                "id": gid,
                "type": "MetavariableGoal",
                "status": "open",
                "label": {"kind": "engineering_id", "value": goal["engineering_id"]},
                "features": {
                    "role": "open_goal",
                    "target": goal["target"],
                    "ordinal": goal["ordinal"],
                },
                "provenance": "lean_state",
            }
        )
        nodes.append(
            {
                "id": tid,
                "type": "GoalTargetExpr",
                "status": "open",
                "label": {"kind": "normalized_expr", "value": goal["target"].get("normalized", "")},
                "features": {"expr": goal["target"]},
                "provenance": "lean_state",
            }
        )
        edges.append(
            {
                "id": node_id("edge", {"type": "goal_has_target", "source": gid, "target": tid}),
                "type": "goal_has_target",
                "source": gid,
                "target": tid,
                "features": {},
                "provenance": "lean_state",
            }
        )
        for local in goal.get("local_context", []):
            local_payload = {
                "role": "local",
                "name": local.get("user_name", ""),
                "type": local.get("type", {}).get("normalized", ""),
            }
            lid = node_id("local", local_payload)
            nodes.append(
                {
                    "id": lid,
                    "type": "LocalDecl",
                    "status": "available",
                    "label": {"kind": "user_name", "value": local.get("user_name", "")},
                    "features": {
                        "role": "hypothesis_or_local_definition",
                        "type": local.get("type", {}),
                        "kind": local.get("kind", ""),
                    },
                    "provenance": "lean_state",
                }
            )
            edges.append(
                {
                    "id": node_id("edge", {"type": "goal_has_local", "source": gid, "target": lid}),
                    "type": "goal_has_local",
                    "source": gid,
                    "target": lid,
                    "features": {},
                    "provenance": "lean_state",
                }
            )
        frontier_map[goal["engineering_id"]] = gid
        open_frontier.append(gid)
    return {
        "nodes": dedupe_by_id(nodes),
        "edges": dedupe_by_id(edges),
        "frontier_map": frontier_map,
        "open_frontier": open_frontier,
        "closed_goals": [],
    }


def dedupe_by_id(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_id: dict[str, dict[str, Any]] = {}
    for item in items:
        by_id[item["id"]] = item
    return [by_id[k] for k in sorted(by_id)]


def graph_hash(graph: dict[str, Any]) -> str:
    payload = {
        "nodes": sorted(graph.get("nodes", []), key=lambda x: x["id"]),
        "edges": sorted(graph.get("edges", []), key=lambda x: x["id"]),
        "open_frontier": sorted(graph.get("open_frontier", [])),
    }
    return sha256_obj(payload)


def estimate_used_declarations(tactic: str, state_before: dict[str, Any]) -> list[dict[str, str]]:
    names = set()
    for goal in state_before.get("goals", []):
        for local in goal.get("local_context", []):
            name = local.get("user_name", "")
            if name and re.search(rf"\b{re.escape(name)}\b", tactic):
                names.add(name)
    if tactic.strip().startswith("rw"):
        for name in re.findall(r"\[([^\]]+)\]", tactic):
            for item in re.split(r"[, ]+", name):
                if item:
                    names.add(item.strip("<>-"))
    return [
        {"name": name, "kind": "local_or_decl_from_tactic_text", "provenance": "source_tactic_text"}
        for name in sorted(names)
    ]


def make_delta(
    before_graph: dict[str, Any],
    after_graph: dict[str, Any] | None,
    tactic: str,
    success: bool,
) -> dict[str, Any]:
    family = tactic_family(tactic)
    effect_payload = {"tactic": tactic, "family": family, "success": success}
    effect_id = node_id("effect", effect_payload)
    nodes_added = [
        {
            "id": effect_id,
            "type": "TacticEffect" if family != "AutomationBundle" else "AutomationBundle",
            "status": "verified" if success else "failed_candidate",
            "label": {"kind": "tactic_family", "value": family},
            "features": {"tactic_family": family, "tactic_text": tactic},
            "provenance": "lean_state" if success else "candidate_failure",
        }
    ]
    edges_added = []
    for gid in before_graph.get("open_frontier", []):
        edges_added.append(
            {
                "id": node_id("edge", {"type": "tactic_consumes_frontier", "source": gid, "target": effect_id}),
                "type": "tactic_consumes_frontier",
                "source": gid,
                "target": effect_id,
                "features": {"tactic_family": family},
                "provenance": "lean_state" if success else "candidate_failure",
            }
        )
    nodes_updated = []
    after_node_ids: set[str] = set()
    if after_graph is not None:
        before_node_ids = {n["id"] for n in before_graph.get("nodes", [])}
        after_node_ids = {n["id"] for n in after_graph.get("nodes", [])}
        for node in after_graph.get("nodes", []):
            if node["id"] not in before_node_ids:
                nodes_added.append(node)
        before_edge_ids = {e["id"] for e in before_graph.get("edges", [])}
        for edge in after_graph.get("edges", []):
            if edge["id"] not in before_edge_ids:
                edges_added.append(edge)
        for gid in after_graph.get("open_frontier", []):
            edges_added.append(
                {
                    "id": node_id("edge", {"type": "tactic_creates_frontier", "source": effect_id, "target": gid}),
                    "type": "tactic_creates_frontier",
                    "source": effect_id,
                    "target": gid,
                    "features": {"tactic_family": family},
                    "provenance": "lean_state",
                }
            )
    for gid in before_graph.get("open_frontier", []):
        if gid not in after_node_ids:
            nodes_updated.append(
                {
                    "id": gid,
                    "status_before": "open",
                    "status_after": "closed_or_transformed" if success else "failed_candidate_preserved",
                    "provenance": "lean_state" if success else "candidate_failure",
                }
            )
    return {
        "nodes_added": dedupe_by_id(nodes_added),
        "edges_added": dedupe_by_id(edges_added),
        "nodes_updated": nodes_updated,
        "frontier_map_delta": {
            "family": family,
            "success": success,
            "before_frontier_count": len(before_graph.get("open_frontier", [])),
            "after_frontier_count": len(after_graph.get("open_frontier", [])) if after_graph else None,
        },
    }


def source_span(decl: Declaration, step_index: int, tactic: str) -> dict[str, Any]:
    width = max(1, tactic.count("\n") + 1)
    start = decl.start_line + 1 + step_index
    return {"file": decl.source_file, "start_line": start, "end_line": start + width - 1}


def make_success_record(
    decl: Declaration,
    step_index: int,
    tactic: str,
    before_raw: dict[str, Any],
    after_raw: dict[str, Any],
) -> dict[str, Any]:
    state_before = normalize_state(before_raw, decl.theorem_id, step_index)
    state_after = normalize_state(after_raw, decl.theorem_id, step_index + 1)
    before_graph = state_to_graph(state_before, decl.theorem_id, decl.variant_id, step_index)
    after_graph = state_to_graph(state_after, decl.theorem_id, decl.variant_id, step_index + 1)
    delta = make_delta(before_graph, after_graph, tactic, True)
    return {
        "schema_version": SCHEMA_VERSION,
        "record_type": "trace_step",
        "quality_tier": "silver",
        "theorem_id": decl.theorem_id,
        "variant_id": decl.variant_id,
        "step_index": step_index,
        "source_span": source_span(decl, step_index, tactic),
        "state_before": state_before,
        "tactic": tactic,
        "state_after": state_after,
        "lean_result": "success",
        "graph_before_hash": graph_hash(before_graph),
        "graph_delta": delta,
        "graph_after_hash": graph_hash(after_graph),
        "frontier_before": before_graph["open_frontier"],
        "frontier_after": after_graph["open_frontier"],
        "used_declarations": estimate_used_declarations(tactic, state_before),
        "provenance": {
            "trace_origin": "lean_state",
            "extractor": "ProofNet.Extract.proofnet_state",
            "model_input_fields": ["formal_statement_header", "state_before", "frontier_before"],
            "proof_body_source_used_as_model_input": False,
        },
    }


def make_failure_record(
    decl: Declaration,
    step_index: int,
    tactic: str,
    before_raw: dict[str, Any],
    output: str,
) -> dict[str, Any]:
    state_before = normalize_state(before_raw, decl.theorem_id, step_index)
    before_graph = state_to_graph(state_before, decl.theorem_id, decl.variant_id, step_index)
    delta = make_delta(before_graph, None, tactic, False)
    return {
        "schema_version": SCHEMA_VERSION,
        "record_type": "failure_step",
        "quality_tier": "silver",
        "theorem_id": decl.theorem_id,
        "variant_id": decl.variant_id,
        "step_index": step_index,
        "source_span": source_span(decl, step_index, tactic),
        "state_before": state_before,
        "tactic": tactic,
        "state_after": None,
        "lean_result": "failure",
        "error_excerpt": compact_error(output),
        "failure_type": "lean_elaboration_error",
        "graph_before_hash": graph_hash(before_graph),
        "graph_delta": delta,
        "graph_after_hash": None,
        "frontier_before": before_graph["open_frontier"],
        "frontier_after": [],
        "used_declarations": estimate_used_declarations(tactic, state_before),
        "provenance": {
            "trace_origin": "lean_state_failure",
            "extractor": "ProofNet.Extract.proofnet_state",
            "model_input_fields": ["formal_statement_header", "state_before", "frontier_before"],
            "proof_body_source_used_as_model_input": False,
        },
    }


def declaration_record(decl: Declaration) -> dict[str, Any]:
    return {
        "schema_version": "proofnet-declaration-split-1.0",
        "record_type": "declaration_split",
        "theorem_id": decl.theorem_id,
        "variant_id": decl.variant_id,
        "formal_statement_header": decl.formal_statement_header,
        "proof_body_kind": "by",
        "proof_body_source": decl.proof_body_source,
        "full_declaration_source": decl.full_declaration_source,
        "source_span": {"file": decl.source_file, "start_line": decl.start_line},
        "source_hashes": {
            "formal_statement_header_sha256": sha256_text(decl.formal_statement_header),
            "proof_body_source_sha256": sha256_text(decl.proof_body_source),
            "full_declaration_source_sha256": sha256_text(decl.full_declaration_source),
        },
        "model_input_policy": {
            "allowed_fields": ["formal_statement_header", "state_before", "frontier_before"],
            "forbidden_fields": ["proof_body_source", "full_declaration_source"],
        },
    }


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows))


def pfr_bronze_attempts(package_root: Path) -> list[dict[str, Any]]:
    verified_path = package_root / "data/proofnet_frontier_verified_subset.jsonl"
    if not verified_path.exists():
        return []
    rows = []
    for line in verified_path.read_text().splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        if row.get("id") != "F01_PFR":
            continue
        rows.append(
            {
                "schema_version": "proofnet-extraction-attempt-1.0",
                "record_type": "bronze_extraction_attempt",
                "theorem_id": "F01_PFR",
                "quality_tier": "bronze",
                "lean_result": "not_run",
                "reason": (
                    "The v05 package contains verified metadata for PFR but not the cloned PFR "
                    "source tree or Lake dependency cache. No Lean state extraction was attempted "
                    "inside the deliverable package."
                ),
                "source_metadata_present": bool(row.get("frontier_verification_v04")),
                "promote_to_silver_condition": (
                    "Run the extractor inside the cloned teorth/pfr Lake project and obtain "
                    "state_before/state_after markers for the target tactic steps."
                ),
            }
        )
    return rows


def generate_report(package_root: Path, records: list[dict[str, Any]], decls: list[Declaration]) -> str:
    real_state_records = [
        r
        for r in records
        if r.get("state_before", {}).get("goals") is not None
        and (r.get("lean_result") == "failure" or r.get("state_after", {}).get("goals") is not None)
    ]
    failures = [r for r in records if r["lean_result"] == "failure"]
    empty_deltas = [
        r
        for r in records
        if not r.get("graph_delta", {}).get("nodes_added")
        and not r.get("graph_delta", {}).get("edges_added")
        and not r.get("graph_delta", {}).get("nodes_updated")
    ]
    leakage = [
        d.theorem_id
        for d in decls
        if ":= by" in d.formal_statement_header or d.proof_body_source in d.formal_statement_header
    ]
    bronze = pfr_bronze_attempts(package_root)
    pct_empty = 0.0 if not records else 100.0 * len(empty_deltas) / len(records)
    return f"""# State Extractor Report v0.5

## Summary

- Declarations split: {len(decls)}
- Tactic records emitted: {len(records)}
- Tactic steps with real Lean states: {len(real_state_records)}
- Failure records: {len(failures)}
- Empty graph deltas: {len(empty_deltas)} ({pct_empty:.1f}%)
- Proof leakage violations detected by runner: {len(leakage)}
- PFR examples remaining bronze/source-only: {len(bronze)}

## Strict Interpretation

The controlled synthetic examples are silver: every success row contains a Lean-object-derived
`state_before` and `state_after`, and every failure row contains a Lean-object-derived pre-state plus
the Lean error excerpt. The graph deltas are partial and rule-guided, but their goal, target, and local
context nodes are derived from Lean state snapshots rather than manual labels.

PFR is not promoted to silver in this deliverable. The v04 package includes verified PFR metadata but
does not include the cloned `teorth/pfr` Lake project, so the extractor records a bronze attempt only.

## Files

- Trace JSONL: `{TRACE_RECORDS}`
- Declaration splits: `{DECL_RECORDS}`
- PFR bronze attempts: `{PFR_ATTEMPTS}`
- Validator: `scripts/validate_extracted_traces.py`
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", default=".", help="Path to the v05 package root")
    parser.add_argument("--no-failures", action="store_true", help="Do not emit candidate failure records")
    args = parser.parse_args()

    package_root = Path(args.package_root).resolve()
    records: list[dict[str, Any]] = []

    for decl in DECLARATIONS:
        for step_index, tactic in enumerate(decl.proof_steps):
            source = source_for_probe(decl, decl.proof_steps[:step_index], tactic, include_after=True)
            result = run_lean_probe(package_root, source)
            output = result.stdout + "\n" + result.stderr
            states = parse_state_markers(output)
            before = next((s for s in states if s.get("tag") == "before"), None)
            after = next((s for s in states if s.get("tag") == "after"), None)
            if result.returncode != 0 or before is None or after is None:
                raise RuntimeError(
                    f"success probe failed for {decl.theorem_id} step {step_index}: {compact_error(output)}"
                )
            records.append(make_success_record(decl, step_index, tactic, before, after))

        if not args.no_failures:
            for step_index, bad_tactic in decl.failure_candidates.items():
                source = source_for_probe(decl, decl.proof_steps[:step_index], bad_tactic, include_after=False)
                result = run_lean_probe(package_root, source)
                output = result.stdout + "\n" + result.stderr
                states = parse_state_markers(output)
                before = next((s for s in states if s.get("tag") == "before"), None)
                if result.returncode == 0:
                    raise RuntimeError(f"failure candidate unexpectedly succeeded: {decl.theorem_id} {bad_tactic}")
                if before is None:
                    raise RuntimeError(f"failure candidate did not emit pre-state: {decl.theorem_id} {bad_tactic}")
                records.append(make_failure_record(decl, step_index, bad_tactic, before, output))

    declarations = [declaration_record(d) for d in DECLARATIONS]
    write_jsonl(package_root / TRACE_RECORDS, records)
    write_jsonl(package_root / DECL_RECORDS, declarations)
    write_jsonl(package_root / PFR_ATTEMPTS, pfr_bronze_attempts(package_root))
    (package_root / REPORT_PATH).write_text(generate_report(package_root, records, DECLARATIONS))
    print(f"wrote {len(records)} trace records")
    print(f"wrote {len(declarations)} declaration split records")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
