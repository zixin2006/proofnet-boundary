import Lean
import ProofNet.Extract.State
import ProofNet.Extract.Serialize

namespace ProofNet.Extract

open Lean Elab Tactic Meta

syntax (name := proofnetStateTac) "proofnet_state" str : tactic

@[tactic proofnetStateTac]
def evalProofnetState : Tactic := fun stx => do
  let tag := stx[1].isStrLit?.getD "state"
  let goals ← getGoals
  let json ← liftMetaM <| stateSnapshotJson tag goals
  logInfo m!"{taggedJsonLine "PROOFNET_STATE" json}"

end ProofNet.Extract
