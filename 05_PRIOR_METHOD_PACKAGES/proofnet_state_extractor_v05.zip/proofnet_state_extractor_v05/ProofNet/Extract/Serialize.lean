import Lean

namespace ProofNet.Extract

open Lean

def jsonLine (json : Json) : String :=
  json.compress

def taggedJsonLine (tag : String) (json : Json) : String :=
  tag ++ " " ++ jsonLine json

end ProofNet.Extract
