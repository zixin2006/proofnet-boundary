import Lean

namespace ProofNet.Extract

open Lean Meta

/-- A normalized expression payload for model features. Node ids are kept outside this payload. -/
structure NormalizedExpr where
  pretty : String
  normalized : String
deriving Inhabited, Repr

def normalizeExprString (s : String) : String :=
  s

def exprToNormalizedJson (e : Expr) : MetaM Json := do
  let pretty := toString (← ppExpr e)
  pure <| Json.mkObj [
    ("pretty", Json.str pretty),
    ("normalized", Json.str (normalizeExprString pretty))
  ]

def levelParamsToJson (names : List Name) : Json :=
  Json.arr <| names.toArray.map (fun n => Json.str n.toString)

end ProofNet.Extract
