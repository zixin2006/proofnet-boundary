import ProofNet.Extract.Expr

namespace ProofNet.Extract

open Lean Meta

def localDeclToJson (decl : LocalDecl) : MetaM Json := do
  let typeJson ← exprToNormalizedJson decl.type
  let valueJson ←
    match decl.value? with
    | some v => pure (← exprToNormalizedJson v)
    | none => pure Json.null
  pure <| Json.mkObj [
    ("fvar_id", Json.str decl.fvarId.name.toString),
    ("user_name", Json.str decl.userName.toString),
    ("kind", Json.str (if decl.isLet then "let" else "cdecl")),
    ("type", typeJson),
    ("value", valueJson),
    ("is_implementation_detail", Json.bool decl.isImplementationDetail)
  ]

def goalToJson (goal : MVarId) : MetaM Json := do
  let goalDecl ← goal.getDecl
  let target ← instantiateMVars goalDecl.type
  let targetJson ← exprToNormalizedJson target
  let mut locals : Array Json := #[]
  for decl in goalDecl.lctx do
    if !decl.isImplementationDetail then
      locals := locals.push (← localDeclToJson decl)
  pure <| Json.mkObj [
    ("mvar_id", Json.str goal.name.toString),
    ("user_name", Json.str goalDecl.userName.toString),
    ("target", targetJson),
    ("local_context", Json.arr locals)
  ]

def stateSnapshotJson (tag : String) (goals : List MVarId) : MetaM Json := do
  let mut goalJsons : Array Json := #[]
  for goal in goals do
    goalJsons := goalJsons.push (← goalToJson goal)
  pure <| Json.mkObj [
    ("tag", Json.str tag),
    ("goals", Json.arr goalJsons)
  ]

end ProofNet.Extract
