import Lean

namespace ProofNet.Extract

inductive TacticFamily where
  | intro
  | intros
  | exact
  | assumption
  | apply
  | refine
  | constructor
  | left
  | right
  | cases
  | rcases
  | have
  | suffices
  | letDecl
  | rw
  | rfl
  | exfalso
  | contradiction
  | automationBundle
  | unsupported
deriving BEq, Repr

def TacticFamily.toString : TacticFamily -> String
  | .intro => "intro"
  | .intros => "intros"
  | .exact => "exact"
  | .assumption => "assumption"
  | .apply => "apply"
  | .refine => "refine"
  | .constructor => "constructor"
  | .left => "left"
  | .right => "right"
  | .cases => "cases"
  | .rcases => "rcases"
  | .have => "have"
  | .suffices => "suffices"
  | .letDecl => "let"
  | .rw => "rw"
  | .rfl => "rfl"
  | .exfalso => "exfalso"
  | .contradiction => "contradiction"
  | .automationBundle => "AutomationBundle"
  | .unsupported => "unsupported"

def classifyTacticHead (head : String) : TacticFamily :=
  match head with
  | "intro" => .intro
  | "intros" => .intros
  | "exact" => .exact
  | "assumption" => .assumption
  | "apply" => .apply
  | "refine" => .refine
  | "constructor" => .constructor
  | "left" => .left
  | "right" => .right
  | "cases" => .cases
  | "rcases" => .rcases
  | "have" => .have
  | "suffices" => .suffices
  | "let" => .letDecl
  | "rw" => .rw
  | "rfl" => .rfl
  | "exfalso" => .exfalso
  | "contradiction" => .contradiction
  | "simp" => .automationBundle
  | "aesop" => .automationBundle
  | "linarith" => .automationBundle
  | "omega" => .automationBundle
  | "ring" => .automationBundle
  | _ => .unsupported

structure GraphDeltaSummary where
  family : TacticFamily
  reliability : String
deriving Repr

def graphDeltaSummary (head : String) : GraphDeltaSummary :=
  let family := classifyTacticHead head
  let reliability :=
    match family with
    | .unsupported => "unknown"
    | .automationBundle => "coarse"
    | .cases | .rcases | .rw | .contradiction => "medium"
    | _ => "high"
  { family, reliability }

end ProofNet.Extract
