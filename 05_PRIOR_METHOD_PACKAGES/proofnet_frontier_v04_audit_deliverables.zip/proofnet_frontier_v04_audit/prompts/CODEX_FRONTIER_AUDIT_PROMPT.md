You are auditing and extending a Lean + ML ProofNet dataset.

Repository/package context:
- MVP v0.3 has 29 locally checked synthetic records and 58 checked variants.
- A new file `data/proofnet_frontier_research_10.jsonl` adds ten frontier/research-level external candidate records in the same schema.
- These frontier records must remain excluded from experiments until you verify them.

Your job is to build v0.4-frontier-verification.

Critical rule: do not claim any frontier record is Lean-checked unless you have cloned the referenced repository, pinned the toolchain/mathlib version, and run the relevant build or file check successfully.

Tasks:

1. Validate local files.
   Run the local JSONL validators on:
   - `data/proofnet_checked_synthetic_29.jsonl`
   - `data/proofnet_frontier_research_10.jsonl`
   - `data/proofnet_merged_checked29_plus_frontier10_candidates.jsonl`
   Check every graph edge source/target, node type, edge type, canonical hash field, and `excluded_from_v03_experiments` flag.

2. Audit Codex v0.3 outputs.
   Read:
   - `MVP_V03_REPORT.md`
   - `reports/LEAN_BACKED_CANDIDATE_SEARCH_RESULT.md`
   - `reports/CANONICALIZATION_SAFETY_V03_REPORT.md`
   - `reports/TRACE_EXTRACTION_REPORT.md`
   Write a concise assessment of what is scientifically valid and what is only a toy/scaffold result.

3. Verify frontier source availability.
   For each frontier record F01-F10:
   - open the source URL(s);
   - record repository name, license if easily visible, Lean version/toolchain if present, mathlib commit if present;
   - locate the exact theorem declaration if possible;
   - record source file path and line range;
   - determine whether the project is Lean 3 or Lean 4.

4. Clone and build only what is feasible.
   Try to clone/build a small subset first:
   - F01 PFR
   - F05 Equational Theories representative files
   - one or two Erdős records from `plby/lean-proofs`
   Do not attempt massive builds blindly. If a full repo build is too large, use file-level checks or dependency-aware subsets.

5. Extract exact theorem metadata.
   For each successfully verified source, create/update records with:
   - exact theorem name;
   - exact Lean statement;
   - source file path;
   - Lean version;
   - mathlib commit;
   - build command;
   - build result;
   - source theorem hash.

6. Extract trace-level data where feasible.
   Prefer LeanDojo or Lean 4 RPC for Lean 4 repositories. If unavailable, parse tactic blocks conservatively. Do not invent states.
   Desired schema:
   ```json
   {
     "frontier_id": "F01_PFR",
     "source_theorem": "ProbabilityTheory.PFR_conjecture",
     "step_index": 0,
     "state_before": "... or null",
     "tactic": "...",
     "state_after": "... or null",
     "used_premises": [],
     "graph_delta": {"nodes_added": [], "edges_added": []},
     "extraction_status": "lean_rpc_extracted | leandojo_extracted | parsed_no_state | failed"
   }
   ```

7. Refine proof-net graphs.
   For each frontier theorem, check whether the candidate graph in `proofnet_frontier_research_10.jsonl` actually matches the source proof architecture. Fix graphs when they are too coarse or misleading.

8. Do not merge frontier records into experiments yet.
   Only create a verified frontier subset file:
   - `data/proofnet_frontier_verified_subset.jsonl`
   Include only records that you actually built/checked.

9. Produce reports.
   Create:
   - `reports/CODEX_FRONTIER_AUDIT_REPORT.md`
   - `reports/FRONTIER_BUILD_REPORT.md`
   - `reports/FRONTIER_TRACE_EXTRACTION_REPORT.md`
   - `reports/FRONTIER_GRAPH_FIDELITY_REPORT.md`
   - `reports/FRONTIER_NEXT_STEPS.md`

10. Final answer requirements.
   In your final response, state:
   - which commands you ran;
   - which repositories were checked;
   - which frontier records are verified, partially verified, or unverified;
   - exact blockers;
   - whether any graphs were corrected;
   - whether trace extraction succeeded;
   - what remains before these records can be used in training or search evaluation.

Be strict and conservative. The right answer may be: “only 2 of 10 frontier records were verified in this run.” That is acceptable. Do not hide failures.
