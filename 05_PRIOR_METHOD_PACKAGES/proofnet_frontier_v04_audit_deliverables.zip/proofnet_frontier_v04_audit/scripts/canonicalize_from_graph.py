#!/usr/bin/env python3
"""Graph-derived canonicalization for MVP v0.3.

The structural hash in this file is intentionally computed from graph structure
and normalized graph labels only. It must not consume theorem IDs, expected
equivalence classes, or manual theorem/tactic family metadata.
"""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import re
from pathlib import Path
from typing import Any


FORBIDDEN_RECORD_FIELDS = {
    "id",
    "theorem_id",
    "variant_id",
    "theorem_name",
    "lean_name",
    "expected_equivalence_class",
    "manual_theorem_family",
    "manual_tactic_family",
    "typed_canonical_graph_payload",
    "typed_canonical_graph_hash",
}


def stable_hash(payload: Any) -> str:
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha1(encoded.encode("utf-8")).hexdigest()[:12]


def assert_graph_only(graph: dict[str, Any]) -> None:
    forbidden = sorted(FORBIDDEN_RECORD_FIELDS.intersection(graph.keys()))
    if forbidden:
        raise ValueError(
            "structural canonicalization received record-level fields instead of a graph object: "
            + ", ".join(forbidden)
        )
    if "nodes" not in graph or "edges" not in graph:
        raise ValueError("structural canonicalization requires a graph object with `nodes` and `edges`")


def normalize_label(label: str) -> str:
    value = str(label)
    value = value.replace("→", "->").replace("↔", "<->").replace("∧", "and").replace("∨", "or")
    value = value.replace("¬", "not ").replace("∃", "exists ").replace("∀", "forall ")
    value = value.replace("α", "alpha").replace("β", "beta")
    value = re.sub(r"\bh[A-Z][A-Za-z0-9_]*\b", "hLocal", value)
    value = re.sub(r"\bh[a-z][A-Za-z0-9_]*\b", "hLocal", value)
    value = re.sub(r"\bcase[A-Z][A-Za-z0-9_]*\b", "caseLocal", value)
    value = re.sub(r"\s+", " ", value.strip())
    return value


def sorted_nodes(graph: dict[str, Any]) -> list[dict[str, Any]]:
    return sorted(
        [node for node in graph.get("nodes", []) if isinstance(node, dict)],
        key=lambda node: (str(node.get("id", "")), str(node.get("type", "")), str(node.get("label", ""))),
    )


def sorted_edges(graph: dict[str, Any]) -> list[dict[str, Any]]:
    return sorted(
        [edge for edge in graph.get("edges", []) if isinstance(edge, dict)],
        key=lambda edge: (
            str(edge.get("target", "")),
            str(edge.get("type", "")),
            normalize_label(str(edge.get("label", ""))),
            tuple(str(source) for source in edge.get("sources", [])),
        ),
    )


def literal_graph_payload(graph: dict[str, Any]) -> dict[str, Any]:
    assert_graph_only(graph)
    return {
        "level": graph.get("level"),
        "nodes": sorted_nodes(graph),
        "edges": sorted_edges(graph),
    }


def literal_graph_hash(graph: dict[str, Any]) -> str:
    return stable_hash(literal_graph_payload(graph))


def shape_graph_payload(graph: dict[str, Any]) -> dict[str, Any]:
    assert_graph_only(graph)
    nodes = sorted_nodes(graph)
    edges = sorted_edges(graph)
    node_ids = [str(node.get("id", "")) for node in nodes]
    node_types = {str(node.get("id", "")): str(node.get("type", "")) for node in nodes}
    adjacency = collections.defaultdict(lambda: {"out": [], "in": []})
    for edge in edges:
        target = str(edge.get("target", ""))
        edge_type = str(edge.get("type", ""))
        for source in edge.get("sources", []):
            source = str(source)
            adjacency[source]["out"].append((edge_type, node_types.get(target, "<missing>")))
            adjacency[target]["in"].append((edge_type, node_types.get(source, "<missing>")))
    node_shapes = []
    for node_id in node_ids:
        node_shapes.append(
            {
                "type": node_types.get(node_id, "<missing>"),
                "in": sorted(adjacency[node_id]["in"]),
                "out": sorted(adjacency[node_id]["out"]),
            }
        )
    edge_shapes = [
        {
            "type": str(edge.get("type", "")),
            "arity": len(edge.get("sources", [])),
            "source_types": sorted(node_types.get(str(source), "<missing>") for source in edge.get("sources", [])),
            "target_type": node_types.get(str(edge.get("target", "")), "<missing>"),
        }
        for edge in edges
    ]
    return {
        "node_shapes": sorted(node_shapes, key=lambda item: json.dumps(item, sort_keys=True)),
        "edge_shapes": sorted(edge_shapes, key=lambda item: json.dumps(item, sort_keys=True)),
    }


def shape_graph_hash(graph: dict[str, Any]) -> str:
    return stable_hash(shape_graph_payload(graph))


def graph_case_depth(graph: dict[str, Any]) -> int:
    nodes = sorted_nodes(graph)
    edges = sorted_edges(graph)
    node_type = {str(node.get("id", "")): str(node.get("type", "")) for node in nodes}
    children = collections.defaultdict(list)
    for edge in edges:
        if str(edge.get("type", "")) != "caseSplit":
            continue
        for source in edge.get("sources", []):
            children[str(source)].append(str(edge.get("target", "")))

    case_nodes = [node_id for node_id, typ in node_type.items() if typ == "caseNode"]

    def depth(node_id: str, seen: set[str]) -> int:
        if node_id in seen:
            return 0
        child_depths = [depth(child, seen | {node_id}) for child in children.get(node_id, [])]
        current = 1 if node_type.get(node_id) == "caseNode" else 0
        return current + (max(child_depths) if child_depths else 0)

    return max([depth(node_id, set()) for node_id in case_nodes] or [0])


def structural_node_signature(node: dict[str, Any]) -> dict[str, str]:
    return {
        "type": str(node.get("type", "")),
        "label": normalize_label(str(node.get("label", ""))),
    }


def structural_edge_signature(edge: dict[str, Any], node_types: dict[str, str], node_labels: dict[str, str]) -> dict[str, Any]:
    source_ids = [str(source) for source in edge.get("sources", [])]
    return {
        "type": str(edge.get("type", "")),
        "label": normalize_label(str(edge.get("label", ""))),
        "arity": len(source_ids),
        "sources": sorted(
            ({
                "type": node_types.get(source, "<missing>"),
                "label": node_labels.get(source, "<missing>"),
            }
            for source in source_ids),
            key=lambda item: json.dumps(item, sort_keys=True),
        ),
        "target": {
            "type": node_types.get(str(edge.get("target", "")), "<missing>"),
            "label": node_labels.get(str(edge.get("target", "")), "<missing>"),
        },
    }


def structural_canonical_payload(graph: dict[str, Any]) -> dict[str, Any]:
    assert_graph_only(graph)
    nodes = sorted_nodes(graph)
    edges = sorted_edges(graph)
    node_types = {str(node.get("id", "")): str(node.get("type", "")) for node in nodes}
    node_labels = {str(node.get("id", "")): normalize_label(str(node.get("label", ""))) for node in nodes}
    type_counts = collections.Counter(node_types.values())
    labels_by_type = collections.defaultdict(list)
    for node in nodes:
        labels_by_type[str(node.get("type", ""))].append(normalize_label(str(node.get("label", ""))))
    return {
        "level": graph.get("level", "coarse"),
        "node_type_counts": dict(sorted(type_counts.items())),
        "labels_by_type": {key: sorted(values) for key, values in sorted(labels_by_type.items())},
        "case_tree_depth": graph_case_depth(graph),
        "nodes": sorted(
            [structural_node_signature(node) for node in nodes],
            key=lambda item: json.dumps(item, sort_keys=True),
        ),
        "edges": sorted(
            [structural_edge_signature(edge, node_types, node_labels) for edge in edges],
            key=lambda item: json.dumps(item, sort_keys=True),
        ),
    }


def structural_canonical_graph_hash(graph: dict[str, Any]) -> str:
    return stable_hash(structural_canonical_payload(graph))


def compute_graph_hashes(graph: dict[str, Any]) -> dict[str, str]:
    return {
        "literal_graph_hash": literal_graph_hash(graph),
        "shape_graph_hash": shape_graph_hash(graph),
        "structural_canonical_graph_hash": structural_canonical_graph_hash(graph),
    }


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, records: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_jsonl", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()

    records = read_jsonl(args.input_jsonl)
    enriched = []
    for record in records:
        graph = record.get("graph")
        if not isinstance(graph, dict):
            raise ValueError(f"record {record.get('id') or record.get('theorem_id')} has no graph")
        item = dict(record)
        item.update(compute_graph_hashes(graph))
        item["canonical_graph_id"] = item["structural_canonical_graph_hash"]
        item["canonical_graph_id_policy"] = "structural_canonical_graph_hash_v03_from_graph_only"
        enriched.append(item)

    write_jsonl(args.output, enriched)
    groups = collections.defaultdict(list)
    for record in enriched:
        groups[record["structural_canonical_graph_hash"]].append(record.get("id") or record.get("theorem_id"))
    collision_groups = {key: value for key, value in groups.items() if len(value) > 1}
    lines = [
        "# Canonicalization v0.3 Report",
        "",
        "The v0.3 structural hash is computed from graph structure and normalized graph labels only.",
        "",
        f"- Input records: {len(records)}",
        f"- Output records: {len(enriched)}",
        f"- Unique structural hashes: {len(groups)}",
        f"- Structural collision groups: {len(collision_groups)}",
        "",
        "## Collision Groups",
        "",
    ]
    if not collision_groups:
        lines.append("None.")
    else:
        for key, value in sorted(collision_groups.items()):
            lines.append(f"- `{key}`: {', '.join(map(str, value))}")
    lines.extend(
        [
            "",
            "## Forbidden Inputs",
            "",
            "The structural canonicalizer accepts only a graph object. It raises an error if record-level keys such as `theorem_id`, `expected_equivalence_class`, `manual_theorem_family`, or `manual_tactic_family` are passed to the structural hash function.",
            "",
        ]
    )
    args.report.write_text("\n".join(lines), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
