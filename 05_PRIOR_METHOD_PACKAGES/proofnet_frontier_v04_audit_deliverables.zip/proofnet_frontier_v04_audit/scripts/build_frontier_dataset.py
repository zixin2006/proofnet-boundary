#!/usr/bin/env python3
from __future__ import annotations
import json, hashlib, sys, shutil, textwrap
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))
from canonicalize_from_graph import compute_graph_hashes

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT/'data'
REPORTS = ROOT/'reports'
PROMPTS = ROOT/'prompts'


def stable_hash(payload):
    return hashlib.sha1(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',',':')).encode()).hexdigest()[:12]


def graph(record_id, level, nodes, edges):
    return {'level': level, 'nodes': nodes, 'edges': edges}


def node(id,label,type):
    return {'id':id,'label':label,'type':type}

def edge(sources,target,type,label):
    return {'sources':sources,'target':target,'type':type,'label':label}


def base_record(id, domain, theorem_name, informal, lean_label, lean_statement, source_project, source_urls, source_status, redundancy, tactic_set, graph_obj, graph_notes, difficulty, proofnet_benefit, source_evidence):
    hashes = compute_graph_hashes(graph_obj)
    complexity = {
        'estimated_tactic_steps_min': None,
        'branching_factor': 'high' if 'high' in redundancy.lower() or 'many' in redundancy.lower() else 'medium',
        'graph_nodes': len(graph_obj['nodes']),
        'graph_edges': len(graph_obj['edges']),
        'realism_level': 'frontier/research-level external source; not locally compiled in this package',
        'needs_trace_extraction': True,
    }
    return {
        'id': id,
        'origin': 'frontier_research_extension_v1_external_sources',
        'domain': domain,
        'training_stage': 'S3_frontier_external_candidate_not_for_v03_experiments',
        'theorem_name': theorem_name,
        'informal_statement': informal,
        'lean_label': lean_label,
        'lean_statement': lean_statement,
        'lean_statement_status': 'source_snippet_or_summary; Codex must fetch exact theorem declaration when source_code_url is available',
        'check_status': source_status,
        'proof_variant_count': 0,
        'abstraction_type': 'frontier proof-net dependency graph candidate',
        'redundancy_type': redundancy,
        'difficulty': difficulty,
        'tactic_set': tactic_set,
        'positive_proof_variants': [
            {'name': 'external_source_proof', 'script': 'Fetch from source_code_url and extract tactic/term proof traces with LeanDojo/RPC. Not bundled here.'}
        ],
        'negative_branches': [
            {'type': 'frontier_near_miss', 'description': 'Potential wrong lemma, wrong rewrite orientation, incompatible coercion/transport, wrong case split, or stale imported theorem. Generate via Lean-backed candidate checking after cloning the source repository.'}
        ],
        'graph': graph_obj,
        'canonicalization': graph_notes,
        'complexity': complexity,
        'source_project': source_project,
        'source_urls': source_urls,
        'source_evidence': source_evidence,
        'proofnet_expected_benefit': proofnet_benefit,
        'excluded_from_v03_experiments': True,
        'frontier_integration_policy': 'Keep separate from checked synthetic records until Codex clones/builds the source repository and extracts real traces.',
        'literal_graph_hash': hashes['literal_graph_hash'],
        'shape_graph_hash': hashes['shape_graph_hash'],
        'structural_canonical_graph_hash': hashes['structural_canonical_graph_hash'],
        'canonical_graph_id': hashes['structural_canonical_graph_hash'],
        'canonical_graph_id_policy': 'structural_canonical_graph_hash_v03_from_candidate_graph_only',
        'canonicalization_policy_v03': 'hashes are computed from candidate graph structure and labels only; record remains external and unverified until source repository is built and traces are extracted',
        'legacy_canonical_graph_id': None,
        'legacy_typed_canonical_graph_hash_v02': None,
    }

records=[]

records.append(base_record(
    'F01_PFR', 'additive_combinatorics_information_theory',
    'Polynomial Freiman--Ruzsa conjecture over elementary abelian 2-groups',
    'If A is a nonempty finite subset of an elementary abelian 2-group with small doubling |A+A| ≤ K|A|, then A is covered by fewer than 2K^12 cosets of a subspace H with |H| ≤ |A|.',
    'ProbabilityTheory.PFR_conjecture',
    'theorem PFR_conjecture (hA₀ : A.Nonempty) (hA : (A + A).ncard ≤ K * A.ncard) : ∃ (H : Submodule (ZMod 2) G) (c : Set G), Nat.card c < 2 * K ^ 12 ∧ (H : Set G).ncard ≤ A.ncard ∧ A ⊆ c + H := by ...',
    'teorth/pfr',
    {'project':'https://teorth.github.io/pfr/','source_code':'https://github.com/teorth/pfr/blob/master/PFR/Main.lean'},
    'external_open_source_lean4_reported_completed_not_locally_checked',
    'high: entropy inequalities, Ruzsa covering, subgroup/coset choice, and arithmetic estimates create many reusable independent proof components',
    ['obtain','have','calc','gcongr','rw','linarith','positivity','exact','refine'],
    graph('F01','frontier_candidate',[
        node('A','finite nonempty set A in elementary abelian 2-group','hypothesis'),
        node('doubling','small-doubling hypothesis |A+A| ≤ K|A|','hypothesis'),
        node('entropy','Shannon entropy / information inequalities','lemmaCluster'),
        node('ruzsa','Ruzsa covering lemma and sumset estimates','lemmaCluster'),
        node('aux','PFR auxiliary subgroup/coset construction','intermediate'),
        node('H','chosen submodule H and coset set c','witness'),
        node('card','cardinality inequalities for c and H','subgoal'),
        node('cover','A ⊆ c + H','subgoal'),
        node('goal','PFR_conjecture conclusion','conclusion')],
        [edge(['A','doubling'],'entropy','uses','small doubling feeds entropy estimates'),
         edge(['entropy','ruzsa'],'aux','assembles','auxiliary theorem combines information and covering arguments'),
         edge(['aux'],'H','creates','obtain subgroup and coset witnesses'),
         edge(['H','doubling'],'card','proves','numeric exponent/cardinality obligations'),
         edge(['H'],'cover','proves','covering obligation'),
         edge(['card','cover'],'goal','combines','existential conclusion')]),
    ['Canonicalize independent numeric inequalities and covering witnesses separately from final existential assembly. Preserve exponent labels 12/11/9 and subgroup/coset orientation.'],
    'frontier: completed research-level Lean4 formalization, additive combinatorics + information theory',
    'Proof-net guidance should expose independent entropy, covering, subgroup-selection, and numeric inequality subgraphs; a local tactic model will repeatedly re-discover similar calc/gcongr/rw/linarith branches.',
    ['PFR project site states it is a Lean4 formalization and gives the theorem statement and current extensions.', 'PFR/Main.lean contains theorem PFR_conjecture and the final existential coset-covering statement.']
))

records.append(base_record(
    'F02_LTE', 'condensed_mathematics_homological_algebra',
    'Liquid Tensor Experiment: Ext vanishing for p-measures into p-Banach spaces',
    'For 0 < p′ < p ≤ 1, profinite S, and p-Banach V, Ext^i(𝓜_{p′}(S), V) = 0 for i > 0 in condensed abelian groups.',
    'liquid_tensor_experiment',
    'theorem liquid_tensor_experiment (S : Profinite.{0}) (V : pBanach.{0} p) : ∀ i > 0, Ext i (ℳ_{p\'} S) V ≅ 0 := begin ... end',
    'leanprover-community/lean-liquid',
    {'project':'https://github.com/leanprover-community/lean-liquid','source_code':'https://github.com/leanprover-community/lean-liquid/blob/master/src/challenge.lean','blueprint':'https://leanprover-community.github.io/liquid/'},
    'external_open_source_lean3_reported_completed_not_locally_checked',
    'very high: category-theory reductions, exact sequences, Ext vanishing, isomorphism transports, and choice of Banach structures generate non-linear proof dependencies',
    ['intros','apply','revert','haveI','erw','let','convert','intro','rw'],
    graph('F02','frontier_candidate',[
        node('params','0 < p′ < p ≤ 1 and S profinite','hypothesis'),
        node('V','p-Banach space V','hypothesis'),
        node('M','p′-measure object ℳ_{p′}(S)','construction'),
        node('Ext','Ext i (ℳ_{p′} S) V target','goal'),
        node('shortExact','Laurent-measures short exact sequence','lemma'),
        node('epiIso','epi and isomorphism criterion for Ext vanishing','lemma'),
        node('banachChoice','chosen seminormed/normed structures on V','construction'),
        node('transport','coercion/isomorphism/rewrite transports','rewrite'),
        node('goal','Ext-vanishing conclusion','conclusion')],
        [edge(['params'],'M','creates','construct measure object'),
         edge(['M','V'],'Ext','creates','target Ext goal'),
         edge(['shortExact','Ext'],'epiIso','reduces','Ext vanishing reduced to epi/is_iso obligations'),
         edge(['params','V'],'banachChoice','creates','choose needed Banach structures'),
         edge(['banachChoice'],'transport','rewrites','normalize chosen structure terms'),
         edge(['epiIso','transport'],'goal','combines','convert final theorem')]),
    ['Canonicalize independent exactness, isomorphism, and transport subgraphs. Preserve category/object universe labels and map orientation.'],
    'frontier: condensed mathematics, homological algebra, analysis; completed Lean project',
    'The proof-net effect should appear in diagram/exactness bureaucracy: many commuting reductions and transports are order-insensitive but semantically structured.',
    ['Lean-liquid challenge.lean states the Clausen--Scholze theorem and contains the Lean theorem liquid_tensor_experiment.', 'LTE final reports state the main theorem as Ext-vanishing for p-measures.']
))

records.append(base_record(
    'F03_FLT_REGULAR', 'algebraic_number_theory',
    'Fermat’s Last Theorem for regular prime exponents',
    'Kummer-style proof that Fermat’s equation has no nontrivial solutions for regular prime exponents.',
    'FltRegular.FltRegular / flt_regular_case_one family',
    'EXTERNAL_SOURCE: repository states that FltRegular/FltRegular.lean contains the theorem statement; Codex should fetch exact declaration.',
    'leanprover-community/flt-regular',
    {'project':'https://github.com/leanprover-community/flt-regular','source_code_hint':'FltRegular/FltRegular.lean'},
    'external_open_source_lean4_project_not_locally_checked',
    'very high: regularity, class-group/cyclotomic arithmetic, unit arguments, ideal divisibility, and case distinctions form a large dependency network',
    ['apply','rw','simp','have','exact','refine','obtain','by_cases','ring_nf','norm_num'],
    graph('F03','frontier_candidate',[
        node('p','regular prime exponent p','hypothesis'),
        node('eq','hypothetical Fermat solution x^p+y^p=z^p','hypothesis'),
        node('cyclo','cyclotomic integer factorization','construction'),
        node('ideal','ideal/class-group divisibility arguments','lemmaCluster'),
        node('kummer','Kummer obstruction eliminated by regularity','lemmaCluster'),
        node('cases','case analysis on divisibility/first-case obligations','caseNode'),
        node('contr','derive contradiction','conclusion'),
        node('goal','FLT regular-prime conclusion','conclusion')],
        [edge(['eq'],'cyclo','creates','factor Fermat equation cyclotomically'),
         edge(['cyclo'],'ideal','uses','ideal factorization and divisibility'),
         edge(['p','ideal'],'kummer','uses','regularity kills class-group obstruction'),
         edge(['eq','kummer'],'cases','splits','divisibility case structure'),
         edge(['cases'],'contr','closes','derive contradiction'),
         edge(['contr'],'goal','proves','no nontrivial solution')]),
    ['Canonicalize independent ideal-divisibility lemmas and first/second case subproofs. Preserve prime regularity, ideal orientation, and contradiction target.'],
    'frontier: algebraic number theory formalization project',
    'Proof-net search should help because many class-group, ideal, and divisibility lemmas are reusable and can be scheduled in different orders before the final contradiction.',
    ['Repository README states the goal is proving FLT for regular primes in Lean and that FltRegular/FltRegular.lean contains the theorem statement.']
))

records.append(base_record(
    'F04_KUMMER_CRITERION', 'computational_algebraic_number_theory',
    'Kummer criterion and FLT for most exponents up to 100',
    'An odd prime p is regular iff p does not divide the numerator of Bernoulli numbers B₂, B₄, …, B_{p−3}; combined with regular-prime FLT, this yields many finite exponent cases.',
    '_root_.KummerCriterion / fermatLastTheoremFor_le100_of_ne_irregular',
    'theorem _root_.KummerCriterion {p : ℕ} [hp : Fact p.Prime] (hp_odd : p ≠ 2) : IsRegularPrime p ↔ ∀ k, 1 ≤ k → 2 * k ≤ p - 3 → ¬ (p : ℤ) ∣ (bernoulli (2 * k)).num := ...',
    'riccardobrasca/KummerCriterion',
    {'project':'https://github.com/riccardobrasca/KummerCriterion','source_code_hint':'KummerCriterion/BernoulliFast/FermatLastTheoremUpTo100.lean'},
    'external_open_source_lean4_project_not_locally_checked',
    'high: Bernoulli-number computations, divisibility tests, regularity equivalence, finite exception management, and FLT imports create modular proof graphs',
    ['simp','norm_num','omega','interval_cases','rw','exact','apply','fin_cases'],
    graph('F04','frontier_candidate',[
        node('p','odd prime p','hypothesis'),
        node('bernoulli','Bernoulli numerators B_{2k}.num','construction'),
        node('criterion','KummerCriterion equivalence','lemma'),
        node('finiteCheck','finite divisibility computations for p < 100','computation'),
        node('regularity','IsRegularPrime p','intermediate'),
        node('exceptions','irregular-prime exclusions 37,59,67,74','caseNode'),
        node('fltRegular','FLT for regular prime exponents','lemma'),
        node('goal','FermatLastTheoremFor n under finite conditions','conclusion')],
        [edge(['p','bernoulli'],'criterion','uses','regularity iff Bernoulli divisibility'),
         edge(['criterion','finiteCheck'],'regularity','proves','compute regularity'),
         edge(['regularity','exceptions'],'fltRegular','uses','route non-exception cases to regular-prime FLT'),
         edge(['fltRegular'],'goal','closes','finite-range FLT conclusion')]),
    ['Canonicalize finite computation branches separately from imported regular-prime FLT theorem. Preserve exception set and divisibility direction.'],
    'frontier-adjacent: computational algebraic number theory linked to FLT formalization',
    'Proof-net graphs can separate computation certificates from algebraic theorem dependencies, preventing search from mixing finite exception casework with abstract regularity lemmas.',
    ['KummerCriterion README states the theorem KummerCriterion and a packaged FLT-up-to-100 theorem.']
))

records.append(base_record(
    'F05_EQUATIONAL_THEORIES', 'universal_algebra_automated_reasoning',
    'Equational Theories Project implication graph for magma laws',
    'Determine implications and non-implications among 4694 simple single-equation magma laws, producing a large formally validated implication graph.',
    'equational_theories implication/countermodel certificates',
    'EXTERNAL_SOURCE: project has many generated Lean declarations/certificates; Codex should pick representative implication and non-implication theorem files.',
    'teorth/equational_theories',
    {'project':'https://github.com/teorth/equational_theories','website':'https://teorth.github.io/equational_theories/'},
    'external_open_source_lean4_project_not_locally_checked',
    'extremely high: millions of implication/non-implication edges, symmetry quotienting, term rewriting, finite model certificates, and proof/countermodel duality',
    ['simp','rw','exact','apply','aesop','tauto','first_order','native_decide'],
    graph('F05','frontier_candidate',[
        node('lawA','source magma equation/law A','hypothesis'),
        node('lawB','target magma equation/law B','goal'),
        node('rewrite','term rewriting / equational derivation','lemmaCluster'),
        node('symmetry','duality/symmetry/relabeling quotient','canonicalizationNode'),
        node('model','finite countermodel certificate for non-implication','witness'),
        node('implication','A implies B certificate','conclusion'),
        node('nonimp','A does not imply B certificate','conclusion'),
        node('graph','global implication graph','conclusion')],
        [edge(['lawA','rewrite'],'implication','proves','equational derivation'),
         edge(['lawA','lawB','model'],'nonimp','refutes','finite magma countermodel'),
         edge(['symmetry','implication','nonimp'],'graph','assembles','global quotient implication graph')]),
    ['Canonicalize laws modulo symmetry/relabeling, but preserve proof/countermodel distinction. This is closest to literal proof-net quotienting of bureaucratic derivation order.'],
    'frontier: recent collaborative Lean-first mathematical exploration',
    'This is almost tailor-made for proof nets: the core object is already a graph of implications, with many equivalent derivations and countermodel certificates that should be quotiented structurally.',
    ['Project README states it explores 4694 magma laws ordered by implication.', 'The ETP paper reports all 22,028,942 edges validated by Lean.']
))

records.append(base_record(
    'F06_QUANTUM_STEIN', 'quantum_information_operator_algebra',
    'Generalized Quantum Stein’s Lemma in Lean-QuantumInfo',
    'Operational characterization of regularized relative entropy through asymptotic quantum hypothesis testing in resource theories.',
    'limit_hypotesting_eq_limit_rel_entropy',
    'theorem limit_hypotesting_eq_limit_rel_entropy (ρ : MState (H i)) (ε : Prob) (hε : 0 < ε ∧ ε < 1) : ∃ rate : ℝ≥0, Filter.atTop.Tendsto (...) ...',
    'Timeroot/Lean-QuantumInfo / Physlib',
    {'project':'https://github.com/Timeroot/Lean-QuantumInfo','source_code_hint':'QuantumInfo/Finite/ResourceTheory/SteinsLemma.lean','paper':'https://arxiv.org/abs/2510.08672'},
    'external_open_source_lean4_reported_completed_not_locally_checked',
    'very high: tensor products, free-state closure, POVM optimization, ENNReal/limit transports, compactness/convexity assumptions, and entropy inequalities interact nonlinearly',
    ['rw','simp','have','apply','refine','exact','convert','tendsto','linarith','positivity'],
    graph('F06','frontier_candidate',[
        node('rho','null-hypothesis mixed state ρ','hypothesis'),
        node('eps','error tolerance ε with 0<ε<1','hypothesis'),
        node('free','sequence of free-state sets / resource theory axioms','hypothesis'),
        node('povm','restricted two-outcome POVM optimization','construction'),
        node('beta','minimal type-II error β_ε','construction'),
        node('entropy','regularized relative entropy expression','construction'),
        node('limits','two Tendsto/limit statements to same rate','subgoal'),
        node('rate','existential rate witness','witness'),
        node('goal','Generalized Quantum Stein lemma conclusion','conclusion')],
        [edge(['rho','eps','free'],'povm','creates','hypothesis-testing protocol'),
         edge(['povm'],'beta','defines','type-II error optimization'),
         edge(['rho','free'],'entropy','defines','relative entropy variational side'),
         edge(['beta','entropy'],'limits','proves','both asymptotic limits converge to same rate'),
         edge(['limits'],'rate','creates','existential rate'),
         edge(['rate'],'goal','closes','final equivalence/convergence theorem')]),
    ['Canonicalize independent limit, entropy, compactness, and optimization subgraphs. Preserve ENNReal/Prob coercions and tensor product orientation.'],
    'frontier: quantum information theorem, Lean4 repository, operator algebra/topology dependencies',
    'Proof-net guidance is useful because a local tactic search can drown in coercion/transport and limit/entropy side conditions; the graph separates analytic, algebraic, and order-theoretic obligations.',
    ['Lean-QuantumInfo README says the Generalized Quantum Stein lemma was completed and names the final theorem.', 'The paper describes the formalization and states the theorem in Lean.']
))

records.append(base_record(
    'F07_ERDOS_848', 'number_theory_extremal_combinatorics',
    'Erdős Problem 848: non-squarefree products ab+1 and extremal residue classes',
    'For large N, sets A whose products ab+1 are never squarefree are bounded by residue-class extremal examples modulo 25.',
    'Erdos848.erdos_848.variants.asymptotic',
    'theorem erdos_848.variants.asymptotic : ∀ᶠ N in Filter.atTop, Erdos848For N := by ...',
    'The-Obstacle-Is-The-Way/erdos-banger via FormalConjectures',
    {'formal_statement':'https://github.com/google-deepmind/formal-conjectures/blob/main/FormalConjectures/ErdosProblems/848.lean','source_code':'https://github.com/The-Obstacle-Is-The-Way/erdos-banger/blob/1cc2ac8e9d70516e979733c6ea5c4d2eb652d1f5/formal/lean/Erdos/848.lean'},
    'external_open_source_lean4_reported_complete_asymptotic_result_not_locally_checked',
    'high: squarefree obstructions, modular residue classes, density estimates, finite-set bounds, and eventual-atTop quantifiers interact',
    ['simp','omega','linarith','norm_num','rw','apply','filter_mono','eventually'],
    graph('F07','frontier_candidate',[
        node('A','finite set A ⊆ range N','hypothesis'),
        node('prop','∀a,b∈A, ¬Squarefree(a*b+1)','hypothesis'),
        node('residue','candidate residue classes n≡7 or 18 mod 25','construction'),
        node('density','large-N density/largeness assumptions','lemmaCluster'),
        node('squarefree','squarefree obstruction lemmas','lemmaCluster'),
        node('bound','cardinality bound A.card ≤ A₇(N).card','subgoal'),
        node('eventual','eventual-atTop wrapper','conclusion')],
        [edge(['A','prop'],'squarefree','uses','turn product property into modular obstruction'),
         edge(['squarefree'],'residue','constrains','force residue-class containment'),
         edge(['residue','density'],'bound','proves','cardinality estimate'),
         edge(['bound'],'eventual','wraps','∀ᶠ N conclusion')]),
    ['Canonicalize modular case splits and density estimates independently. Preserve residue class labels 7/18 mod 25 and squarefree negation.'],
    'frontier/recent Erdős problem: asymptotic result with Lean formal proof pointer',
    'Good proof-net case because modular obstruction and density/cardinality branches commute, but wrong residue/squarefree direction creates near-miss branches.',
    ['FormalConjectures page states the asymptotic theorem and gives complete formal proof URL.', 'It defines NonSquarefreeProductProp and Erdos848For.']
))

records.append(base_record(
    'F08_ERDOS_1026', 'extremal_combinatorics_sequences',
    'Erdős Problem 1026: generalized Erdős--Szekeres sequence problem',
    'A recently solved problem generalizing Erdős--Szekeres-type increasing/decreasing subsequence bounds, with Lean-verified proof in plby/lean-proofs.',
    'Erdos1026 theorem family',
    'EXTERNAL_SOURCE: Erdos1026.lean contains many theorem declarations; Codex should identify final exported theorem and exact statement after cloning.',
    'plby/lean-proofs',
    {'source_code':'https://github.com/plby/lean-proofs/blob/main/src/v4.24.0/ErdosProblems/Erdos1026.lean','repo':'https://github.com/plby/lean-proofs'},
    'external_open_source_lean4_verified_according_to_source_not_locally_checked',
    'high: sequence construction, increasing/decreasing subsequence maxima, block decompositions, inequalities, and case splits create many equivalent proof schedules',
    ['aesop','linarith','nlinarith','simp','rw','exact','obtain','refine','by_contra'],
    graph('F08','frontier_candidate',[
        node('seq','finite real sequence/list construction','construction'),
        node('inc','maximum increasing subsequence statistic M_inc','construction'),
        node('dec','maximum decreasing subsequence statistic M_dec','construction'),
        node('blocks','block decomposition / ε-perturbed construction','construction'),
        node('ineq','sum-of-squares and area inequalities','lemmaCluster'),
        node('append','append/sorted-subsequence lemmas','lemmaCluster'),
        node('extreme','extremal bound/counterexample target','conclusion')],
        [edge(['seq'],'inc','defines','increasing subsequence measure'),
         edge(['seq'],'dec','defines','decreasing subsequence measure'),
         edge(['blocks'],'seq','creates','explicit sequence construction'),
         edge(['inc','dec','ineq'],'extreme','proves','extremal inequality conclusion'),
         edge(['append','blocks'],'inc','uses','append lemmas for increasing side'),
         edge(['append','blocks'],'dec','uses','append lemmas for decreasing side')]),
    ['Canonicalize inc/dec dual subgraphs and append/block lemmas modulo symmetry; preserve direction of < versus > and sum statistic.'],
    'frontier/recent collaborative Erdős problem formalization, verified by Lean per source comment',
    'This is a strong proof-net benchmark: inc and dec branches are dual/symmetric, block lemmas repeat, and tactic scripts likely contain substantial aesop/simp bureaucracy.',
    ['Erdos1026.lean states it is a Lean formalization of a solution and says the proof is verified by Lean with exact Lean/Mathlib versions.']
))

records.append(base_record(
    'F09_ERDOS_541', 'additive_combinatorics_zero_sum',
    'Erdős Problem 541 / Graham conjecture: distinct length modular zero-sum subsequences',
    'For residues a_i modulo a prime p, if all nonempty zero-sum subsequences have the same cardinality r, then at most two distinct residues occur.',
    'Erdos541.erdos_541',
    'theorem erdos_541 : answer(True) ↔ (∀ p, Fact p.Prime → ∀ (a : Fin p → ZMod p), (∃ r, ∀ (S : Finset (Fin p)), S ≠ ∅ → ∑ i ∈ S, a i = 0 → S.card = r) → (Set.range a).ncard ≤ 2) := by ...',
    'plby/lean-proofs via FormalConjectures',
    {'formal_statement':'https://github.com/google-deepmind/formal-conjectures/blob/main/FormalConjectures/ErdosProblems/541.lean','source_code':'https://github.com/plby/lean-proofs/blob/main/src/v4.24.0/ErdosProblems/Erdos541.lean'},
    'external_open_source_lean4_reported_formal_proof_not_locally_checked',
    'high: finite subsets, zero-sum equations in ZMod p, cardinality constraints, range/ncard bounds, and prime/modulus generalization',
    ['simp','rw','fin_cases','by_cases','omega','linarith','exact','apply','card_mono'],
    graph('F09','frontier_candidate',[
        node('p','prime modulus p','hypothesis'),
        node('a','sequence a : Fin p → ZMod p','hypothesis'),
        node('zeroSum','zero-sum subset condition ∑_{i∈S} a_i = 0','hypothesis'),
        node('sameLen','all nonempty zero-sum subsets have same card r','hypothesis'),
        node('comb','additive-combinatorial zero-sum lemmas','lemmaCluster'),
        node('range','range/cardinality of values of a','subgoal'),
        node('goal','(Set.range a).ncard ≤ 2','conclusion')],
        [edge(['p','a','zeroSum','sameLen'],'comb','uses','zero-sum structure under prime modulus'),
         edge(['comb'],'range','proves','value-set cardinality bound'),
         edge(['range'],'goal','closes','at most two residues')]),
    ['Canonicalize subset-cardinality branches modulo Finset order. Preserve prime modulus, zero-sum equation orientation, and nonempty condition.'],
    'research-level additive combinatorics Erdős problem with external Lean4 proof pointer',
    'Proof-net abstraction should help because many Finset/cardinality obligations commute and the central zero-sum dependency should be exposed separately from bookkeeping.',
    ['FormalConjectures gives the theorem statement and formal_proof Lean4 URL for Erdos541.']
))

records.append(base_record(
    'F10_ERDOS_229', 'complex_analysis_interpolation',
    'Erdős Problem 229: entire transcendental function with derivative zeros on prescribed discrete sets',
    'For a sequence of complex sets with no finite limit points, construct a transcendental entire function whose suitable iterated derivatives vanish on each set.',
    'Erdos229.erdos_229 / theorem_1',
    'theorem erdos_229 : letI := Polynomial.algebraPi ℂ ℂ ℂ; answer(True) ↔ ∀ (S : ℕ → Set ℂ), (∀ n, derivedSet (S n) = ∅) → ∃ (f : ℂ → ℂ), Transcendental (Polynomial ℂ) f ∧ Differentiable ℂ f ∧ ∀ n ≥ 1, ∃ k, ∀ z ∈ S n, iteratedDeriv k f z = 0 := by ...',
    'plby/lean-proofs via FormalConjectures',
    {'formal_statement':'https://github.com/google-deepmind/formal-conjectures/blob/main/FormalConjectures/ErdosProblems/229.lean','source_code':'https://github.com/plby/lean-proofs/blob/main/src/v4.24.0/ErdosProblems/Erdos229.lean'},
    'external_open_source_lean4_reported_formal_proof_not_locally_checked',
    'very high: discrete-set topology, entire/differentiable functions, transcendence, iterated derivatives, and existential construction layers',
    ['apply','rw','simp','exact','use','refine','have','funext','continuity','differentiability'],
    graph('F10','frontier_candidate',[
        node('S','sequence S_n of complex sets','hypothesis'),
        node('discrete','derivedSet(S_n)=∅ no finite limit point','hypothesis'),
        node('construct','construct transcendental entire function f','witness'),
        node('diff','Differentiable ℂ f','subgoal'),
        node('trans','Transcendental (Polynomial ℂ) f','subgoal'),
        node('deriv','iterated derivative vanishing witnesses k_n','witness'),
        node('forall','∀ n ≥ 1 and ∀ z∈S_n obligations','subgoal'),
        node('goal','Erdős 229 conclusion','conclusion')],
        [edge(['S','discrete'],'construct','uses','interpolation/existence theorem'),
         edge(['construct'],'diff','proves','entire/differentiable property'),
         edge(['construct'],'trans','proves','transcendence property'),
         edge(['construct','S'],'deriv','creates','choose derivative order k_n'),
         edge(['deriv'],'forall','proves','vanishing on each S_n'),
         edge(['diff','trans','forall'],'goal','combines','existential conjunction')]),
    ['Canonicalize existential witness branches for f and k_n separately from analytic property subgoals. Preserve differentiability/transcendence/vanishing distinctions.'],
    'research-level complex analysis/function theory Erdős problem with Lean proof pointer',
    'The proof-net idea should expose the construction-and-properties graph: f is one central witness feeding independent differentiability, transcendence, and derivative-vanishing subgoals.',
    ['FormalConjectures states Erdos229, source references Barth--Schneider, and gives a formal_proof Lean4 URL.']
))

# write files
DATA.mkdir(exist_ok=True); REPORTS.mkdir(exist_ok=True); PROMPTS.mkdir(exist_ok=True)
frontier_path=DATA/'proofnet_frontier_research_10.jsonl'
with frontier_path.open('w',encoding='utf-8') as f:
    for r in records:
        f.write(json.dumps(r, ensure_ascii=False)+'\n')
# Merge with checked synthetic as a convenience candidate file
merged=[]
checked_path=DATA/'proofnet_checked_synthetic_29.jsonl'
if checked_path.exists():
    with checked_path.open(encoding='utf-8') as f:
        merged=[json.loads(line) for line in f if line.strip()]
merged += records
with (DATA/'proofnet_merged_checked29_plus_frontier10_candidates.jsonl').open('w',encoding='utf-8') as f:
    for r in merged:
        f.write(json.dumps(r, ensure_ascii=False)+'\n')

# Harmonized convenience file: every record has the same top-level key set.
all_keys = sorted(set().union(*(set(r.keys()) for r in merged)))
with (DATA/'proofnet_merged_checked29_plus_frontier10_candidates_harmonized.jsonl').open('w',encoding='utf-8') as f:
    for r in merged:
        f.write(json.dumps({k: r.get(k, None) for k in all_keys}, ensure_ascii=False)+'\n')
# Summary CSV-ish json
summary=[]
for r in records:
    summary.append({k:r[k] for k in ['id','domain','theorem_name','lean_label','check_status','canonical_graph_id']})
(DATA/'proofnet_frontier_research_10_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2),encoding='utf-8')

# Validation report
errors=[]
for r in records:
    ids={n['id'] for n in r['graph']['nodes']}
    for e in r['graph']['edges']:
        if e['target'] not in ids:
            errors.append(f"{r['id']} edge target missing: {e}")
        for s in e.get('sources',[]):
            if s not in ids:
                errors.append(f"{r['id']} edge source missing: {e}")
    for field in ['id','origin','domain','training_stage','theorem_name','informal_statement','lean_label','lean_statement','check_status','graph','canonical_graph_id']:
        if field not in r:
            errors.append(f"{r['id']} missing {field}")
(REPORTS/'FRONTIER_VALIDATION_REPORT.md').write_text('\n'.join([
    '# Frontier Dataset Validation Report','',
    f'- Records: {len(records)}',
    f'- Graph structural errors: {len(errors)}',
    f'- Merged convenience file records: {len(merged)}',
    '',
    '## Status',
    'These records are **not** locally Lean-checked in this package. They are candidate metadata records pointing to external Lean projects. Keep `excluded_from_v03_experiments=true` until Codex clones/builds the source repositories and extracts exact theorem declarations and traces.',
    '',
    '## Errors',
    *(errors or ['None.'])
])+'\n',encoding='utf-8')

review = """# Review of Codex v0.3 Work and Frontier Extension Rationale

## What Codex did well

1. It separated the 29 controlled Lean-checked synthetic records from the 21 unverified Mathlib-shaped sketches. This prevents accidental use of informal records in experiments.
2. It created 58 compiling proof variants for the synthetic fragment and correctly labeled the frontier limitation: no interactive tactic-state extraction yet.
3. It moved from manually assigned v0.2 graph labels to graph-derived structural hashes, and improved the problematic equality/disjunction graphs.
4. It generated real Lean-backed whole-proof candidate failures, rather than only hand-written negative descriptions.
5. It made the candidate-level pruning limitation explicit: this is whole-proof candidate checking, not live BFS over proof states.

## What still needs improvement

1. The central missing object is still the live transition
   `(state_before, partial_graph, tactic) -> (state_after, graph_delta)`.
   The current trace records have `state_before=null` and `state_after=null`.
2. The step-level deltas are parser approximations. They are useful scaffolding, but they are not extracted from Lean elaboration, kernel dependencies, or Lean RPC proof states.
3. Candidate-level pruning is not a proof-search result. It skips duplicate whole-proof candidate shapes. It does not yet show that partial graph pruning is safe under open-goal compatibility.
4. The negative candidates are too scripted: two duplicate bad candidates plus two successes per theorem. Future negative data should come from an actual tactic grammar/search process.
5. The synthetic 29 are too small for research-level claims. They validate the mechanism; they do not test frontier mathematical proof geometry.

## Why the frontier extension is separate

The 10 records in `data/proofnet_frontier_research_10.jsonl` are not replacements for the checked synthetic set. They are a research-level target list with the same schema. They should be treated as `S3_frontier_external_candidate_not_for_v03_experiments` until Codex checks the external repositories.

The purpose is to define which real formalization projects are likely to expose the proof-net effect: independent subgraphs, large lemma clusters, quotientable proof-order bureaucracy, diagram/rewrite transports, and repeated structural motifs.
"""
(REPORTS/'CODEX_V03_REVIEW_AND_NEXT_STEPS.md').write_text(review,encoding='utf-8')

frontier_readme = """# Frontier ProofNet Candidate Dataset

This directory adds ten research-level, externally sourced proof targets in the same high-level JSONL format as the MVP v0.3 dataset.

Files:

- `data/proofnet_frontier_research_10.jsonl`: ten frontier candidate records.
- `data/proofnet_merged_checked29_plus_frontier10_candidates.jsonl`: convenience merge of the 29 checked synthetic records plus the ten frontier candidate records.
- `reports/FRONTIER_VALIDATION_REPORT.md`: graph/schema validation.
- `prompts/CODEX_FRONTIER_AUDIT_PROMPT.md`: prompt for Codex to clone/check/extract exact Lean data.

Important status rule:

- The 29 synthetic records are locally checked in the v0.3 package.
- The 10 frontier records are externally sourced and not locally compiled here.
- Do not train or evaluate search on the frontier records until Codex verifies the source repository build and extracts exact theorem declarations, proof traces, and graph deltas.

Research use:

These records are intended to guide the next stage: selecting frontier Lean projects where proof-net abstractions should matter. They are especially useful for designing extraction scripts and choosing benchmark subproofs.
"""
(REPORTS/'FRONTIER_DATASET_README.md').write_text(frontier_readme,encoding='utf-8')

sources_md = """# Frontier Sources and Why They Were Chosen

The records were chosen because they involve large proof-dependency networks rather than merely long linear calculations.

1. PFR: entropy, additive combinatorics, Ruzsa covering, subgroup/coset witness construction.
2. Liquid Tensor Experiment: Ext vanishing, exact sequences, condensed mathematics, Banach choices, isomorphism transports.
3. FLT regular primes: regularity, cyclotomic factorization, class group obstruction, contradiction structure.
4. Kummer criterion: Bernoulli-number finite computation plus algebraic number theory theorem dependencies.
5. Equational Theories Project: a direct implication/countermodel graph; nearly ideal for proof-net canonicalization experiments.
6. Generalized Quantum Stein lemma: tensor products, resource theory, POVM optimization, entropy and limit transports.
7. Erdős 848: modular squarefree obstruction + density/cardinality proof structure.
8. Erdős 1026: sequence/block decomposition and increasing/decreasing subsequence duality.
9. Erdős 541: finite zero-sum subsets and cardinality/range constraints.
10. Erdős 229: construction of a transcendental entire function with independent analytic property subgoals.
"""
(REPORTS/'FRONTIER_SOURCES.md').write_text(sources_md,encoding='utf-8')

prompt = r'''You are auditing and extending a Lean + ML ProofNet dataset.

Repository/package context:
- MVP v0.3 has 29 locally checked synthetic records and 58 checked variants.
- A new file `data/proofnet_frontier_research_10.jsonl` adds ten frontier/research-level external candidate records in the same schema.
- These frontier records must remain excluded from experiments until you verify them.

Your job is to build v0.4-frontier-verification.

Critical rule: do not claim any frontier record is Lean-checked unless you have cloned the referenced repository, pinned the toolchain/mathlib version, and run the relevant build or file check successfully.

Tasks:

1. Validate local files.
   Run the local JSONL validators on:
   - `data/proofnet_checked_synthetic_29.jsonl`
   - `data/proofnet_frontier_research_10.jsonl`
   - `data/proofnet_merged_checked29_plus_frontier10_candidates.jsonl`
   Check every graph edge source/target, node type, edge type, canonical hash field, and `excluded_from_v03_experiments` flag.

2. Audit Codex v0.3 outputs.
   Read:
   - `MVP_V03_REPORT.md`
   - `reports/LEAN_BACKED_CANDIDATE_SEARCH_RESULT.md`
   - `reports/CANONICALIZATION_SAFETY_V03_REPORT.md`
   - `reports/TRACE_EXTRACTION_REPORT.md`
   Write a concise assessment of what is scientifically valid and what is only a toy/scaffold result.

3. Verify frontier source availability.
   For each frontier record F01-F10:
   - open the source URL(s);
   - record repository name, license if easily visible, Lean version/toolchain if present, mathlib commit if present;
   - locate the exact theorem declaration if possible;
   - record source file path and line range;
   - determine whether the project is Lean 3 or Lean 4.

4. Clone and build only what is feasible.
   Try to clone/build a small subset first:
   - F01 PFR
   - F05 Equational Theories representative files
   - one or two Erdős records from `plby/lean-proofs`
   Do not attempt massive builds blindly. If a full repo build is too large, use file-level checks or dependency-aware subsets.

5. Extract exact theorem metadata.
   For each successfully verified source, create/update records with:
   - exact theorem name;
   - exact Lean statement;
   - source file path;
   - Lean version;
   - mathlib commit;
   - build command;
   - build result;
   - source theorem hash.

6. Extract trace-level data where feasible.
   Prefer LeanDojo or Lean 4 RPC for Lean 4 repositories. If unavailable, parse tactic blocks conservatively. Do not invent states.
   Desired schema:
   ```json
   {
     "frontier_id": "F01_PFR",
     "source_theorem": "ProbabilityTheory.PFR_conjecture",
     "step_index": 0,
     "state_before": "... or null",
     "tactic": "...",
     "state_after": "... or null",
     "used_premises": [],
     "graph_delta": {"nodes_added": [], "edges_added": []},
     "extraction_status": "lean_rpc_extracted | leandojo_extracted | parsed_no_state | failed"
   }
   ```

7. Refine proof-net graphs.
   For each frontier theorem, check whether the candidate graph in `proofnet_frontier_research_10.jsonl` actually matches the source proof architecture. Fix graphs when they are too coarse or misleading.

8. Do not merge frontier records into experiments yet.
   Only create a verified frontier subset file:
   - `data/proofnet_frontier_verified_subset.jsonl`
   Include only records that you actually built/checked.

9. Produce reports.
   Create:
   - `reports/CODEX_FRONTIER_AUDIT_REPORT.md`
   - `reports/FRONTIER_BUILD_REPORT.md`
   - `reports/FRONTIER_TRACE_EXTRACTION_REPORT.md`
   - `reports/FRONTIER_GRAPH_FIDELITY_REPORT.md`
   - `reports/FRONTIER_NEXT_STEPS.md`

10. Final answer requirements.
   In your final response, state:
   - which commands you ran;
   - which repositories were checked;
   - which frontier records are verified, partially verified, or unverified;
   - exact blockers;
   - whether any graphs were corrected;
   - whether trace extraction succeeded;
   - what remains before these records can be used in training or search evaluation.

Be strict and conservative. The right answer may be: “only 2 of 10 frontier records were verified in this run.” That is acceptable. Do not hide failures.
'''
(PROMPTS/'CODEX_FRONTIER_AUDIT_PROMPT.md').write_text(prompt,encoding='utf-8')

print(json.dumps({'frontier_records':len(records),'merged_records':len(merged),'errors':len(errors),'out':str(frontier_path)},indent=2))
