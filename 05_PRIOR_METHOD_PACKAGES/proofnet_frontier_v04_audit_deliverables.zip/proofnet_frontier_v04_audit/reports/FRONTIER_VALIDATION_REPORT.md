# Frontier Dataset Validation Report

- Records: 10
- Graph structural errors: 0
- Merged convenience file records: 39

## Status
These records are **not** locally Lean-checked in this package. They are candidate metadata records pointing to external Lean projects. Keep `excluded_from_v03_experiments=true` until Codex clones/builds the source repositories and extracts exact theorem declarations and traces.

## Errors
None.
