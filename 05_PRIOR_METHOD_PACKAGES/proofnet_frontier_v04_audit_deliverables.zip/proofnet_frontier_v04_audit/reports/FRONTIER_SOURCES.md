# Frontier Sources and Why They Were Chosen

The records were chosen because they involve large proof-dependency networks rather than merely long linear calculations.

1. PFR: entropy, additive combinatorics, Ruzsa covering, subgroup/coset witness construction.
2. Liquid Tensor Experiment: Ext vanishing, exact sequences, condensed mathematics, Banach choices, isomorphism transports.
3. FLT regular primes: regularity, cyclotomic factorization, class group obstruction, contradiction structure.
4. Kummer criterion: Bernoulli-number finite computation plus algebraic number theory theorem dependencies.
5. Equational Theories Project: a direct implication/countermodel graph; nearly ideal for proof-net canonicalization experiments.
6. Generalized Quantum Stein lemma: tensor products, resource theory, POVM optimization, entropy and limit transports.
7. Erdős 848: modular squarefree obstruction + density/cardinality proof structure.
8. Erdős 1026: sequence/block decomposition and increasing/decreasing subsequence duality.
9. Erdős 541: finite zero-sum subsets and cardinality/range constraints.
10. Erdős 229: construction of a transcendental entire function with independent analytic property subgoals.
