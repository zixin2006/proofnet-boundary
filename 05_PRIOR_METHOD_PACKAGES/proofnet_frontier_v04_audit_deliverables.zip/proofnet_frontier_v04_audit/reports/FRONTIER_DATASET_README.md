# Frontier ProofNet Candidate Dataset

This directory adds ten research-level, externally sourced proof targets in the same high-level JSONL format as the MVP v0.3 dataset.

Files:

- `data/proofnet_frontier_research_10.jsonl`: ten frontier candidate records.
- `data/proofnet_merged_checked29_plus_frontier10_candidates.jsonl`: convenience merge of the 29 checked synthetic records plus the ten frontier candidate records.
- `reports/FRONTIER_VALIDATION_REPORT.md`: graph/schema validation.
- `prompts/CODEX_FRONTIER_AUDIT_PROMPT.md`: prompt for Codex to clone/check/extract exact Lean data.

Important status rule:

- The 29 synthetic records are locally checked in the v0.3 package.
- The 10 frontier records are externally sourced and not locally compiled here.
- Do not train or evaluate search on the frontier records until Codex verifies the source repository build and extracts exact theorem declarations, proof traces, and graph deltas.

Research use:

These records are intended to guide the next stage: selecting frontier Lean projects where proof-net abstractions should matter. They are especially useful for designing extraction scripts and choosing benchmark subproofs.
