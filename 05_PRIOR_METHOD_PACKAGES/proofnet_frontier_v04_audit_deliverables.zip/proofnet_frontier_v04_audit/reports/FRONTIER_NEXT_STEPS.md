# Frontier Next Steps v0.4

1. Keep `data/proofnet_frontier_verified_subset.jsonl` separate from all experiments until graph fidelity is repaired from machine-extracted traces.
2. Build exact theorem records for F02, F03, F04, F06, and F07. Record repo commit, Lean version, mathlib commit or dependency lock, source theorem line range, and successful command.
3. Replace project-level F05 with concrete Equational Theories examples: one implication theorem, one countermodel/refutation certificate, and one generated theorem. Each should have its own record.
4. Install or implement a Lean 4 RPC/InfoTree extractor for F01/F08/F09/F10 and a Lean 3-compatible path for F02 if it remains in scope.
5. Regenerate proof-net graphs from traces: split case trees, independent subgoals, witness creation, calc chains, theorem applications, rewrite directions, and final closure steps.
6. Add negative/failed branches by replaying small tactic mutations under Lean, not by hand annotation.
7. Only after trace-backed graphs exist, run a frontier smoke experiment comparing tactic-only search to graph-pruned search. Metrics should include expanded nodes, Lean calls, duplicate branch rate, equivalent-branch redundancy, and success@budget.
