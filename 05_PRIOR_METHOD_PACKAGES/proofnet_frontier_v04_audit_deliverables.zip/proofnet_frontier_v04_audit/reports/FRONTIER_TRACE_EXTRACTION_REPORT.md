# Frontier Trace Extraction Report v0.4

Trace extraction status: **partial scaffold only**.

A LeanDojo/RPC tactic-state extractor was not installed or run. No `state_before` or `state_after` values were recovered. The file `data/proofnet_frontier_trace_steps_parsed_no_state.jsonl` contains 131 conservative source-line trace fragments from the four locally checked theorem blocks. Every row is marked `parsed_no_state` and has null states.

## Parsed Trace Counts

| Record | Source theorem | Parsed no-state steps |
| --- | --- | --- |
| F01_PFR | PFR_conjecture | 55 |
| F08_ERDOS_1026 | Erdos1026.c_opt_eq_k_div_sq_add_a | 53 |
| F09_ERDOS_541 | Erdos541.erdos_541 | 11 |
| F10_ERDOS_229 | Erdos229.erdos_229 | 12 |


## Interpretation

These traces are useful only for bootstrapping a trace schema and checking source-to-record alignment. They are not suitable for training a tactic-state model or evaluating graph-pruned search, because they do not contain Lean states, branch alternatives, failed tactics, or machine-extracted proof dependencies.
