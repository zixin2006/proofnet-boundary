# Frontier Build Report v0.4

Date: 2026-07-03. Strict rule applied: a record is `verified` only if the referenced repository was cloned/pinned and the relevant Lake/Lean check succeeded locally.

## Command Log

| Command | Result |
| --- | --- |
| unzip -q /Users/zixinyu/Desktop/proofnet_frontier_extension.zip -d work/frontier_audit | success |
| python3 <strict JSONL validator one-off> | success; 0 structural errors across checked29, frontier10, merged39 |
| lake --version | Lake 5.0.0-src+68218e8 / Lean 4.31.0 |
| lean --version | Lean 4.31.0 arm64 |
| git clone --depth 1 https://github.com/teorth/pfr.git work/frontier_sources/pfr | success after network approval |
| git clone --depth 1 https://github.com/teorth/equational_theories.git work/frontier_sources/equational_theories | success |
| git clone --depth 1 https://github.com/plby/lean-proofs.git work/frontier_sources/lean-proofs | success |
| lake env lean PFR/Main.lean | failed before build: unknown module prefix PFR |
| lake exe cache get (PFR) | success |
| lake build PFR.Main | success; 3040 jobs |
| lake env lean equational_theories/Definability/Simple.lean | failed before build: unknown module prefix Batteries/equational_theories |
| lake exe cache get (equational_theories) | success |
| lake build equational_theories.Definability.Simple | success; 992 jobs |
| lake env lean ErdosProblems/Erdos541.lean | initial unknown Mathlib, then success after cache |
| lake exe cache get (lean-proofs v4.24.0) | success; 7335 mathlib cache files |
| lake env lean ErdosProblems/Erdos229.lean | success with warnings |
| lake env lean ErdosProblems/Erdos1026.lean | success with many warnings |


## Build Outcomes

| Record | Repository | Source target | Theorem/declaration | Lean toolchain | Mathlib commit | Status | Successful command |
| --- | --- | --- | --- | --- | --- | --- | --- |
| F01_PFR | teorth/pfr | PFR/Main.lean:253-309 | PFR_conjecture | Lean 4.31.0 | e1d1de3bbb575ceb968a895a3462d5a9ca4b22c9 | verified | lake build PFR.Main |
| F05_EQUATIONAL_THEORIES | teorth/equational_theories | representative module equational_theories.Definability.Simple | not a dataset theorem | Lean 4.29.1 | 5e932f97dd25535344f80f9dd8da3aab83df0fe6 | partial | lake build equational_theories.Definability.Simple |
| F08_ERDOS_1026 | plby/lean-proofs | src/v4.24.0/ErdosProblems/Erdos1026.lean:3604-3656 | Erdos1026.c_opt_eq_k_div_sq_add_a | Lean 4.24.0 | f897ebcf72cd16f89ab4577d0c826cd14afaafc7 | verified | lake env lean ErdosProblems/Erdos1026.lean |
| F09_ERDOS_541 | plby/lean-proofs | src/v4.24.0/ErdosProblems/Erdos541.lean:3055-3065 | Erdos541.erdos_541 | Lean 4.24.0 | f897ebcf72cd16f89ab4577d0c826cd14afaafc7 | verified | lake env lean ErdosProblems/Erdos541.lean |
| F10_ERDOS_229 | plby/lean-proofs | src/v4.24.0/ErdosProblems/Erdos229.lean:1587-1598 | Erdos229.erdos_229 | Lean 4.24.0 | f897ebcf72cd16f89ab4577d0c826cd14afaafc7 | verified | lake env lean ErdosProblems/Erdos229.lean |


## Exact Dependency Pins

- PFR: repo commit `01c9b666945eaf73b3f7d8b20ffe003f8640e630`; Lean `leanprover/lean4:v4.31.0`; Mathlib `e1d1de3bbb575ceb968a895a3462d5a9ca4b22c9`; license observed `Apache-2.0`.
- Equational Theories: repo commit `8ae53676a94e4676a2cda3362d5d57c1ebf4f7c0`; Lean `leanprover/lean4:v4.29.1`; manifest Mathlib `5e932f97dd25535344f80f9dd8da3aab83df0fe6`; license observed `Apache-2.0`.
- lean-proofs: repo commit `423633363b101cf2f6206320e256bf5a223588b0`; Lean `leanprover/lean4:v4.24.0`; Mathlib `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`; Apache-2.0 notice observed in later version directories, but no `src/v4.24.0/LICENSE` file.

## Non-Promoted Records

F02, F03, F04, F06, and F07 were not cloned or built in this run. Their dataset records remain external sketches/candidates. F05 had a successful representative module build, but the dataset record does not identify a single theorem, so it is not included in `data/proofnet_frontier_verified_subset.jsonl`.
