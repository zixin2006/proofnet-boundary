# Codex Frontier Audit Report v0.4

## Summary

The local JSONL files are structurally valid, and four frontier records were locally checked against cloned/pinned Lean repositories: F01, F08, F09, and F10. One project-level record, F05, has a successful representative module build but is not a verified theorem record. The other five frontier records remain unverified.

The verified subset is written to `data/proofnet_frontier_verified_subset.jsonl` with exact source file, line range, pinned Lean/mathlib commits, successful build command, and SHA-256 source theorem hash. These records are still marked ineligible for training because their graphs are candidate annotations, not extracted proof traces.

## Local JSONL Validation

Previously run strict validation found zero structural errors in:

- `data/proofnet_checked_synthetic_29.jsonl`: 29 records, 0 graph endpoint/type/hash/exclusion errors.
- `data/proofnet_frontier_research_10.jsonl`: 10 records, 0 graph endpoint/type/hash/exclusion errors.
- `data/proofnet_merged_checked29_plus_frontier10_candidates.jsonl`: 39 records, 0 graph endpoint/type/hash/exclusion errors.

## v0.3 Scientific Status

The v0.3 results are scientifically valid only for the controlled synthetic benchmark: 29 checked synthetic base theorems, 58 checked variants, structural canonicalization tests, and a candidate-level pruning simulation. They are not evidence of Lean-backed interactive proof search. The v0.3 trace extraction had no Lean tactic states, candidate search checked whole proof candidates rather than expanding an interactive search tree, and the 21 Mathlib-shaped sketches remained excluded.

## Source Availability and Verification

| Record | v0.4 status | Repository | License observed | Lean/project status | Source status |
| --- | --- | --- | --- | --- | --- |
| F01_PFR | verified | teorth/pfr | Apache-2.0 | Lean 4 | PFR/Main.lean:253-309 |
| F02_LTE | unverified | leanprover-community/lean-liquid | not rechecked in this run | Lean 3 project per record/source convention | source URL opened only; not cloned/built |
| F03_FLT_REGULAR | unverified | leanprover-community/flt-regular | not rechecked in this run | Lean 4 per record | source URL opened only; not cloned/built |
| F04_KUMMER_CRITERION | unverified | riccardobrasca/KummerCriterion | not rechecked in this run | Lean project unconfirmed locally | source URL/search only; not cloned/built |
| F05_EQUATIONAL_THEORIES | partial | teorth/equational_theories | Apache-2.0 | Lean 4.29.1 | representative module built, record lacks one theorem |
| F06_QUANTUM_STEIN | unverified | Timeroot/Lean-QuantumInfo | not rechecked in this run | Lean 4 per record/source URL | source URL opened only; not cloned/built |
| F07_ERDOS_848 | unverified | The-Obstacle-Is-The-Way/erdos-banger | not rechecked in this run | unconfirmed locally | source/formal URL opened only; not cloned/built |
| F08_ERDOS_1026 | verified | plby/lean-proofs | Apache-2.0 notice in later version dirs | Lean 4.24.0 | ErdosProblems/Erdos1026.lean:3604-3656 |
| F09_ERDOS_541 | verified | plby/lean-proofs | Apache-2.0 notice in later version dirs | Lean 4.24.0 | ErdosProblems/Erdos541.lean:3055-3065 |
| F10_ERDOS_229 | verified | plby/lean-proofs | Apache-2.0 notice in later version dirs | Lean 4.24.0 | ErdosProblems/Erdos229.lean:1587-1598 |


## Verified Subset

| Record | Source theorem | Source hash prefix | Build result |
| --- | --- | --- | --- |
| F01_PFR | PFR_conjecture | 358317080cca8692 | success |
| F08_ERDOS_1026 | Erdos1026.c_opt_eq_k_div_sq_add_a | 4b607dbe381427aa | success_with_many_warnings |
| F09_ERDOS_541 | Erdos541.erdos_541 | 47c130df3c83bb1d | success_with_warnings |
| F10_ERDOS_229 | Erdos229.erdos_229 | d6b96b8d4d19b51b | success_with_warnings |


## Strict Exclusions

F02, F03, F04, F05, F06, and F07 must remain excluded from experiments. F05 is excluded despite a representative build because the record has no exact theorem declaration. The merged candidate file must not be used as an experiment input.

## Main Blockers

- No Lean RPC/LeanDojo state extraction was run.
- Frontier graphs are hand-written/candidate annotations, not generated from checked traces.
- Several source records point to projects or theorem families rather than exact declarations.
- F02 is Lean 3-shaped and requires a separate Lean 3 verification path.
- F04/F06/F07 were not locally cloned/built in this run.
