# Frontier Graph Fidelity Report v0.4

Strict conclusion: the frontier graphs remain candidate proof-net-inspired dependency annotations. They are not extracted from Lean traces.

## Verified Records

- F01_PFR: The graph captures the broad PFR architecture (small doubling, entropy/Ruzsa auxiliary theorem, subgroup/coset witnesses, cardinality and cover goals). It is still too coarse for search: the checked proof has a concrete `le_or_gt` case split on `#H <= #A`, a second witness `H'`, a transversal `u`, and long chained numeric `calc` obligations. Those are not represented as separate case-tree or arithmetic-dependency nodes.
- F08_ERDOS_1026: The candidate graph is too shallow. The checked final theorem is an equality proof by two inequalities (`le_antisymm`), with construction-side and lower-bound-side subgraphs. The graph should split construction, normalization, monotone-subsequence lower bound, `csInf/csSup` reasoning, and positivity/injectivity obligations.
- F09_ERDOS_541: The graph is directionally aligned with the final theorem using `thm_main`, but it omits the submultiset-to-index conversion, extraction of `r`, the `h_subset` bridge, and the final `Set.ncard`/`List.ofFn` conversion.
- F10_ERDOS_229: The graph captures the witness function idea but omits the source proof chain `theorem_1 -> erdos_229.not_polynomial -> erdos_229`, the conversion from non-polynomiality to transcendence, and the derivative-zero witness dependency.

## Partially Checked Project Record

- F05_EQUATIONAL_THEORIES: A representative module (`equational_theories.Definability.Simple`) builds, but the record names a whole project/implication graph rather than a theorem. No graph correction was made because there is no single source theorem to align against.

## Unchecked Records

F02_LTE, F03_FLT_REGULAR, F04_KUMMER_CRITERION, F06_QUANTUM_STEIN, and F07_ERDOS_848 remain unverified in this run. Their graphs should not be used as positive training examples until the exact source theorem and local build are checked.

## Corrections Made

No original frontier candidate graph was silently rewritten. Instead, the verified subset records add `frontier_verification_v04.graph_status = candidate_graph_not_extracted_from_checked_trace`. This is deliberately conservative: graph repair should happen after Lean state/trace extraction, not by hand from prose summaries.
