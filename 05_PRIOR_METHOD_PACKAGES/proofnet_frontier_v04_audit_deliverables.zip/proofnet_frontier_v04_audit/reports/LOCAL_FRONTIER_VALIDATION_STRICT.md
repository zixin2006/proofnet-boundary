# Frontier Local Validation Report

## data/proofnet_checked_synthetic_29.jsonl

- Records: 29
- Unique IDs: 29
- Duplicate IDs: none
- Graph endpoint errors: 0
- Node type errors: 0
- Edge type errors: 0
- Missing hash field counts: 0
- Exclusion flag errors: 0

## data/proofnet_frontier_research_10.jsonl

- Records: 10
- Unique IDs: 10
- Duplicate IDs: none
- Graph endpoint errors: 0
- Node type errors: 0
- Edge type errors: 0
- Missing hash field counts: 0
- Exclusion flag errors: 0

## data/proofnet_merged_checked29_plus_frontier10_candidates.jsonl

- Records: 39
- Unique IDs: 39
- Duplicate IDs: none
- Graph endpoint errors: 0
- Node type errors: 0
- Edge type errors: 0
- Missing hash field counts: 0
- Exclusion flag errors: 0

## Errors

None.
