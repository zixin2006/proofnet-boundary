# ProofNet Frontier Extension

This package extends the ProofNet MVP v0.3 scaffold with ten research-level external Lean formalization candidates. The frontier records use the same high-level JSONL schema as the checked synthetic records, with extra source metadata fields.

Important status distinction:

- `data/proofnet_checked_synthetic_29.jsonl` is copied from the MVP v0.3 checked synthetic dataset.
- `data/proofnet_frontier_research_10.jsonl` contains external-source candidate records. These are **not locally compiled here** and are marked `excluded_from_v03_experiments=true`.
- `data/proofnet_merged_checked29_plus_frontier10_candidates.jsonl` is a convenience merge, not an experiment-ready training file.
- `data/proofnet_merged_checked29_plus_frontier10_candidates_harmonized.jsonl` is the same merge with a unified top-level key set.

The frontier records are intended for v0.4 source verification: clone/build source repositories, locate exact theorem declarations, extract proof traces, improve graph fidelity, and only then promote verified records into benchmark/training files.

See:

- `reports/CODEX_V03_REVIEW_AND_NEXT_STEPS.md`
- `reports/FRONTIER_DATASET_README.md`
- `reports/FRONTIER_VALIDATION_REPORT.md`
- `prompts/CODEX_FRONTIER_AUDIT_PROMPT.md`
