# Experiment and implementation plan

**Registration status: DRAFT.** This document is not a preregistration. Freeze code, corpus, hypotheses, exclusions, costs, and analysis in a new commit before collecting new outcome data. Do not edit existing registered experiments or reinterpret their decisions. [R3, R4]

## Work package 1: reproduce and audit the actual baseline

Work in a local branch of `proof-graphs`, pinned initially at `8010d137af5af5040fcbcd9e98f910b01162263e`. Keep its actual dependency lock; do not substitute the newer `proofnet-ir` main for a pinned dependency. Compare that pin with the separately inspected ProofNet-IR head and document the distinction.

Run the documented build and committed-artifact checks. Distinguish recomputing summaries from running new inference. Check a small set of fresh Lean fixtures before a broad export. Select fixtures for nested `have`, `calc`, `simpa ... using`, `first`, `try`, `repeat`, shared witnesses, metavariable-dependent local types, and universe sharing. A human should independently reconstruct at least the failure-combinator cases before viewing extractor output. [R4]

Acceptance: recorded commands and logs; untouched frozen outputs; a reproducible failing test for each confirmed defect, or an explicit refutation of the suspected defect. No mass source transformation or model training is required.

## Work package 2: a fail-closed typed boundary sidecar

Extend the existing Lean exporter and REPL rather than introducing another session driver. Required information is the active goal list, persistent raw IDs, versioned capsules, tagged expressions and levels, local telescope, reachable metavariable declarations/assignments, environment/prefix fingerprint, branch identity, and dependency-coverage flags.

When complete coverage is unavailable, keep the entire affected state/group and avoid hard equality merges based on lossy printed fallback. Lack of factoring is an acceptable conservative result. Querying the same snapshot twice must not change observable proof behavior.

Acceptance: all adversarial fixtures pass; no literal modification or placeholder identity merges; same raw goal may change its capsule version; failures do not mutate the committed graph. Every exported row validates against one current schema. Recorded gold evidence is attached only to actual full replay, not to a tactic name.

## Work package 3: closed-fragment cache with a graph ablation

Use only completed, hole-free local terms. Start with same-environment reuse under typed renaming and weakening. Do not start with arbitrary open-subproof unification or a learned GNN.

**Arms:**

| Arm | Purpose |
|:--|:--|
| A0: faithful whole-state search | Existing baseline, same correctness repairs as other arms |
| A1: faithful coupled-group search | Existing graph baseline |
| A2: A0 plus ordinary typed closed-term cache | Does reuse help without graph-specific indexing? |
| A3: A0 plus boundary/graph-indexed cache | Does your representation improve retrieval or net cost? |

A2 and A3 receive the same proof-fragment inventory, trust policy, verification budget, and candidate proposer. A3 cannot quietly receive more theorems, future dependencies, or a stronger model. Repair keying in all arms; do not credit fixing an old baseline bug as a graph-specific learning benefit.

Primary mechanism metrics: eligible repeated fragments, retrieval attempts, successful Lean-checked reuse, rejected transports, avoided model requests, avoided tactic executions, export/match/recheck costs. Primary task metric: theorem success under an explicitly fixed resource budget. Report all denominators and setup failures.

A graph feature could improve retrieval order without supporting any extra exact merges. Make that the experimental distinction rather than comparing a weak string cache to a rich graph cache.

## Work package 4: held-out mathematical pilot

First use 20–50 small and medium proof fragments with genuine repeated subarguments and adversarial negatives; choose the final count before the run. After extraction and transport are stable, select a separate held-out module set in analysis, algebra, or category theory. Curate by syntactic constructs and available build resources, not by whether the new algorithm wins.

For condensed mathematics, use an actually buildable, pinned Lean project and identify its Lean generation. The historical Liquid Tensor corpus and a modern Lean 4 Mathlib development are not interchangeable. No theorem from that area was extracted in this review. The milestone is one correct traced module fragment, not a diagram labelled frontier-scale.

## Controls that matter

**Leakage.** Split by module/theorem family and dependency availability. Exclude the target declaration itself and later declarations from the proving environment. Store full proofs for audit separately from policy inputs. Do not compute input graph features from future proof steps.

**Common draws.** For controlled search comparison, prerecord or deterministically index candidate draws by exact request content, seed, and occurrence. Report marginal candidate costs rather than which arm happened to populate the shared cache. A policy conditioned on a different graph prompt cannot be called the same draw experiment without describing the changed request.

**Runtime.** Run isolated fresh-process cold-cache trials, randomized by arm order, under an explicit warmup policy. Include extraction, serialization, canonicalization, matching, replay, and model time. The corrected search-v0.8 cost discussion makes this a required control. [R3]

**Statistics.** A theorem repeated under seeds is a clustered observation. Use paired per-task comparisons and module-aware uncertainty estimates. Predefine multiple-comparison handling. Nonsignificance is not equivalence; a claim of non-inferiority needs a chosen margin and an appropriate design.

## Go / no-go gates

Proceed to a trained graph model only after there is evidence of a useful signal beyond a plain cache. If eligible reuse is rare, change corpus or conclude limited applicability before optimizing graph encoders. If replay overhead exceeds avoided work, report the cost failure. If A2 and A3 perform alike, remove graph-specific claims and retain the useful semantic tooling.

The immediate decision need not depend on a positive ML result: a carefully audited extractor and falsifiable account of where abstraction fails are legitimate outputs, though their publication fit depends on the resulting evidence and venue.
