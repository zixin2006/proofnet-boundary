# Contribution and collaboration proposal

## Your part, stated without inflating it

Your last available implementation is smaller and less mature than your friend's current repositories. Its strengths are the original problem framing, the focus on partial boundaries rather than finished proofs alone, and the insistence on extracting faithful intermediate objects. Those strengths become a distinct contribution only when they are turned into new checks, semantics, or demonstrated reuse—not when renamed as another graph abstraction. [R1–R8, U1]

This assessment compares artifacts. It cannot reconstruct the history of your joint conversations, the origin of shared ideas, or individual authorship. Agree on contribution credit directly and keep a written record of work performed.

## Proposed ownership, subject to your agreement

| Workstream | Suggested lead | Concrete output |
|:--|:--|:--|
| Restricted MLL theory and certified IR | Friend / existing maintainer | Stable theorem interface; no unsupported transfer to Lean graphs |
| Existing extraction, search, and frozen results | Friend / existing maintainer | Baseline behavior, reproducibility support, review of changes |
| Independent semantic audit | You | Hand reconstructions, adversarial Lean fixtures, reproducible bug reports |
| Typed boundary / event interface | You, jointly reviewed | Versioned schema, exporter sidecar, provenance, transaction checks |
| Checked fragment transport | You, jointly reviewed | Closed-fragment cache, context mapping, replay evidence |
| Experimental design and interpretation | Both | Frozen protocol, strong baselines, negative results retained |
| Paper and release | Both | Separate formal claims, engineering guarantees, empirical conclusions |

Do not divide the project as “he does code; I do ideas.” Own a module with measurable acceptance criteria. Conversely, a correctness audit is not inferior to new features: it determines whether the features support the intended scientific claims.

## Proposed sequence of pull requests

**PR 1: audit only.** New adversarial fixtures and source-pinned review. No baseline behavior change. Establish which suspicious cases are real defects.

**PR 2: typed boundary sidecar.** Additive schema and serializer, identity-version separation, conservative unknown handling. Keep old datasets and frozen experiments intact.

**PR 3: checked closed-fragment cache.** Baseline cache and graph-index variant using the same inventory. No learned model yet.

**PR 4: registered experiment and report.** Collected only after the protocol commit. Explain null or negative results as clearly as positive ones.

No automatic push to main. Work on a local feature branch, request review, and resolve concurrent-edit ownership. The final ZIP is a planning/reference package, not a modification of either repository.

## Suggested message to your friend

“I read the newer results and think I should stop duplicating the extractor and goal-grouping work you already have. I'd like to own the semantic audit and typed boundary/transport layer, then test whether checked reuse of local proof fragments adds anything beyond your structural-state and group baselines. I will start with the failure-combinator and identity tests, keep your frozen experiments intact, and include a plain proof-term cache so we can isolate whether the graph really helps. Let's agree on that scope and review the interfaces together before implementation.”
