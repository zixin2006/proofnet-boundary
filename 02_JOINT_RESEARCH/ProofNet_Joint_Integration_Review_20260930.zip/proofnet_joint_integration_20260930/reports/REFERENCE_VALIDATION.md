# What was and was not executed

## Actually executed here

The supplied user v0.7.1 archive was read programmatically and checked against its shipped JSON Schema. `evidence/USER_V071_AUDIT.json` records the counts and mismatch examples. This is a fresh artifact audit, not a fresh Lean run.

The package's Python reference tests were run with `python -m unittest discover -s tests -v`. They cover typed renaming, literal preservation, metavariable aliasing, shared local identity across capsules, transitive and universe dependencies in a finite model, frontier persistence, and schema guards. `evidence/REFERENCE_TEST_LOG.txt` is the actual output.

The literal regression reproduces the specific regex-renumbering mechanism observed in the pinned `scripts/goal_identity.py` [R5]. It does not import and execute the entire remote repository, and its synthetic inputs are not evidence of an actual erroneous Mathlib proof.

## Not executed here

No local `lake build`, Lean proof elaboration, friend-repository end-to-end reproduction, full 7,285-row dataset conversion, new model call, or frontier theorem trace was performed. Lean/Lake was unavailable; container GitHub cloning failed at DNS resolution, while selected files were successfully read through the connected GitHub tool. No repository was modified remotely.

`examples/BoundaryRegression.lean` is uncompiled fixture source. The JSON examples are explicitly synthetic design fixtures. Their IDs name fixtures, not invented Lean metavariables. The offline adapter was tested on a synthetic row matching the inspected format, not the full downloaded dataset.

## Interpretation limits

The Python representation is not a Lean typechecker and does not decide operational state equivalence. It deliberately rejects missing declared dependencies, but its finite-model closure does not establish complete coverage of Lean's postponed constraints, plugins, transparency behavior, elaborator state, or external effects. A matching fingerprint licenses no hard pruning. The sidecar schema enforces that limitation.

A passed JSON schema checks structure, not provenance truth. A claimed log reference still requires checking its contents. A passed local term application is not a full-declaration replay. A full checked theorem does not prove that every extractor annotation is correct or that a pruning rule preserves search completeness.
