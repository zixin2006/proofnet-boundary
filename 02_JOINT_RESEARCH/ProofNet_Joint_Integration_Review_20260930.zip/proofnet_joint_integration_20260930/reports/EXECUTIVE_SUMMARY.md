# Executive decision

**Keep the research question; change the proposed contribution.** The current repositories already implement much of what the earlier Boundary-Lens roadmap treated as future work. The strongest joint direction is not a third graph extractor but an audited, typed boundary and proof-transport layer within `proof-graphs`.

## What is established

`proofnet-ir` supplies a formally verified restricted MLL proof-net library. `proof-graphs` supplies real Lean extraction, a corrected dataset of 7,285 step graphs, structural goal identity, coupled-goal search, and registered comparisons. Its latest controlled comparison does not establish a significant search advantage for goals or groups over whole states. The latest MLL representation experiment also finds no significant format advantage in its thinking condition. [R1–R3, R9]

Your available v0.7.1 artifact is a smaller controlled extraction milestone: 15 successful transition rows for five theorems and five failure rows. This review's Python audit found no typed edges in those success rows and a mismatch with the shipped schema. Its included Lean logs were not independently re-executed here. [U1]

## What your part should become

Own three connected outputs: an independent semantic audit, a typed transaction-aware boundary sidecar, and a Lean-checked proof-fragment reuse experiment. Start with completed local terms transported under typed context maps. Use the existing search driver and give a non-graph typed cache the same fragment inventory. This is a proposed research contribution, not an already established novelty or speedup.

## The key mathematical correction

If a duplicate key is `(state_key, graph_key)`, equality of that pair implies equality of `state_key`. Adding the graph cannot merge more states than the same state key. Graph-specific gains must arise from another mechanism—such as useful retrieval or cheaper repeated work—not from this pair alone.

## Concrete immediate action

Make one reviewable PR containing failure-combinator tests, typed identity regressions, and a minimal additive boundary exporter. Do not begin with a large dataset, a new neural model, or a condensed-mathematics flagship theorem. Proceed to checked reuse only after the interface is reliable.

## What this package actually contains

A source-pinned comparison, revised methodology, collaboration plan, experiment draft, two Codex prompts, strict sidecar schemas, Lean fixture source, and executable Python reference tests. The Python model demonstrates representation properties only. No new Lean build, trained model, frontier run, or prover improvement is claimed.
