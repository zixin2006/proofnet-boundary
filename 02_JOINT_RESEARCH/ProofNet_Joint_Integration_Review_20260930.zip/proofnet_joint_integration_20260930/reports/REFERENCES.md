# Source register

Reviewed 30 September 2026. GitHub links are pinned to the exact inspected commit. The Lean reference is a moving documentation URL; actual integration must inspect the pinned Lean source. R-numbers below are used throughout the reports. U1 is a local artifact, not a public publication.

**[R1] ProofNet-IR: current status and restricted MLL guarantees.** <https://github.com/fushanbobfan/proofnet-ir/blob/261f2db26aac842534f4306da0f45d8c5e9b1c05/docs/current-status.md>

**[R2] proof-graphs: current scope and dataset.** <https://github.com/fushanbobfan/proof-graphs/blob/8010d137af5af5040fcbcd9e98f910b01162263e/README.md>

**[R3] proof-graphs: states, goals, and coupled groups, search-v0.8.** <https://github.com/fushanbobfan/proof-graphs/blob/8010d137af5af5040fcbcd9e98f910b01162263e/experiments/search-v0.8/README.md>

**[R4] proof-graphs: handoff, verification boundaries, and audit priorities.** <https://github.com/fushanbobfan/proof-graphs/blob/8010d137af5af5040fcbcd9e98f910b01162263e/HANDOFF.md>

**[R5] proof-graphs: structural goal identity implementation.** <https://github.com/fushanbobfan/proof-graphs/blob/8010d137af5af5040fcbcd9e98f910b01162263e/scripts/goal_identity.py>

**[R6] proof-graphs: structural-key whole-state, goal, and group searches.** <https://github.com/fushanbobfan/proof-graphs/blob/8010d137af5af5040fcbcd9e98f910b01162263e/scripts/search_faithful.py>

**[R7] proof-graphs: Lean InfoTree extractor.** <https://github.com/fushanbobfan/proof-graphs/blob/8010d137af5af5040fcbcd9e98f910b01162263e/ProofGraphs/Extract.lean>

**[R8] proof-graphs: corrected graph derivation and dataset generation.** <https://github.com/fushanbobfan/proof-graphs/blob/8010d137af5af5040fcbcd9e98f910b01162263e/scripts/run_recount.py>

**[R9] ProofNet-IR: representation study with and without thinking, v0.3.** <https://github.com/fushanbobfan/proofnet-ir/blob/261f2db26aac842534f4306da0f45d8c5e9b1c05/experiments/representation-v0.3/README.md>

**[R10] Kripner, Sustr, and Straka (2025), LeanTree: Accelerating White-Box Proof Search with Factorized States in Lean 4.** <https://arxiv.org/abs/2507.14722v1>

**[R11] Lample et al. (2022), HyperTree Proof Search for Neural Theorem Proving.** <https://arxiv.org/abs/2205.11491v1>

**[R12] Aniva, Sun, Miranda, Barrett, and Koyejo (2025 revision), Pantograph.** <https://arxiv.org/abs/2410.16429v2>

**[R13] Aniva, Oikawa, Dill, and Barrett (2026), Nazrin: An Atomic Neural Proof Automation Tactic in Lean 4.** <https://arxiv.org/abs/2602.18767v3>

**[R14] Lean language reference: reading proof states.** <https://lean-lang.org/doc/reference/latest/Tactic-Proofs/Reading-Proof-States/>

**[R15] Lean language reference: tactic proofs.** <https://lean-lang.org/doc/reference/latest/Tactic-Proofs/>

**[R16] Yang et al. (2023), LeanDojo: Theorem Proving with Retrieval-Augmented Language Models.** <https://arxiv.org/abs/2306.15626>

**[R17] proof-graphs: original dataset row format; use R8 for corrected v0.2 generation.** <https://github.com/fushanbobfan/proof-graphs/blob/8010d137af5af5040fcbcd9e98f910b01162263e/scripts/export_graphs.py>

**[U1] User-supplied Boundary-Lens v0.7.1 archive; fresh Python audit in this package.** ../evidence/USER_V071_AUDIT.json

The repository reports are first-party evidence, not independently replicated results in this review. Selected code paths were inspected through the connected GitHub reader. Container cloning was blocked by DNS and Lean/Lake was unavailable. The review therefore does not certify either full repository build or all experimental conclusions.

**[R18] Blaauwbroek et al. (2024), Graph2Tac: Online Representation Learning of Formal Math Concepts, ICML / PMLR 235.** <https://proceedings.mlr.press/v235/blaauwbroek24a.html>

**[R19] Blaauwbroek (2024), The Tactician's Web of Large-Scale Formal Knowledge.** <https://arxiv.org/abs/2401.02950v2>
