# Revised joint methodology: from graph shape to checked reuse

**Status:** proposed method and executable Python design tests. No new Lean soundness theorem, neural-prover result, or frontier extraction is claimed here. Mathematical propositions below have explicit hypotheses; the reference implementation is a tagged-expression model, not Lean's meta-state.

## 1. Separate four objects

Use four related but distinct representations.

1. **MLL certificate:** the object checked by `proofnet-ir`. Its correctness results apply only to its specified logic. [R1]
2. **Offline derivation graph:** the corrected `proof-graphs` step DAG. It is useful for structural analysis and supervised metadata. It is not an online state. [R7, R8]
3. **Live boundary/event graph:** accepted and attempted Lean transitions with source, state, and evidence identities. This is the proposed Boundary-Lens integration.
4. **Reuse index:** a retrieval structure for completed proof fragments. A match proposes an application; Lean decides whether that application is valid.

This decomposition avoids making one graph serve simultaneously as a proof certificate, a search state, a corpus row, and a heuristic index.

## 2. Boundary and event definitions

Let a live search configuration be

$$S=(E,O,Q,M,U,P),$$

where $E$ is the environment and source-prefix availability, $O$ relevant options and scope, $Q$ the ordered active-goal list, $M$ the reachable term-metavariable declarations and assignments, $U$ universe information, and $P$ any relevant postponed or opaque obligations. This is an interface contract; exporting all of Lean's operational state is not assumed feasible. Missing fields must be represented by coverage flags, not silently erased. Lean distinguishes term goals, shared unknowns, and universe metavariables. [R14, R15]

A goal capsule stores its local telescope, target, available local instances, identity, and content version. Metavariable types and local-definition values participate in dependency closure. Raw identifiers are for same-session provenance; model features use explicit structural references. Do not replace an unexported free variable by a common placeholder.

Define an observed boundary

$$\partial S=(Q,\operatorname{Reach}(Q;M,U,P),\operatorname{coverage}).$$

`Reach` follows references through goal targets, local types/values, metavariable declarations/assignments, and universes. Opaque constraints either join the affected component conservatively or disable factorization. A successful export is not automatically a complete export.

An event is

$$e_i=(b_i,S_i,t_i,o_i,S'_i,\eta_i),$$

with branch/transaction identifier $b_i$, tactic syntax $t_i$, outcome $o_i$, and evidence $\eta_i$. Outcomes distinguish unexecuted proposals, executed successes, errors, timeouts, and unknowns. Disposition separately distinguishes committed, speculative, and rolled-back events. A successful speculative alternative need not be committed.

Let $\rho_i$ map active Lean goal identifiers injectively into persistent graph identities. Preserve this identity while incrementing a **capsule version** when an assignment changes the instantiated target or context. A removed active goal is `no_longer_active` until assignment/reachability evidence determines whether it is solved, replaced, or suspended.

The durable history is append-only:

$$H_{i+1}=H_i\mathbin{\|}[e_i].$$

The current graph is a materialized view:

$$G_{i+1}=\operatorname{Apply}(G_i,\Delta_i).$$

Node insertions can be monotone, but statuses, active ports, and content versions are updates. Writing only $G_{i+1}=G_i\cup\Delta_i$ loses this distinction.

## 3. Evidence hierarchy

Use independent evidence labels rather than a single `verified` flag:

- `source_observed`: syntax, arguments, source span;
- `lean_transition_observed`: before/after state observed during an executed transition;
- `assignment_observed`: a particular assignment or expression reference was inspected;
- `derived_annotation`: an extractor rule inferred a relation;
- `kernel_replay_passed`: a complete reconstructed declaration passed checking under a recorded trust policy;
- `proposed`: no execution evidence.

An accepted tactic does not prove that a source-mentioned lemma was used. `constructor` does not certify sibling independence. A root proof with unresolved holes is not a complete theorem. Proof-term enrichment reveals actual references but does not automatically establish minimal dependencies or tactic commutation. [R14, R15]

## 4. The hashing limitation: an elementary but decisive result

**Proposition 1 (refinement cannot enlarge duplicate classes).** Let $N$ be any state key and $H$ any graph key. Define $K(x)=(N(x),H(x))$. Then

$$K(x)=K(y)\Longrightarrow N(x)=N(y).$$

Therefore each $K$-equivalence class is a subset of an $N$-equivalence class.

**Proof.** Equality of ordered pairs entails equality of their first coordinates. $\square$

**Consequence.** A state-plus-graph exact key cannot, by itself, merge more states than that same state key. It can retain *more* distinctions. Any advantage must come from a different decision: scheduling, learned ranking, cross-context fragment reuse, or cheaper comparison. Appending graph history to the duplicate key can even undo useful transposition sharing.

This does not make graphs useless. It identifies which mechanism must be measured. A faithful state may contain all logical information while a graph remains a helpful computational representation. No information-theoretic superiority is claimed.

## 5. Conditional local independence, not tactic-name independence

For an explicitly restricted tactic semantics, let $R(t,S)$ and $W(t,S)$ denote the mutable cells read and written by a transition. If both transitions are applicable, allocation can be renamed, they perform no relevant external effects, and

$$W(t,S)\cap(R(u,S)\cup W(u,S))=\varnothing,$$
$$W(u,S)\cap(R(t,S)\cup W(t,S))=\varnothing,$$

with these footprints stable over the two executions, the usual disjoint-update argument yields commuting results up to fresh-identifier renaming.

This is a conditional frame argument, not a theorem about arbitrary Lean tactics. A graph of visible goal references is an approximation to these footprints. A shared witness can make a focused `exact` change another goal. Arbitrary metaprograms may inspect additional state. Consequently the production rule is: preserve observed identities, record every observed effect, and refuse uncertified factorization when coverage is insufficient. [R3, R5, R6, R14]

For `first`, `try`, and `repeat`, preserve nested transaction ancestry. An InfoTree node in a failed alternative must not be treated as a committed proof step solely because it is present in the tree. The current repository's handoff explicitly leaves these constructs as audit targets. [R4]

## 6. The recommended new algorithm: closed-fragment transport

Begin with a completed local proof, not an arbitrary open graph. Write

$$E;\Gamma\vdash p:T,$$

where $p$ contains no unresolved expression or universe metavariables. Compute the dependency-closed local telescope $\Gamma_p$: free locals in $p$ and $T$, plus all locals required by their types and retained local-definition values. Preserve order and instance/binder information. Abstract to a portable term over $\Gamma_p$; do not simply erase unused-looking hypotheses from a printed state.

A candidate reuse at target $E';\Gamma'\vdash T'$ supplies a typed context substitution $\theta$ and compatible environment. The proposed application is $\theta(p)$. The match is useful only if Lean accepts it at $T'$ under the current declaration prefix and trust policy.

**Proposition 2 (typed substitution, restricted setting).** In a dependent type theory with the standard substitution rule, if $E;\Gamma\vdash p:T$ and $\theta:\Gamma\to\Gamma'$ is a well-typed context substitution, then

$$E;\Gamma'\vdash\theta(p):\theta(T).$$

**Proof sketch.** Induct through the typing derivation; the variable case uses the substitution's typing assumptions, and binder cases extend the substitution with a fresh bound variable. Local definitions require compatibility with their values. If $\theta(T)$ is definitionally equal to $T'$, the conversion rule gives the desired judgment. $\square$

This is standard metatheory, not an original theorem claimed by the project. It motivates a concrete checker: build the candidate in Lean rather than trusting Python's matcher. Different environments require checking the used declarations, universe parameters, and permitted axioms; equal spelling of a constant is not sufficient.

### Online procedure

```text
For each actually solved local obligation:
  inspect the resulting term in its saved Lean context;
  reject unresolved holes, unexported locals, or unsupported obligations;
  build its dependency-closed telescope and portable abstraction;
  store term reference, interface, provenance, and replay evidence.

Before requesting another costly tactic batch:
  query the ordinary typed cache and/or the boundary-graph index;
  propose context substitutions using only the available prefix;
  instantiate a candidate in a cloned current Lean state;
  accept a reuse only if Lean accepts the application;
  commit exactly the accepted branch and record all state effects;
  otherwise restore state and continue the unchanged baseline search.
```

The index may be approximate. False matches are performance failures, not licenses to assert a proof. Keep final full-declaration replay. Typechecking the reused term protects theorem correctness; maintaining baseline fallbacks protects coverage but does not by itself guarantee equal success under a finite budget.

## 7. Three instructive examples

### A. Existing sibling transport is a regression, not a new speed result

From $h:p\land q$, use `constructor`, `exact h.right`, `exact h.left` to prove $q\land p$. The second tactic must preserve the identity of the remaining $p$ goal. Both the user artifact and the current research line already target this case. It tests extraction, not an incremental graph-search advantage.

### B. Context-sensitive reuse: the actual new hypothesis

Suppose a completed local term proves $f\ a=g\ a$ from $h:f=g$. In another branch, the context includes extra unrelated assumptions and differently named $f,g,a,h$. The whole context key can differ even though the fragment `congrArg (fun k => k a) h` transports. A dependency-indexed cache can propose the fragment using only its required telescope; Lean checks the application.

Graph stages are: an open equality port; a retrieved fragment with unbound interface parameters; a proposed typed substitution; a successful local application; and the unchanged external frontier. This could avoid re-searching the local argument. However an ordinary proof-term cache could do exactly the same, so it is a mandatory baseline. This is a design example, not a measured result.

### C. Coupled witnesses: why local successes cannot be combined freely

For an open construction of $\exists n:\mathbb N,\ n=0\land n=1$, a shared witness cell $w$ links the residual goals $w=0$ and $w=1$. One isolated branch can succeed by setting $w:=0$, another by setting $w:=1$. Their union is inconsistent. A reuse packet for an open fragment must include assignment constraints and jointly check composition; a cache that stores only “this goal succeeded” is insufficient. This is why closed-fragment reuse precedes open-fragment reuse.

## 8. Interface and integration

Keep the frozen v0.2 graph dataset unchanged. Add `joint-sidecar/0.1.0` records keyed by source commit, declaration locator, extraction session, InfoTree/event path, and content hash. The existing exporter does not provide rich boundary state, so its imported sidecars truthfully contain `state_before: null`, `state_after: null`, and `boundary_coverage: not_exported`. [R7, R8, R17]

Use a tagged JSON expression codec rather than renaming over serialized strings. Preserve literals and alias structure; handle missing declarations as unknown. Use full digests for indexing and retain canonical bytes for collision resolution. Neither a digest nor a transport map is a proof of Lean-state equivalence.

The reference code in this package demonstrates those representation properties in a finite model. It deliberately rejects incomplete fixture coverage. It does not supply a Lean exporter, a complete operational boundary, a proof-term matcher, or kernel replay.

## 9. Scope of novelty

Existing work supplies the MLL theory, hypergraph search, Lean interfaces, factorized state reuse, and expression graphs. [R1, R10–R16] This proposal adapts those ideas into an auditable composition of state snapshots, event effects, portable proof fragments, and checked reuse. The original deliverable here is the integration design and its adversarial regression model, not a claim to have invented substitution, proof graphs, metavariable coupling, or memoization.

Tactician's Web already connects Coq definitions, proof terms, tactics, and states in a semantic graph with an interactive interface; Graph2Tac and Tactician's online learning show that reuse of nearby formal knowledge is also an established research theme. [R18, R19] These precedents further rule out claiming generic semantic proof graphs or online reuse as new. The proposed contribution must be its precise Lean-side contract, independent evidence, and measured incremental behavior.

Only experiments can establish whether the joint representation adds useful value. If a plain typed cache matches graph-indexed reuse, keep the cache and report that the graph-specific hypothesis failed.
