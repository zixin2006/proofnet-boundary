/-
Design fixtures for the proposed joint integration.
NOT compiled in this review: Lean/Lake unavailable.
Run inside the pinned proof-graphs project; add exporter checkpoints there.
No state ids, timing results, or kernel receipts are claimed by this file.
-/
import Lean

namespace JointBoundaryFixtures

 theorem swap (p q : Prop) (h : p ∧ q) : q ∧ p := by
  constructor
  · exact h.right
  · exact h.left

 theorem localFragment {α β : Type} (f g : α → β) (a : α)
    (h : f = g) : f a = g a := by
  exact congrArg (fun k => k a) h

-- This is a design for ordinary typed reuse, not evidence of a graph advantage.
 theorem transportedFragment {α β : Type} (f g : α → β) (a : α)
    (h : f = g) (irrelevant : Prop) (_ : irrelevant) : f a = g a := by
  exact localFragment f g a h

-- An actual identity exporter should preserve the literal contents in these goals.
 theorem literalOne (s : String) (h : s = "?[left]") : s = "?[left]" := by
  exact h
 theorem literalTwo (s : String) (h : s = "?[right]") : s = "?[right]" := by
  exact h
 theorem universeLookingLiteral : "?u.1" ≠ "?u.99" := by
  decide

-- The first alternative changes state, then fails: it is not a committed proof branch.
 theorem failedAlternative (p q : Prop) (h : p ∧ q) : q ∧ p := by
  first
  | constructor
    fail "intentional rollback fixture"
  | exact ⟨h.right, h.left⟩

 theorem failedTry (p q : Prop) (h : p ∧ q) : q ∧ p := by
  try
    constructor
    fail "intentional rollback fixture"
  exact ⟨h.right, h.left⟩

 theorem repeatedIntro (p q : Prop) : p → q → p := by
  repeat intro
  assumption

 theorem nestedHave (p q : Prop) (hp : p) (hpq : p → q) : p ∧ q := by
  have hq : q := by
    exact hpq hp
  exact ⟨hp, hq⟩

-- This witnesses the incompatibility that an open-fragment cache must respect.
 theorem incompatibleWitnesses : ¬ ∃ n : Nat, n = 0 ∧ n = 1 := by
  intro h
  rcases h with ⟨n, hn0, hn1⟩
  have absurd : (0 : Nat) = 1 := hn0.symm.trans hn1
  cases absurd

end JointBoundaryFixtures
