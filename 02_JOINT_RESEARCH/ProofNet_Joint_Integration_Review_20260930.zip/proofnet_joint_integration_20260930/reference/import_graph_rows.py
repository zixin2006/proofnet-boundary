"""Lossless sidecar adapter for proof-graphs exported rows (not Lean-state enrichment).
Usage: python reference/import_graph_rows.py DATA.jsonl.gz OUT.jsonl
No target expressions, states, or certificates are manufactured from a step DAG.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import json
from pathlib import Path
from typing import Any

def adapt(row: dict[str, Any], commit: str) -> dict[str, Any]:
    n = len(row['steps'])
    adj, indeg = [[] for _ in range(n)], [0] * n
    for edge in row['edges']:
        if len(edge) != 2 or any(type(i) is not int or i < 0 or i >= n for i in edge):
            raise ValueError('Invalid edge endpoint')
        a, b = edge; adj[a].append(b); indeg[b] += 1
    queue = [i for i in range(n) if indeg[i] == 0]; visited = 0
    while queue:
        i = queue.pop(); visited += 1
        for j in adj[i]:
            indeg[j] -= 1
            if indeg[j] == 0: queue.append(j)
    if visited != n: raise ValueError('Cyclic step graph')
    digest = hashlib.sha256(json.dumps(row,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return {'schema_version':'joint-sidecar/0.1.0','record_type':'offline_step_graph',
            'source_commit':commit,'source_row_sha256':digest,'source_row':row,
            'evidence':'offline_graph_derivation','state_before':None,'state_after':None,
            'boundary_coverage':'not_exported','certified_semantic_edges':[],
            'training_policy':'No online-state or safe-pruning claims from this record'}

def main() -> None:
    p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--commit',default='8010d137af5af5040fcbcd9e98f910b01162263e');a=p.parse_args()
    opening=gzip.open if a.input.suffix=='.gz' else open
    with opening(a.input,'rt',encoding='utf-8') as f, a.output.open('w',encoding='utf-8') as out:
        for no,line in enumerate(f,1):
            if line.strip():
                try: rec=adapt(json.loads(line),a.commit)
                except Exception as e: raise ValueError(f'{a.input}:{no}: {e}') from e
                out.write(json.dumps(rec,ensure_ascii=False)+'\n')
if __name__=='__main__':main()
