"""Typed boundary fingerprint and dependency guard: executable DESIGN REFERENCE.

Not a Lean extractor, type checker, proof verifier, or safe-pruning implementation.
Input is a small tagged-JSON model. Unknown dependency coverage fails closed.
Preserves literals, aliases, dependent local contexts, and universe dependencies.
See reports/METHODOLOGY.md for the stronger Lean integration contract.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import hashlib
import json

class UnsupportedBoundary(ValueError):
    """The snapshot is not complete enough to compare or factor safely."""

# expr: const(name, levels), bvar(index), fvar(id), mvar(id), sort(level),
#       app(f,a), lam(type,body,binder), forall(type,body,binder),
#       let(type,value,body), nat(value), str(value), proj(name,index,value).
# level: zero, param(name), uvar(id), succ(level), max(a,b), imax(a,b).
@dataclass(frozen=True)
class Local:
    id: str
    type: Any
    value: Any | None = None
    binder: str = "default"
    implementation_detail: bool = False

@dataclass(frozen=True)
class Meta:
    id: str
    context: tuple[Local, ...]
    type: Any
    assignment: Any | None = None
    kind: str = "natural"

@dataclass
class Snapshot:
    environment: str
    options: str
    goals: tuple[str, ...]
    metas: dict[str, Meta]
    levels: dict[str, Any | None] = field(default_factory=dict)
    dependency_coverage: str = "complete_fixture_model"

class Encoder:
    def __init__(self, snapshot: Snapshot):
        if snapshot.dependency_coverage != "complete_fixture_model":
            raise UnsupportedBoundary("Incomplete dependencies: no factorization/identity license")
        self.s = snapshot
        if len(set(snapshot.goals)) != len(snapshot.goals):
            raise UnsupportedBoundary("Duplicate active goal identity")
        self.mnums: dict[str, int] = {}
        self.unums: dict[str, int] = {}
        self.fnums: dict[str, int] = {}

    def mref(self, key: str) -> list[Any]:
        if key not in self.s.metas:
            raise UnsupportedBoundary(f"Unexported metavariable {key}")
        if key not in self.mnums:
            self.mnums[key] = len(self.mnums)
        return ["mvar", self.mnums[key]]

    def level(self, x: Any) -> Any:
        if not isinstance(x, (list, tuple)) or not x:
            raise UnsupportedBoundary("Malformed level")
        t = x[0]
        if t == "zero" and len(x) == 1:
            return [t]
        if t == "param" and len(x) == 2:
            return [t, x[1]]  # level parameters are conservatively preserved
        if t == "uvar" and len(x) == 2:
            if x[1] not in self.s.levels:
                raise UnsupportedBoundary(f"Unexported universe metavariable {x[1]}")
            if x[1] not in self.unums:
                self.unums[x[1]] = len(self.unums)
            return [t, self.unums[x[1]]]
        if t == "succ" and len(x) == 2:
            return [t, self.level(x[1])]
        if t in {"max", "imax"} and len(x) == 3:
            return [t, self.level(x[1]), self.level(x[2])]
        raise UnsupportedBoundary(f"Unsupported level {t}")

    def expr(self, x: Any, locals_: dict[str, int]) -> Any:
        if not isinstance(x, (list, tuple)) or not x:
            raise UnsupportedBoundary("Malformed expression")
        t = x[0]
        if t == "mvar" and len(x) == 2:
            return self.mref(x[1])
        if t == "fvar" and len(x) == 2:
            if x[1] not in locals_:
                raise UnsupportedBoundary(f"Unexported local {x[1]} (never replace by h?)")
            return [t, locals_[x[1]]]
        if t == "bvar" and len(x) == 2 and isinstance(x[1], int) and x[1] >= 0:
            return [t, x[1]]
        if t == "str" and len(x) == 2 and isinstance(x[1], str):
            return [t, x[1]]  # NEVER regex-rewrite a string literal
        if t == "nat" and len(x) == 2 and type(x[1]) is int and x[1] >= 0:
            return [t, x[1]]
        if t == "const" and len(x) == 3:
            return [t, x[1], [self.level(l) for l in x[2]]]
        if t == "sort" and len(x) == 2:
            return [t, self.level(x[1])]
        if t == "app" and len(x) == 3:
            return [t, self.expr(x[1], locals_), self.expr(x[2], locals_)]
        if t in {"lam", "forall"} and len(x) == 4:
            return [t, self.expr(x[1], locals_), self.expr(x[2], locals_), x[3]]
        if t == "let" and len(x) == 4:
            return [t, *(self.expr(a, locals_) for a in x[1:])]
        if t == "proj" and len(x) == 4:
            return [t, x[1], x[2], self.expr(x[3], locals_)]
        raise UnsupportedBoundary(f"Unsupported expression {t}")

    def encode(self) -> dict[str, Any]:
        for g in self.s.goals:
            self.mref(g)
        mrows, urows = [], []
        # Reference IDs are allocated before definitions; cycles cannot recurse forever.
        while len(mrows) < len(self.mnums) or len(urows) < len(self.unums):
            while len(mrows) < len(self.mnums):
                key = list(self.mnums)[len(mrows)]
                m = self.s.metas[key]
                ctx, pos = [], {}
                for loc in m.context:
                    if loc.id in pos:
                        raise UnsupportedBoundary("Duplicate local identifier")
                    # Type/value may refer only to earlier context entries.
                    ty = self.expr(loc.type, pos)
                    val = None if loc.value is None else self.expr(loc.value, pos)
                    pos[loc.id] = len(pos)
                    global_id = self.fnums.setdefault(loc.id, len(self.fnums))
                    ctx.append([global_id, loc.binder, loc.implementation_detail, ty, val])
                mrows.append({"context": ctx, "type": self.expr(m.type, pos),
                              "assignment": None if m.assignment is None else self.expr(m.assignment, pos),
                              "kind": m.kind})
            while len(urows) < len(self.unums):
                key = list(self.unums)[len(urows)]
                value = self.s.levels[key]
                urows.append(None if value is None else self.level(value))
        return {"version": "fixture-boundary/0.1", "environment": self.s.environment,
                "options": self.s.options, "goals": list(range(len(self.s.goals))),
                "metas": mrows, "universes": urows}

def canonical_bytes(snapshot: Snapshot) -> bytes:
    return json.dumps(Encoder(snapshot).encode(), ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")

def fingerprint(snapshot: Snapshot) -> str:
    """Index only. Compare bytes too; this is not a Lean-state equivalence certificate."""
    return hashlib.sha256(canonical_bytes(snapshot)).hexdigest()

def _references(x: Any) -> tuple[set[str], set[str]]:
    ms, us = set(), set()
    def walk(v: Any) -> None:
        if not isinstance(v, (list, tuple)) or not v:
            return
        tag = v[0]
        if tag in {"str", "nat", "bvar", "fvar", "param", "zero"}:
            return
        if tag == "mvar":
            ms.add(v[1]); return
        if tag == "uvar":
            us.add(v[1]); return
        if tag == "const":
            for z in v[2]: walk(z)
            return
        if tag == "proj":
            walk(v[3]); return
        for child in v[1:]: walk(child)
    walk(x)
    return ms, us

def support(snapshot: Snapshot, goal: str) -> set[tuple[str, str]]:
    """Reachable metadata closure, not just textual occurrence in visible targets."""
    if snapshot.dependency_coverage != "complete_fixture_model":
        raise UnsupportedBoundary("Cannot infer independence with incomplete coverage")
    out, todo = set(), [("m", goal)]
    while todo:
        kind, key = todo.pop()
        if (kind, key) in out: continue
        out.add((kind, key))
        if kind == "m":
            if key not in snapshot.metas: raise UnsupportedBoundary("Missing meta declaration")
            m = snapshot.metas[key]
            exprs = [m.type] + ([] if m.assignment is None else [m.assignment])
            for loc in m.context:
                exprs.append(loc.type)
                if loc.value is not None: exprs.append(loc.value)
        else:
            if key not in snapshot.levels: raise UnsupportedBoundary("Missing level declaration")
            exprs = [] if snapshot.levels[key] is None else [snapshot.levels[key]]
        for expr in exprs:
            ms, us = _references(expr)
            todo.extend(("m", k) for k in ms)
            todo.extend(("u", k) for k in us)
    return out

def groups(snapshot: Snapshot) -> list[list[str]]:
    """Conservative components IN THIS MODEL; not arbitrary Lean tactic independence."""
    supports = [support(snapshot, g) for g in snapshot.goals]
    parent = list(range(len(supports)))
    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]; i = parent[i]
        return i
    for i in range(len(supports)):
        for j in range(i):
            if supports[i] & supports[j]: parent[find(i)] = find(j)
    result: dict[int, list[str]] = {}
    for i, g in enumerate(snapshot.goals): result.setdefault(find(i), []).append(g)
    return list(result.values())

def transport(rho: dict[str, str], before: tuple[str, ...], after: tuple[str, ...],
              session: str, next_serial: int) -> tuple[dict[str, str], dict[str, Any], int]:
    """Identity transport ONLY. Disappearance does not imply closure; no focus assumption."""
    if len(set(before)) != len(before) or len(set(after)) != len(after):
        raise ValueError("Goal lists must contain distinct identities")
    if set(rho) != set(before): raise ValueError("rho must cover exactly active before-goals")
    if len(set(rho.values())) != len(rho): raise ValueError("rho must be injective")
    used, updated = set(rho.values()), {}
    for m in after:
        if m in rho: updated[m] = rho[m]
        else:
            while f"{session}:goal:{next_serial}" in used: next_serial += 1
            updated[m] = f"{session}:goal:{next_serial}"; used.add(updated[m]); next_serial += 1
    cert = {"preserved": [m for m in after if m in rho],
            "created": [m for m in after if m not in rho],
            "no_longer_active": [m for m in before if m not in updated],
            "closure_status": "requires_assignment_and_reachability_evidence"}
    return updated, cert, next_serial
