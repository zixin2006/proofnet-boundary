"""Read-only inspection of the user's uploaded v0.7.1 ZIP. No Lean execution."""
from __future__ import annotations
import argparse, hashlib, json, zipfile
from pathlib import Path
from collections import Counter

def main():
    p=argparse.ArgumentParser();p.add_argument('zipfile',type=Path);p.add_argument('--out',type=Path);a=p.parse_args()
    with zipfile.ZipFile(a.zipfile) as z:
        candidates=[n for n in z.namelist() if n.endswith('/data/actual_lean_boundary_lens_trace_steps.jsonl')]
        if len(candidates)!=1:raise ValueError(f'Expected exactly one trace file, found {candidates}')
        name=candidates[0];prefix=name.split('/data/')[0]
        rows=[json.loads(l) for l in z.read(name).decode().splitlines() if l.strip()]
        failures=[json.loads(l) for l in z.read(prefix+'/data/actual_lean_failure_branches.jsonl').decode().splitlines() if l.strip()]
        errors=[]
        try:
            import jsonschema
            sname=prefix+'/schemas/proofnet_lens_trace_step_schema_v0_7.json'
            schema=json.loads(z.read(sname));v=jsonschema.validators.validator_for(schema)(schema)
            for i,r in enumerate(rows):
                es=list(v.iter_errors(r))
                if es:errors.append({'row':i,'errors':[e.message for e in es[:5]]})
            schema_status={'schema_file':sname,'rows_failing':len(errors),'examples':errors[:2]}
        except (KeyError,ImportError) as e:schema_status={'not_run':str(e)}
        out={'zip':a.zipfile.name,'sha256':hashlib.sha256(a.zipfile.read_bytes()).hexdigest(),
             'trace_file':name,'success_rows':len(rows),'theorems':sorted({r['theorem_id'] for r in rows}),
             'failure_rows':len(failures),'rows_with_typed_edges':sum(bool(r.get('graph_delta',{}).get('edges_added')) for r in rows),
             'rows_with_rho_before':sum('rho_before' in r for r in rows),'schema_audit':schema_status,
             'fresh_lean_execution':False,'evidence_scope':'Local ZIP contents; statements of Lean execution are package provenance, not reproduced in this review.'}
    text=json.dumps(out,indent=2)
    if a.out:a.out.write_text(text+'\n')
    print(text)
if __name__=='__main__':main()
