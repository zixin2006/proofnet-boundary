from __future__ import annotations
import copy
import json
import re
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'reference'))
from boundary_guard import Local, Meta, Snapshot, UnsupportedBoundary, canonical_bytes, fingerprint, groups, transport
from import_graph_rows import adapt

P=['const','P',[]]; NAT=['const','Nat',[]]
def snap(target=P, extra=None):
    return Snapshot('env@pinned','opts@pinned',('g',),{'g':Meta('g',(),target)} | (extra or {}))

def legacy_text(text: str) -> str:
    """Small reproduction of regex renumbering in the reviewed goal_identity.py.
    Synthetic inputs only, NOT a rerun of that repository or a Lean counterexample.
    """
    nums={}; levels={}
    text=re.sub(r'\?\[([^\]]*)\]',lambda m:f'?{nums.setdefault(m[1],len(nums))}',text)
    return re.sub(r'\?u\.\d+',lambda m:f'?u{levels.setdefault(m[0],len(levels))}',text)

class GuardTests(unittest.TestCase):
    def test_goal_id_renaming(self):
        a=snap();b=Snapshot(a.environment,a.options,('different',),{'different':Meta('different',(),P)})
        self.assertEqual(canonical_bytes(a),canonical_bytes(b))
    def test_local_alpha(self):
        a=snap();a.metas['g']=Meta('g',(Local('a',NAT),),['fvar','a'])
        b=snap();b.metas['g']=Meta('g',(Local('b',NAT),),['fvar','b'])
        self.assertEqual(fingerprint(a),fingerprint(b))
    def test_mvar_aliasing_preserved(self):
        meta={'x':Meta('x',(),NAT),'y':Meta('y',(),NAT)}
        a=snap(['app',['mvar','x'],['mvar','x']],meta)
        b=snap(['app',['mvar','x'],['mvar','y']],meta)
        self.assertNotEqual(fingerprint(a),fingerprint(b))
    def test_literal_regex_counterexample(self):
        a='P "?[left]"';b='P "?[right]"'
        self.assertEqual(legacy_text(a),legacy_text(b))
        self.assertNotEqual(fingerprint(snap(['str','?[left]'])),fingerprint(snap(['str','?[right]'])))
    def test_level_literal_regex_counterexample(self):
        self.assertEqual(legacy_text('P "?u.1"'),legacy_text('P "?u.99"'))
        self.assertNotEqual(fingerprint(snap(['str','?u.1'])),fingerprint(snap(['str','?u.99'])))
    def test_unknown_local_is_not_placeholder(self):
        with self.assertRaises(UnsupportedBoundary): fingerprint(snap(['fvar','missing']))
    def test_missing_meta(self):
        with self.assertRaises(UnsupportedBoundary): fingerprint(snap(['mvar','missing']))
    def test_dependency_coverage(self):
        a=snap();a.dependency_coverage='partial'
        with self.assertRaises(UnsupportedBoundary): groups(a)
        with self.assertRaises(UnsupportedBoundary): fingerprint(a)
    def test_environment_scoped(self):
        a=snap();b=snap();b.environment='different'
        self.assertNotEqual(fingerprint(a),fingerprint(b))
    def test_options_scoped(self):
        a=snap();b=snap();b.options='different'
        self.assertNotEqual(fingerprint(a),fingerprint(b))
    def test_joint_local_sharing(self):
        a=Snapshot('e','o',('a','b'),{'a':Meta('a',(Local('x',NAT),),['fvar','x']),
                                    'b':Meta('b',(Local('x',NAT),),['fvar','x'])})
        b=Snapshot('e','o',('a','b'),{'a':Meta('a',(Local('x',NAT),),['fvar','x']),
                                    'b':Meta('b',(Local('y',NAT),),['fvar','y'])})
        self.assertNotEqual(fingerprint(a),fingerprint(b))
    def test_local_value_kept(self):
        a=snap();b=snap()
        a.metas['g']=Meta('g',(Local('n',NAT,['nat',0]),),['fvar','n'])
        b.metas['g']=Meta('g',(Local('n',NAT,['nat',1]),),['fvar','n'])
        self.assertNotEqual(fingerprint(a),fingerprint(b))
    def test_local_binder_kept(self):
        a=snap();b=snap()
        a.metas['g']=Meta('g',(Local('n',NAT,binder='default'),),P)
        b.metas['g']=Meta('g',(Local('n',NAT,binder='instance'),),P)
        self.assertNotEqual(fingerprint(a),fingerprint(b))
    def test_independent_goals(self):
        a=Snapshot('e','o',('a','b'),{'a':Meta('a',(),P),'b':Meta('b',(),P)})
        self.assertEqual(groups(a),[['a'],['b']])
    def test_shared_witness(self):
        a=Snapshot('e','o',('a','b'),{'a':Meta('a',(),['mvar','w']),'b':Meta('b',(),['mvar','w']),
                                    'w':Meta('w',(),NAT)})
        self.assertEqual(groups(a),[['a','b']])
    def test_transitive_type_dependency(self):
        # a mentions x, b mentions y; only their declaration types expose shared w.
        a=Snapshot('e','o',('a','b'),{'a':Meta('a',(),['mvar','x']),'b':Meta('b',(),['mvar','y']),
            'x':Meta('x',(),['mvar','w']),'y':Meta('y',(),['mvar','w']),'w':Meta('w',(),NAT)})
        self.assertEqual(groups(a),[['a','b']])
    def test_universe_dependency(self):
        a=Snapshot('e','o',('a','b'),{'a':Meta('a',(),['sort',['uvar','u']]),
                                    'b':Meta('b',(),['sort',['uvar','u']])},{'u':None})
        self.assertEqual(groups(a),[['a','b']])
    def test_preserve_sibling(self):
        rho,cert,k=transport({'q':'nodeq','p':'nodep'},('q','p'),('p',),'s',0)
        self.assertEqual(rho,{'p':'nodep'});self.assertEqual(cert['no_longer_active'],['q'])
        self.assertIn('requires_assignment',cert['closure_status'])
    def test_context_change_same_identity(self):
        a=snap(['nat',0]);b=snap(['nat',1])
        rho,_,_=transport({'g':'same'},('g',),('g',),'s',0)
        self.assertEqual(rho['g'],'same');self.assertNotEqual(fingerprint(a),fingerprint(b))
    def test_two_disappear_no_false_focus_assertion(self):
        rho,cert,_=transport({'a':'A','b':'B'},('a','b'),(),'s',0)
        self.assertEqual(rho,{});self.assertEqual(cert['no_longer_active'],['a','b'])
    def test_offline_adapter_no_fabrication(self):
        row={'source':'fixture','module':'M','declaration':'d','steps':[{'kind':'constructor','line':1},
             {'kind':'exact','line':2}],'edges':[[0,1]],'linearizations':1}
        out=adapt(row,'fixture_commit')
        self.assertIsNone(out['state_before']);self.assertEqual(out['certified_semantic_edges'],[])
        self.assertEqual(out['source_row'],row)
    def test_offline_adapter_reject_cycle(self):
        with self.assertRaises(ValueError): adapt({'steps':[{},{}],'edges':[[0,1],[1,0]]},'x')

if __name__=='__main__':unittest.main(verbosity=2)
