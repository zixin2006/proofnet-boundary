import copy
import json
import unittest
from pathlib import Path
from jsonschema import Draft202012Validator
R=Path(__file__).resolve().parents[1]

def load(path):return json.loads((R/path).read_text())
class SchemaTests(unittest.TestCase):
    def test_schemas_are_valid(self):
        for p in (R/'schemas').glob('*.json'):
            Draft202012Validator.check_schema(json.loads(p.read_text()))
    def test_event_fixture(self):
        Draft202012Validator(load('schemas/joint_event_schema.json')).validate(load('examples/boundary_event_design_fixture.json'))
    def test_reuse_fixture(self):
        Draft202012Validator(load('schemas/closed_reuse_schema.json')).validate(load('examples/reuse_design_fixture.json'))
    def test_offline_fixture(self):
        Draft202012Validator(load('schemas/offline_sidecar_schema.json')).validate(load('examples/offline_sidecar_design_fixture.json'))
    def test_synthetic_cannot_claim_kernel_replay(self):
        x=load('examples/boundary_event_design_fixture.json');x['kernel_replay']={'status':'passed','receipt_ref':'fake'}
        self.assertTrue(list(Draft202012Validator(load('schemas/joint_event_schema.json')).iter_errors(x)))
    def test_rejected_reuse_cannot_commit(self):
        x=load('examples/reuse_design_fixture.json');x['candidate_status']='lean_rejected';x['committed']=True
        self.assertTrue(list(Draft202012Validator(load('schemas/closed_reuse_schema.json')).iter_errors(x)))
    def test_success_requires_observed_output_reference(self):
        x=load('examples/boundary_event_design_fixture.json');x['state_after_ref']=None
        self.assertTrue(list(Draft202012Validator(load('schemas/joint_event_schema.json')).iter_errors(x)))
