# ProofNet: joint integration review and next-step package

**Review date:** 30 September 2026.

Start with `reports/EXECUTIVE_SUMMARY.md`, then `reports/REPOSITORY_COMPARISON.md`. The paper in `paper/` combines the findings, revised methodology, and experiment design. For implementation, use `prompts/CODEX_JOINT_INTEGRATION_PROMPT.md` first; the closed-fragment reuse prompt is gated on that integration passing real Lean tests.

## Main recommendation

Use `proofnet-ir` as the restricted formally verified MLL layer and `proof-graphs` as the shared Lean extraction/search implementation. Refine the user's Boundary-Lens contribution into an independent semantic audit, typed transaction-aware boundary sidecar, and a checked proof-fragment reuse experiment with an ordinary typed-cache baseline. Do not duplicate work that the repositories already implement.

## Contents

- `paper/`: paper-style synthesis PDF and editable LaTeX/Markdown; executive brief PDF.
- `reports/`: comparison, methodology, collaboration proposal, experiment draft, validation limits, and source register.
- `prompts/`: two bounded Codex implementation specifications.
- `reference/`: Python design model, lossless offline-row adapter, and user-artifact audit.
- `tests/`: executable representation and schema tests.
- `schemas/`: additive event/reuse/offline sidecar schemas.
- `examples/`: explicitly synthetic JSON fixtures and uncompiled Lean fixture source.
- `figures/`: editable diagram sources and rendered SVGs.
- `evidence/`: pinned-source manifest, actual Python audit, test log, and source ledger.

## Reproduce the local checks

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python reference/audit_user_v071.py /path/to/proofnet_v071_boundary_lens_complete_20260704.zip --out audit.json
```

To wrap a separately fetched corrected graph dataset without inventing states:

```bash
python reference/import_graph_rows.py /path/to/proof-graphs-v0.2.jsonl.gz sidecars.jsonl \
  --commit 8010d137af5af5040fcbcd9e98f910b01162263e
```

The complete upstream repositories, large datasets, and original user archives are not bundled. Exact source links and commit pins are in `evidence/REVIEW_MANIFEST.json` and `reports/REFERENCES.md`.

## Status and trust boundary

This is an audit/design/reference-code package, not a completed Lean integration or a positive neural theorem-proving result. The friend's numerical results are attributed to its committed reports, not freshly rerun here. The user-archive audit and Python tests were executed here. No remote repository was modified. See `reports/REFERENCE_VALIDATION.md` for precise limitations.

The implementation code is newly authored reference code. The test file's short regex reproduction is an attributed behavioral test of the inspected source; the upstream repository is not redistributed. Preserve attribution when implementing the integration, and check upstream licensing before copying files between repositories.
