# Selected source inspection ledger

This lists files actually read through the GitHub connector. It is not a claim that every file in either repository was audited. Pins are recorded in REVIEW_MANIFEST.json. See reports/REFERENCES.md for direct links.

## proofnet-ir at 261f2db26aac842534f4306da0f45d8c5e9b1c05

- `docs/current-status.md`: restricted formal guarantees, cost model, release/rolling distinction.
- `experiments/representation-v0.3/README.md`: latest format experiment and its limitations.
- Commit metadata for HEAD: pin and September 30 experiment update.

## proof-graphs at 8010d137af5af5040fcbcd9e98f910b01162263e

- `README.md`: current program and dataset scope.
- `HANDOFF.md`: checks, non-reproduced components, and unresolved audit questions.
- `experiments/search-v0.8/README.md`: current controlled experiment, exclusions, statistical decisions, cost correction.
- `ProofGraphs/Extract.lean`: InfoTree nodes, raw goal identifiers, extraction contexts.
- `scripts/goal_identity.py`: Lean serializer, Python renumbering, grouping.
- `scripts/search_faithful.py`: whole-state and group identity, carried-goal checks, replay.
- `scripts/export_graphs.py`: original row format.
- `scripts/run_recount.py`: corrected derivation and v0.2 dataset pathway.
- Main-branch commit metadata: the September 28 runtime-cost correction.

Full repository cloning in the container failed at DNS resolution. No full-repository local build, model experiment, or bulk dataset extraction was rerun. A request for a file named LICENSE returned 404; this does not establish that no licensing information exists elsewhere. Upstream source is not bundled.
