# ProofNet v0.7.1 audit update package

This package contains an audit of `proofnet_v071_boundary_lens_complete_20260704.zip`, a methodology update for v0.7.2, strict schema drafts, and a Codex prompt to implement the next improvement step.

Files:

- `reports/PROOFNET_V071_AUDIT_AND_METHOD_UPDATE.md`
- `prompts/CODEX_V072_BOUNDARY_LENS_IMPROVEMENT_PROMPT.md`
- `schemas/proofnet_lens_trace_step_schema_v0_7_2.json`
- `schemas/proofnet_boundary_graph_schema_v0_7_2.json`
- `scripts/check_v071_current_schema_mismatch.py`

Key diagnosis:

- v0.7.1 is a real controlled Lean-state milestone.
- The sibling-goal preservation regression passes in the included data.
- The actual JSONL records do not validate against the shipped JSON Schema.
- Trace records lack explicit `rho_before` / `rho_after`.
- All typed `edges_added` are currently empty.
- Failure error extraction reads stderr only, but Lean errors appear in stdout in the shipped logs.
- Canonical graph hashes currently mix in engineering identifiers and should be split into raw/canonical/cumulative/provenance hashes.
